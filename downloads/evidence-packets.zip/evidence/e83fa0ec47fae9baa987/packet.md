# Evidence packet e83fa0ec47fae9baa987: Outcome bias

Frozen revision: 1314900231 (2025-10-03T20:19:30Z); https://en.wikipedia.org/w/index.php?oldid=1314900231
Live check: {"frozen_revid": "1314900231", "title": "Outcome bias", "live_revid": 1314900231, "live_timestamp": "2025-10-03T20:19:30Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "central_effect", "context_kind": "inline", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 2}

## Article lead (plain rendering, approximate)
The outcome bias is an error made in evaluating the quality of a decision when the outcome of that decision is already known. Specifically, the outcome effect occurs when the same "behavior produce[s] more ethical condemnation when it happen[s] to produce bad rather than good outcome, even if the outcome is determined by chance". [ref: Gino (2009) "No Harm, No Foul: The Outcome Bias in Ethical Judgments"]

While similar to the hindsight bias, the two phenomena are markedly different. Hindsight bias focuses on memory distortion to favor the actor, while the outcome bias focuses exclusively on weighting the outcome heavier than other pieces of information in deciding if a past decision was correct.

## Article outline
Overview
See also
References

## Categories
Cognitive biases

## Occurrence 1: original DOI 10.1037/0022-3514.54.4.569 in section 'Overview'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
Baron and Hershey (1988) presented subjects with hypothetical situations in order to test this. [FOCAL REF: Baron (1988) "Outcome bias in decision evaluation" doi:10.1037/0022-3514.54.4.569]
One such example involved a surgeon deciding whether or not to do a risky surgery on a patient. The surgery had a known probability of success. Subjects were presented with either a good or bad outcome (in this case living or dying), and asked to rate the quality of the surgeon's pre-operation decision. Those presented with bad outcomes rated the decision worse than those who had good outcomes. "The ends justify the means" is an often-used aphorism to express the outcome effect when the outcome is desirable.

### Paragraph (raw wikitext)
```
Baron and Hershey (1988) presented subjects with hypothetical situations in order to test this.<ref name="BaronHershey1988">{{cite journal|last1=Baron|first1=Jonathan | author-link = Jonathan Baron|last2=Hershey|first2=John C.|title=Outcome bias in decision evaluation|journal=Journal of Personality and Social Psychology|volume=54|issue=4|year=1988|pages=569–579|url=http://commonweb.unifr.ch/artsdean/pub/gestens/f/as/files/4660/21931_171009.pdf|doi=10.1037/0022-3514.54.4.569|pmid=3367280 |s2cid=26091312 }}</ref>
One such example involved a surgeon deciding whether or not to do a risky surgery on a patient. The surgery had a known probability of success. Subjects were presented with either a good or bad outcome (in this case living or dying), and asked to rate the quality of the surgeon's pre-operation decision. Those presented with bad outcomes rated the decision worse than those who had good outcomes. "[[The ends justify the means]]" is an often-used aphorism to express the outcome effect when the outcome is desirable.
```

### Full section (plain rendering)
==Overview==
One will often judge a past decision by its ultimate outcome instead of based on the quality of the decision at the time it was made, given what was known at that time. This is an error because no decision-maker ever knows whether or not a calculated risk will turn out for the best. The actual outcome of the decision will often be determined by chance, with some risks working out and others not. Individuals whose judgments are influenced by outcome bias are seemingly holding decision-makers responsible for events beyond their control.

Baron and Hershey (1988) presented subjects with hypothetical situations in order to test this. [FOCAL REF: Baron (1988) "Outcome bias in decision evaluation" doi:10.1037/0022-3514.54.4.569]
One such example involved a surgeon deciding whether or not to do a risky surgery on a patient. The surgery had a known probability of success. Subjects were presented with either a good or bad outcome (in this case living or dying), and asked to rate the quality of the surgeon's pre-operation decision. Those presented with bad outcomes rated the decision worse than those who had good outcomes. "The ends justify the means" is an often-used aphorism to express the outcome effect when the outcome is desirable.

This mistake occurs when currently available information is incorporated when evaluating a past decision. To avoid the influence of outcome bias, one would evaluate a decision by ignoring information collected after the fact and focusing on what the right answer is, or was at the time the decision was made.

Outside of psychological experiments, the outcome bias has been found to be substantially present in real world situations. A study looking at the evaluation of football players' performance by coaches and journalists found that players' performance is judged to be substantially better—over a whole match—if the player had a lucky goal rather than an unlucky miss (after a player's shot hit one of the goal posts). [ref: Gauriot (2019) "Fooled by Performance Randomness: Overrewarding Luck" doi:10.1162/rest_a_00783] Another study found that professional basketball coaches are "more likely to revise their strategy after a loss than a win... even when a loss was expected and even when failure is due to factors beyond the team's control." [ref: Lefgren (2015) "Sticking with What (Barely) Worked: A Test of Outcome Bias" doi:10.1287/mnsc.2014.1966]

The outcome bias is closely related to the philosophical concept of moral luck as in both concepts, the evaluation of actions is influenced by factors that are not logically justifiable. [ref: Max (2023) "Moral luck in investment contexts: We consciously find unprofitable in" doi:10.1371/journal.pone.0278677]

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: e83fa0ec47fae9baa987/article_plain.txt in the evidence directory.)

- (none found by keyword scan)

## ORIGINAL STUDY: doi:10.1037/0022-3514.54.4.569 (FLoRA title: Outcome bias in decision evaluation.)
Crossref: Outcome bias in decision evaluation. | Jonathan Baron, John C. Hershey | Journal of Personality and Social Psychology | 1988 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W4242732483", "type": "article", "publication_year": 1988, "cited_by_count": 689, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1037_0022_3514_54_4_569.txt (Free copy found by source search (accepted manuscript): https://www.sas.upenn.edu/~baron/papers.htm/judg.html)
Retrieved: 2026-10-06T16:10:08+00:00

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.5334/irsp.751 (FLoRA title: Outcomes Affect Evaluations of Decision Quality: Replication and Extensions of Baron and Hershey's (1988) Outcome Bias Experiment 1; FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: Outcomes Affect Evaluations of Decision Quality: Replication and Extensions of Baron and Hershey&amp;rsquo;s (1988) Outcome Bias Experiment 1 | Sriraj Aiyer, Hoi Ching Kam, Ka Yuk Ng, Nathaniel A. Young, Jiaxin Shi, Gilad Feldman | International Review of Social Psychology | 2023 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W4385355091", "type": "article", "publication_year": 2023, "cited_by_count": 3, "is_retracted": false, "oa_status": "diamond", "oa_pdf": "https://storage.googleapis.com/jnl-up-j-irsp-files/journals/1/articles/751/64d085974dca9.pdf", "oa_landing": "https://doi.org/10.5334/irsp.751"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext/10_5334_irsp_751.txt (Europe PMC open-access full text (PMC12372742))
Retrieved: 2026-10-06T16:10:09+00:00
### Abstract (Crossref deposited abstract)
Outcome bias is the phenomenon whereby decisions which resulted in successful outcomes were rated more favorably than when the same decisions resulted in failures. We conducted a pre-registered replication and extension of Experiment 1 (original’s: N = 20) from the classic Baron and Hershey (1988) with an online Amazon Mechanical Turk sample using CloudResearch (N = 692), switching from a within-participants design in the original experiment to a between-participants design. We tested outcome bias by measuring participants’ ratings of the quality of decisions in medical scenarios. For the replication (pre-registered) part of the study, we successfully replicated signal and direction of the outcome bias (original: dpaired = 0.21 – 0.53; replication: dindependent = 0.77 [0.62, 0.93] to 1.1 [0.94, 1.26]), and even for participants who stated that outcomes should not be taken into consideration when evaluating decisions (d = 0.64 [0.21, 1.08]). For the extension part of the study, we found differences, dependent on outcome types, in evaluations of the perceived importance of considering the outcome, the perceived responsibility of decision-makers, and the perception that others would act similarly given the choice by outcome type. Materials, data, and code are available on Open Science Framework (OSF): https://osf.io/knjhu/.

## Other database studies cited on this same page (each has its own packet; drafted together)
- d6bc57905df5db6c86f5: Sticking with What (Barely) Worked: A Test of Outcome Bias (doi:10.1287/mnsc.2014.1966)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.4103/jacs.jacs_21_26 | Applied Consciousness: Toward a Working Definition | 2026 | read: metadata_only | mentions replication: False
- doi:10.1017/jdm.2025.10011 | On the process and value of direct close replications: A rejoinder to Shafir and Cheek’s (2024) commentary on Chandrashekar et al. (2021) | 2025 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_1017_jdm_2025_10011.txt
  Snippet: e (2025) team suggests that the answer to all of those questions is 'yes'. three of the target articles that we successfully replicated from the 1970s and the 1980s using very similar items with little to no adjustments were about these 3 biases. in aiyer et al. (2023), we successfully replicated outcome bias demonstrated by https://doi.org/10.1017/jdm.2025.10011 published online by cambridge university press 10 subramanya prasad chandrashekar and gilad feldman baron and hershey (1988) showing that a
  Snippet: authorship of this article. competing interests. we are the authors of the target article for the commentary. other than that, we declare no potential competing interests with respect to the authorship and/or publication of this article. references aiyer, s., kam, h. c., ng, k. y., young, n. a., shi, j., & feldman, g. (2023). outcomes affect evaluations of decision quality: replication and extensions of baron and hershey's (1988) outcome bias experiment 1 international review of social psychology, 3
- doi:10.1146/annurev-psych-020821-114157 | Replicability, Robustness, and Reproducibility in Psychological Science | 2021 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_1146_annurev_psych_020821_114157.txt
- doi:10.1016/j.copsyc.2015.07.016 | Moral coherence processes: constructing culpability and consequences | 2015 | read: metadata_only | mentions replication: False
- doi:10.1177/01461672211042315 | Action and Inaction in Moral Judgments and Decisions: Meta-Analysis of Omission Bias Omission-Commission Asymmetries | 2021 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_1177_01461672211042315.txt

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1146/annurev-psych-020821-114157 | Replicability, Robustness, and Reproducibility in Psychological Science | 2021 | review | cited_by 777
  Abstract: Replication-an important, uncommon, and misunderstood practice-is gaining appreciation in psychology. Achieving replicability is important for making research progress. If findings are not replicable, then prediction and theory development are stifled. If findings are replicable, then interrogation of their meaning and validity can advance knowledge. Assessing replicability can be productive for generating and testing hypotheses by actively confronting current understandings to identify weaknesses and spur innovation. For psychology, the 2010s might be characterized as a decade of active confrontation. Systematic and multi-site replication projects assessed current understandings and observed surprising failures to replicate many published findings. Replication efforts highlighted sociocultural challenges such as disincentives to conduct replications and a tendency to frame replication as a personal attack rather than a healthy scientific practice, and they raised awareness that replication contributes to self-correction. Nevertheless, innovation in doing and understanding replication and its cousins, reproducibility and robustness, has positioned psychology to improve research pra
- [review citing original] doi:10.1016/j.copsyc.2015.07.016 | Moral coherence processes: constructing culpability and consequences | 2015 | review | cited_by 53
  Abstract: (none)
- [review citing original] doi:10.1177/01461672211042315 | Action and Inaction in Moral Judgments and Decisions: Meta-Analysis of Omission Bias Omission-Commission Asymmetries | 2021 | review | cited_by 43
  Abstract: Omission bias is people’s tendency to evaluate harm done through omission as less morally wrong and less blameworthy than commission when there is harm. However, findings are inconsistent. We conducted a preregistered meta-analysis, with 21 samples (13 articles, 49 effects) on omission-commission asymmetries in judgments and decisions. We found an overall effect of g = 0.45, 95% confidence interval (CI) = [0.14, 0.77], with stronger effects for morality and blame than for decisions. Publication bias tests produced mixed results with some indication for publication bias, though effects persisted even after most publication bias adjustments. The small sample of studies included limited our ability to draw definite conclusions regarding moderators, with inconclusive findings when applying different models. After compensating for low power, we found indication for moderation by role responsibility, perspective (self vs. others), outcome type, and study design. We hope this meta-analysis will inspire research on this phenomenon and applications to real-life, especially given the raging pandemic. Materials, data, and code are available on https://osf.io/9fcqm/ .
- [review citing original] doi:10.1213/ane.0000000000006666 | Identifying, Understanding, and Minimizing Unconscious Cognitive Biases in Perioperative Crisis Management: A Narrative Review | 2023 | review | cited_by 5
  Abstract: Rapid clinical decision-making behavior is often based on pattern recognition and other mental shortcuts. Although such behavior is often faster than deliberative thinking, it can also lead to errors due to unconscious cognitive biases (UCBs). UCBs may contribute to inaccurate diagnoses, hamper interpersonal communication, trigger inappropriate clinical interventions, or result in management delays. The authors review the literature on UCBs and discuss their potential impact on perioperative crisis management. Using the Scale for the Assessment of Narrative Review Articles (SANRA), publications with the most relevance to UCBs in perioperative crisis management were selected for inclusion. Of the 19 UCBs that have been most investigated in the medical literature, the authors identified 9 that were judged to be clinically relevant or most frequently occurring during perioperative crisis management. Formal didactic training on concepts of deliberative thinking has had limited success in reducing the presence of UCBs during clinical decision-making. The evolution of clinical decision support tools (CDSTs) has demonstrated efficacy in improving deliberative clinical decision-making, pos
- [cites original and replication 10.5334/irsp.751] doi:10.4103/jacs.jacs_21_26 | Applied Consciousness: Toward a Working Definition | 2026 | article | cited_by 0
  Abstract: (none)
- [cites original and replication 10.5334/irsp.751] doi:10.1017/jdm.2025.10011 | On the process and value of direct close replications: A rejoinder to Shafir and Cheek’s (2024) commentary on Chandrashekar et al. (2021) | 2025 | article | cited_by 0
  Abstract: Abstract The studies in Shafir (1993, Memory & Cognition 21, 546–556) examined the impact of decision frames (choosing vs. rejecting) on decision-making. Our replication—Chandrashekar et al. (2021, Judgment and Decision Making 16, 36–56)—revealed mixed results with only partial support for the original findings, concluding a successful replication of only 2 out of 8 scenarios. Our data from an exploratory extension suggested a pattern in support of an alternative theoretical mechanism aligning with Wedell’s (1997, Memory & Cognition 25, 873–887) accentuation hypothesis. Shafir and Cheek’s (2024) commentary criticized our approach to replications, and the value and importance of direct close replications overall, and shared their views regarding the theory and scope of the phenomenon, with new information about what they consider to be needed steps to empirically test the phenomenon. In our response, we clarify misunderstandings and address empirical findings shared in the commentary. We discuss and defend the value and importance of direct replications and the necessity for full transparency regarding the theoretical assumptions and the process of empirical investigations. Finally,
