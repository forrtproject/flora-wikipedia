# Evidence packet 9a0301d3414fcc395a3d: Non-resident citizen voting

Frozen revision: 1376097196 (2026-09-22T01:52:09Z); https://en.wikipedia.org/w/index.php?oldid=1376097196
Live check: {"frozen_revid": "1376097196", "title": "Non-resident citizen voting", "live_revid": 1376097196, "live_timestamp": "2026-09-22T01:52:09Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "broad_topic", "context_kind": "inline", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 1}

## Article lead (plain rendering, approximate)
Non-resident citizen voting is citizens voting in elections according to their citizenship while not residing in the country of the election. As of 2020 a total of 141 countries grant non-residents such as emigrants or expatriates the right to non-resident citizen voting. [ref: Wellman (2023) "The Extraterritorial Voting Rights and Restrictions Dataset (1950-2020" doi:10.1177/00104140221115169] There is considerable variation across countries in regard to voter eligibility, voting modalities, i.e. voting in person at diplomatic missions or other physical locations, by post or online, which elections nonresident citizens may vote in, i.e. elections of the national legislature, executive elections, referendums, or sub-national elections, and how nonresident citizen voters are represented. The number of countries enfranchising nonresident citizens accelerated significantly in the 1990s. Social scientists have advanced a number of claims about the causes and consequences of this development and debated its normative implications or pros and cons of nonresident citizen voting.

## Article outline
Variations
Historical development
Causes and consequences
Normative debates
By jurisdiction
  Australia
  Austria
  Bangladesh
  Belgium
  Brazil
  Canada
  Chile
  Colombia
  Costa Rica
  Czech Republic
  Denmark
  Dominican Republic
  El Salvador
  Finland
  France
  Germany
  Guinea-Bissau
  Greece
  Hungary
  Iceland
  India
  Indonesia
  Ireland
  Israel
  Italy
  Japan
  Lithuania
  Luxembourg
  Malta
  Mexico
  Morocco
  Namibia
  Netherlands
  New Zealand
  Nigeria
  North Macedonia
  Norway
  Pakistan
  Peru
  Philippines
  Poland
  Portugal
  Romania
  Singapore
  Slovakia
  South Africa
  South Korea
  Spain
  Sweden
  Switzerland
  Taiwan
  Tunisia
  Turkey
  Tuvalu
  Ukraine

## Categories
Expatriate voting; Suffrage

## Occurrence 1: original DOI 10.1177/0010414014546331 in section 'Causes and consequences'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
== Causes and consequences ==
There are a number of different reasons which explain why and when states enfranchise non-resident citizens. One factor is that states seek benefits from emigrants, i.e. states hope that emigrants will be more likely to contribute to the economy of their country of origin through remittances or show loyalty in other ways if they have the right to vote in that country's elections. [ref: (2013) "Transnational politics and the state: the external voting rights of di"] Second, the enfranchisement of non-resident citizens may be the result of lobbying by emigrant organizations. This played a role in the Mexican case. [ref: (2013) "Transnational politics and the state: the external voting rights of di"] Third, governing parties will resist non-resident citizen voting if they have grounds to believe that extending the franchise will benefit the opposition. Thus, non-resident citizen voting becomes possible once the opponents of non-resident citizen voting lose power as happened in Italy in the 1990s. [ref: (2013) "Transnational politics and the state: the external voting rights of di"] Finally, Turcu and Urbatch found evidence for the diffusion of democratic norms favoring non-resident citizen voting. [FOCAL REF: Turcu (2015) "Diffusion of Diaspora Enfranchisement Norms: A Multinational Study" doi:10.1177/0010414014546331] Once one country introduces non-resident citizen voting, neighboring countries become more likely to do the same.

### Paragraph (raw wikitext)
```
== Causes and consequences ==
There are a number of different reasons which explain why and when states enfranchise non-resident citizens.  One factor is that states seek benefits from emigrants, i.e. states hope that emigrants will be more likely to contribute to the economy of their country of origin through remittances or show loyalty in other ways if they have the right to vote in that country's elections.<ref name=":3">{{Cite book |title=Transnational politics and the state: the external voting rights of diasporas |date=2013 |publisher=Routledge |isbn=978-0-203-07728-3 |editor-last=Lafleur |editor-first=Jean-Michel |series=Routledge Research in Transnationalism |location=New York/N.Y}}</ref> Second, the enfranchisement of non-resident citizens may be the result of lobbying by emigrant organizations. This played a role in the Mexican case.<ref name=":3" /> Third, governing parties will resist non-resident citizen voting if they have grounds to believe that extending the franchise will benefit the opposition.  Thus, non-resident citizen voting becomes possible once the opponents of non-resident citizen voting lose power as happened in Italy in the 1990s.<ref name=":3" /> Finally, Turcu and Urbatch found evidence for the diffusion of democratic norms favoring non-resident citizen voting.<ref>{{Cite journal |last1=Turcu |first1=Anca |last2=Urbatsch |first2=R. |date=March 2015 |title=Diffusion of Diaspora Enfranchisement Norms: A Multinational Study |url=http://journals.sagepub.com/doi/10.1177/0010414014546331 |journal=Comparative Political Studies |volume=48 |issue=4 |pages=407–437 |doi=10.1177/0010414014546331 |issn=0010-4140|url-access=subscription }}</ref> Once one country introduces non-resident citizen voting, neighboring countries become more likely to do the same.
```

### Full section (plain rendering)
== Causes and consequences ==
There are a number of different reasons which explain why and when states enfranchise non-resident citizens. One factor is that states seek benefits from emigrants, i.e. states hope that emigrants will be more likely to contribute to the economy of their country of origin through remittances or show loyalty in other ways if they have the right to vote in that country's elections. [ref: (2013) "Transnational politics and the state: the external voting rights of di"] Second, the enfranchisement of non-resident citizens may be the result of lobbying by emigrant organizations. This played a role in the Mexican case. [ref: (2013) "Transnational politics and the state: the external voting rights of di"] Third, governing parties will resist non-resident citizen voting if they have grounds to believe that extending the franchise will benefit the opposition. Thus, non-resident citizen voting becomes possible once the opponents of non-resident citizen voting lose power as happened in Italy in the 1990s. [ref: (2013) "Transnational politics and the state: the external voting rights of di"] Finally, Turcu and Urbatch found evidence for the diffusion of democratic norms favoring non-resident citizen voting. [FOCAL REF: Turcu (2015) "Diffusion of Diaspora Enfranchisement Norms: A Multinational Study" doi:10.1177/0010414014546331] Once one country introduces non-resident citizen voting, neighboring countries become more likely to do the same.

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 9a0301d3414fcc395a3d/article_plain.txt in the evidence directory.)

- === United Kingdom ===
British citizens living abroad can vote in general elections and referendums, with no time limit. The Elections Act 2022 removed the previous rule whereby British citizens residing abroad could vote for up to 15 years after ceasing to live in the UK. [ref: "Greater protections for voters as government's Elections Bill achieves"] This rule was a hotly debated topic among British citizens abroad, particularly those who had lived in European Union Member States for more than 15 years at the time of referendum on European Union membership, and were thus barred from voting in it despite it being argued that they were more affected by the result than British people living in the UK. [ref: (2018) "UK again vows to give Brits in France 'votes for life' but is it all t"] [ref: Troughton (2017) "British expats demand the end of controversial 15-year rule"] The Government intended that registration of overseas electors would be possible from in the autumn of 2023 [ref: Clark (2022) "Overseas electors: open letter to the Association of Electoral Adminis"] but the required secondary legislation was only laid before Parliament on 23 October 2023. [ref: UK Parliament (2023) "Representation of the People (Overseas Electors etc.) (Amendment) Regu"] Registration subsequently became possible on 16 January 2024. [ref: Johnston (2023) "Overseas voters: Research Briefing"] [ref: Johnston (2023) "Overseas voters [full report]"] [ref: https://www.electoralcommission.org.uk/new

## ORIGINAL STUDY: doi:10.1177/0010414014546331 (FLoRA title: Diffusion of Diaspora Enfranchisement Norms)
Crossref: Diffusion of Diaspora Enfranchisement Norms | Anca Turcu, R. Urbatsch | Comparative Political Studies | 2014 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2077503895", "type": "article", "publication_year": 2014, "cited_by_count": 92, "is_retracted": false, "oa_status": "green", "oa_pdf": null, "oa_landing": "https://stars.library.ucf.edu/facultybib2010/6841"}
Evidence level available to you: ABSTRACT
Retrieved: 2026-10-06T16:11:59+00:00
### Abstract (Crossref deposited abstract)
States have increasingly granted voting rights to their citizens overseas. Traditional accounts of franchise extension suggest that governments’ motivations are either political (new voters are expected to support the incumbent government) or, in the case of citizens abroad, materialist (a fortified link to migrants encourages remittance flows). Although these factors doubtless matter, they overlook the tendency for liberal norms to diffuse through the international system, as competition with and learning from neighbors motivate the adoption of relevant policies and institutions. We use large- N cross-national hazard models to examine whether a similar pattern holds for diaspora enfranchisement and find that neighbors’ recent enactment of overseas voting nearly doubles the chance that a country will enfranchise its own diaspora. This suggests a role for international norms in determining national voting policies.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.17605/osf.io/6e9ka (FLoRA title: Reproduction (with author data & code): Turcu & Urbatsch (2014, Comparative Political Studies); FLoRA outcome code: computationally reproducible, robustness not checked [screening input only, not citable]; DOI detected on page: False)
Crossref: None |  | None | None | type None
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W7131873996", "type": "preprint", "publication_year": 2020, "cited_by_count": 0, "is_retracted": false, "oa_status": "green", "oa_pdf": null, "oa_landing": "https://doi.org/10.17605/osf.io/6e9ka"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_17605_osf_io_6e9ka.txt (Free copy found by source search (other): https://osf.io/download/xhu2w/)
Retrieved: 2026-10-06T16:12:00+00:00

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
