# Evidence packet 098f4d519687b4aed607: Positive illusions

Frozen revision: 1309404794 (2025-09-03T21:57:48Z); https://en.wikipedia.org/w/index.php?oldid=1309404794
Live check: {"frozen_revid": "1309404794", "title": "Positive illusions", "live_revid": 1309404794, "live_timestamp": "2025-09-03T21:57:48Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "broad_topic", "context_kind": "list", "living_person_category": false, "health_term_flag": true, "co_cited": false, "large_project": false, "flora_originals_on_page": 3}

## Article lead (plain rendering, approximate)
Positive illusions are unrealistically favorable attitudes that people have towards themselves or to people that are close to them. Positive illusions are a form of self-deception or self-enhancement that feel good, maintain self-esteem, or avoid discomfort, at least in the short term. There are three general forms: inflated assessment of one's own abilities, unrealistic optimism about the future, and an illusion of control. [ref: harvnb|Kruger|Chan|Roese|2009.] The term "positive illusions" originates in a 1988 paper by Shelley E. Taylor and Jonathon D. Brown. [ref: harvnb|Kruger|Chan|Roese|2009.] Taylor and Brown's model of mental health maintains that certain positive illusions are highly prevalent in normal thought and predictive of criteria traditionally associated with mental health.

There are controversies about the extent to which people reliably demonstrate positive illusions, as well as whether these illusions are beneficial to the people who have them. [ref: harvnb|Kruger|Chan|Roese|2009.] [ref: harvnb|McKay|Dennett|2009.] [ref: harvnb|Colvin|Block|1994.] [ref: harvnb|Birinci|Dirik|2010.]

## Article outline
Types
Origins
Benefits and liabilities
  Mental health
  Physical health
  Potential liabilities
Negative counterparts
Mitigation
See also
Notes
References
External links

## Categories
Cognitive biases; Illusions; Perception

## Occurrence 1: original DOI 10.1037/0022-3514.49.6.1621 in section 'References'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
==References==

* [Adelson (2005) "Probing the puzzling workings of 'depressive realism'"]
* [Alicke (1985) "Global self-evaluation as determined by the desirability and controlla" doi:10.1037/0022-3514.49.6.1621]
* Alicke, M.D., & Govorun, O. (2005). "The better-than-average effect." In M.D. Alicke, D.A. Dunning, & J.I. Krueger (Eds.), The self in social judgment (pp.&nbsp;85 –108). Hove: Psychology.
* [Allan (2007) "The sad truth about depressive realism" doi:10.1080/17470210601002686]
* [Armor (1998) "Advances in Experimental Social Psychology" doi:10.1016/S0065-2601(08)60386-X]
* [Armor (2002) "Heuristics and Biases: The Psychology of Intuitive Judgment" doi:10.1017/CBO9780511808098.021]
* [Baumeister (1989) "The optimal margin of illusion" doi:10.1521/jscp.1989.8.2.176]
* [Biglan (2012) "The Critical Role of Nurturing Environments for Promoting Human Wellbe" doi:10.1037/a0026796]
* [Birinci (2010) "Depressive Realism: Happiness or Objectivity"]
* [Bonanno (2005) "Self-enhancement among high-exposure survivors of the September 11th t" doi:10.1037/0022-3514.88.6.984]
* [Bower (1998) "Cognitive processing, discovery of meaning, CD 4 decline, and AIDS-rel" doi:10.1037/0022-006X.66.6.979]
* [Boyd-Wilson (2000) "Do we need positive illusions to carry out plans? Illusion: and instru" doi:10.1016/S0191-8869(99)00261-5]
* [Brown (1986) "Evaluations of self and others: Self-enhancement biases in social judg" doi:10.1521/soco.1986.4.4.353]
*[Buehler (1994) "Exploring the "planning fallacy": Why people underestimate their task " doi:10.1037/0022-3514.67.3.366]
* [Campbell (1986) "Similarity and uniqueness: The effects of attribute type, relevance, a" doi:10.1037/0022-3514.50.2.281]
* [Carson (2010) "Depressive realism and clinical depression" doi:10.1016/j.brat.2009.11.011]
* [Colvin (1994) "Do positive illusions foster mental health? An Examination of the Tayl" doi:10.1037/0033-2909.116.1.3]
* [Compton (1992) "Are positive illusions necessary for self-esteem: a research note" doi:10.1016/0191-8869(92)90177-Q]
* [Coyne (1983) "The role of cognition in depression: A critical appraisal" doi:10.1037/0033-2909.94.3.472]
*[Crary (1966) "Reactions to incongruent self-experiences" doi:10.1037/h0023347]
* [Dufner (2018) "Self-Enhancement and Psychological Adjustment: A Meta-Analytic Review" doi:10.1177/1088868318756467]
* [Dunning (1989) "Heuristics and Biases: The Psychology of Intuitive Judgment"]
* [Dunning (2004) "Flawed Self-Assessment. Implications for Health, Education, and the Wo" doi:10.1111/j.1529-1006.2004.00018.x]
* [Dykman (1989) "Processing of ambiguous and unambiguous feedback by depressed and nond" doi:10.1037/0022-3514.56.3.431]
* [Eiser (2001) "Optimism, pessimism, and the direction of self-other comparisons" doi:10.1006/jesp.2000.1438]
* Fiske, S.T., & Taylor, S.E. (in press). Social cognition (3rd ed.). New York: Random House.
* [Fleming (1989) "Perceiving choice and constraint: The effects of contextual and behavi" doi:10.1037/0022-3514.56.1.27]
* [Fu (2003) "Depression, Confidence, and Decision: Evidence Against Depressive Real" doi:10.1007/s10862-005-2404-x]
* [Golin (1979) "The illusion of control among depressed patients" doi:10.1037/h0077992]
* [Gollwitzer (1989) "Effects of deliberative and implemental mind-sets on illusion of contr" doi:10.1037/0022-3514.56.4.531]
* [Greenwald (1980) "The totalitarian ego: Fabrication and revision of personal history" doi:10.1037/0003-066X.35.7.603]
* [Heine (2007) "In Search of East Asian Self-Enhancement" doi:10.1177/1088868306294587]
* [Janoff-Bulman (1982) "Expectations and action: Expectancy-value models in psychology"]
*[John (1994) "Accuracy and bias in self-perception: Individual differences in self-e" doi:10.1037/0022-3514.66.1.206]
* [Joiner (2006) "On Seeing Clearly and Thriving: Interpersonal Perspicacity as Adaptive" doi:10.1521/jscp.2006.25.5.542]
* [Kruger (1999) "Lake Wobegon be gone! The below-average effect and the egocentric natu" doi:10.1037/0022-3514.77.2.221]
* [Kruger (2009) "(Not so) positive illusions" doi:10.1017/S0140525X09991270]
* [Kuiper (1982) "Depressed and nondepressed content self-reference in mild depression" doi:10.1111/j.1467-6494.1982.tb00746.x]
* [Leary (2007) "Motivational and emotional aspects of the self" doi:10.1146/annurev.psych.58.110405.085658]
* [Lewinsohn (1980) "Social competence and depression: The role of illusory self-perception" doi:10.1037/0021-843X.89.2.203]
*[McFarland (1982) "Impact of causal attributions on affective reactions to success and fa" doi:10.1037/0022-3514.43.5.937]
* [McKay (2009) "The evolution of misbelief" doi:10.1017/S0140525X09990975]
* [Moore (2007) "Not so above average after all: When people believe they are worse tha" doi:10.1016/j.obhdp.2006.09.005]
* [Moore (2007) "Depressive Realism and Attributional Style: Implications for Individua" doi:10.1016/j.beth.2006.06.003]
* [Moore (2012) "Depressive realism: A meta-analytic review" doi:10.1016/j.cpr.2012.05.004] 
* [Msetfi (2005) "Depressive realism and outcome density bias in contingency judgments: " doi:10.1037/0096-3445.134.1.10]
* [Msetfi (2007) "Depressive realism and the effect of intertrial interval on judgements" doi:10.1080/17470210601002595]
* [Nuttin (1987) "Affective consequences of mere ownership: The name letter effect in tw" doi:10.1002/ejsp.2420170402]
* [Owens (2007) "A critical review of self-perception and the positive illusory bias I " doi:10.1007/s10567-007-0027-3]
*[Robins (2001) "Positive illusions about the self: Short-term benefits and long-term c" doi:10.1037/0022-3514.80.2.340]
* [Ruehlman (1985) "Depression and evaluative schemata" doi:10.1111/j.1467-6494.1985.tb00888.x]
* [Sedikides (2008) "Self-enhancement: Food for thought" doi:10.1111/j.1745-6916.2008.00068.x]
* [Segerstrom (1998) "Optimism is associated with mood, coping, and immune change in respons" doi:10.1037/0022-3514.74.6.1646]
* [Svenson (1981) "Are we less risky and more skillful than our fellow drivers?" doi:10.1016/0001-6918(81)90005-6]
* [Swann (1987) "The cognitive-affective crossfire: When self-consistency confronts sel" doi:10.1037/0022-3514.52.5.881]
* [Taylor (1983) "Adjustment to threatening events: A theory of cognitive adaptation" doi:10.1037/0003-066X.38.11.1161]
* [Taylor (1988) "Illusion and well-being: A social psychological perspective on mental " doi:10.1037/0033-2909.103.2.193]
* [Taylor (1992) "Optimism, coping, psychological distress, and high-risk sexual behavio" doi:10.1037/0022-3514.63.3.460]
* [Taylor (1994) "Positive illusions and well-being revisited: Separating fact from fict" doi:10.1037/0033-2909.116.1.21]
* [Taylor (1995) "Effects of mindset on positive illusions" doi:10.1037/0022-3514.69.2.213]
* [Taylor (1996) "Positive illusions and coping with adversity" doi:10.1111/j.1467-6494.1996.tb00947.x]
* [Taylor (2000) "Psychological resources, positive illusions, and health" doi:10.1037/0003-066X.55.1.99]
* [Wenger (2008) "Positive Illusions in Parenting: Every Child Is Above Average" doi:10.1111/j.1559-1816.2007.00319.x]
*[Yang (2009) "Long-Term Costs of Inflated Self-Estimate on Academic Performance Amon" doi:10.2466/PR0.105.3.727-737]

### Paragraph (raw wikitext)
```
==References==
{{refbegin|32em}}
* {{cite journal|last1=Adelson|first1=Rachel|title=Probing the puzzling workings of 'depressive realism'|journal=Monitor on Psychology|date=2005|volume=36|issue=4|page=30|url=http://www.apa.org/monitor/apr05/realism.aspx}}
* {{cite journal | last1 = Alicke | first1 = M.D. | year = 1985 | title = Global self-evaluation as determined by the desirability and controllability of trait adjectives | journal = Journal of Personality and Social Psychology | volume = 49 | issue = 6| pages = 1621–1630 | doi = 10.1037/0022-3514.49.6.1621  }}
* Alicke, M.D., & Govorun, O. (2005). "The better-than-average effect." In M.D. Alicke, D.A. Dunning, & J.I. Krueger (Eds.), ''The self in social judgment'' (pp.&nbsp;85 –108). Hove: Psychology.
* {{cite journal |last1=Allan |first1=LG |last2= Siegel|first2=S |last3=Hannah |first3=S |year=2007 |title= The sad truth about depressive realism |journal=The Quarterly Journal of Experimental Psychology |volume=60|issue=3 |pages=482–495 |url=http://psych.mcmaster.ca/hannahsd/pubs/AllanSiegelHannah%2707.pdf |ref={{harvid|Allan et al.|2007}} |doi=10.1080/17470210601002686 |pmid=17366313|s2cid=17018149 }}
* {{cite book|doi=10.1016/S0065-2601(08)60386-X|chapter=Situated Optimism: Specific Outcome Expectancies and Self-Regulation|title=Advances in Experimental Social Psychology|volume=30|pages=309–379|year=1998|last1=Armor|first1=David A.|last2=Taylor|first2=Shelley E.|isbn=9780120152308|chapter-url=http://behaviorchangeresearchnetwork.pbworks.com/w/file/fetch/48703842/Armor%20Taylor%201998.pdf|publisher=Elsevier}}
* {{cite book|doi=10.1017/CBO9780511808098.021|chapter=When Predictions Fail: The Dilemma of Unrealistic Optimism|title=Heuristics and Biases: The Psychology of Intuitive Judgment|pages=334–347|year=2002|last1=Armor|first1=David A.|last2=Taylor|first2=Shelley E.|isbn=9780511808098|editor1=T. Gilovich |editor2=D. Griffin |editor3=D. Kahneman|publisher=Cambridge University Press}}
* {{cite journal| last=Baumeister |first= R.F. |year=1989 |title= The optimal margin of illusion |journal=Journal of Social and Clinical Psychology |volume=8 |issue= 2 |pages= 176–189 |doi=10.1521/jscp.1989.8.2.176}}
* {{Cite journal|last1=Biglan|first1=Anthony|last2=Flay|first2=Brian R.|last3=Embry|first3=Dennis D.|last4=Sandler|first4=Irwin N.|date=2012|title=The Critical Role of Nurturing Environments for Promoting Human Wellbeing|journal=The American Psychologist|volume=67|issue=4|pages=257–271|doi=10.1037/a0026796|pmc=3621015|pmid=22583340}}
* {{cite journal |title=Depressive Realism: Happiness or Objectivity |journal=Turkish Journal of Psychiatry |year=2010 |volume=21 |issue=1 |pages=60–67 |url=http://www.turkpsikiyatri.com/PDF/C21S1/en/06.pdf |archive-url=https://web.archive.org/web/20120316133440/http://www.turkpsikiyatri.com/PDF/C21S1/en/06.pdf |url-status=dead |archive-date=2012-03-16 |pmid=20204905|last1=Birinci |first1=F |last2=Dirik |first2=G }}
* {{cite journal|pmid=15982117|year=2005|last1=Bonanno|first1=G. A.|title=Self-enhancement among high-exposure survivors of the September 11th terrorist attack: Resilience or social maladjustment?|journal=Journal of Personality and Social Psychology|volume=88|issue=6|pages=984–98|last2=Rennicke|first2=C|last3=Dekel|first3=S|doi=10.1037/0022-3514.88.6.984}}
* {{cite journal | last1 = Bower | first1 = J.E. | year = 1998 | title = Cognitive processing, discovery of meaning, CD 4 decline, and AIDS-related mortality among bereaved HIV-seropositive men | journal = Journal of Consulting and Clinical Psychology | volume = 66 | issue = 6| pages = 979–986  | doi = 10.1037/0022-006X.66.6.979 | pmid = 9874911 | last2 = Kemeny | first2 = ME | last3 = Taylor | first3 = SE | last4 = Fahey | first4 = JL  }}
* {{cite journal| first1=Belinda M. |last1=Boyd-Wilson |first2=Frank H. |last2=Walkey |first3= John|last3=McClure |first4= Dianne E. |last4=Green |date=December 2000 |title= Do we need positive illusions to carry out plans? Illusion: and instrumental coping |journal=Personality and Individual Differences| volume=29|issue= 6|pages= 1141–1152| doi=10.1016/S0191-8869(99)00261-5 |ref={{harvid|Boyd-Wilson et al.|2000}}}}
* {{cite journal | last1 = Brown | first1 = J.D. | year = 1986 | title = Evaluations of self and others: Self-enhancement biases in social judgements | journal = Social Cognition | volume = 4 | issue = 4| pages = 353–376 | doi = 10.1521/soco.1986.4.4.353  }}
*{{cite journal|doi=10.1037/0022-3514.67.3.366|title=Exploring the "planning fallacy": Why people underestimate their task completion times|journal=Journal of Personality and Social Psychology|volume=67|issue=3|pages=366–381|year=1994|last1=Buehler|first1=Roger|last2=Griffin|first2=Dale|last3=Ross|first3=Michael|s2cid=4222578}}
* {{cite journal | last1 = Campbell | first1 = J.D. | year = 1986 | title = Similarity and uniqueness: The effects of attribute type, relevance, and individual differences in self-esteem and depression | journal = Journal of Personality and Social Psychology | volume = 50 | issue = 2| pages = 281–294 | doi = 10.1037/0022-3514.50.2.281 | pmid = 3701578 }}
* {{cite journal|last1=Carson |first1=Richard C. |first2= Steven D. |last2=Hollon |first3= Richard C. |last3=Shelton |date=April 2010 |title= Depressive realism and clinical depression |journal=Behaviour Research and Therapy |volume=48 | issue=4  |pages=257–265 |ref={{harvid|Carson et al.|2010}} |doi=10.1016/j.brat.2009.11.011 |pmid=19963207}}
* {{cite journal |title=Do positive illusions foster mental health? An Examination of the Taylor and Brown Formulation |journal=Psychological Bulletin |year=1994 |volume=116 |issue=1 |pages=3–20 |url=http://www.radford.edu/~jaspelme/_private/gradsoc_articles/Depressive%20Realism/Covin%20n%20Block%20review.pdf |doi=10.1037/0033-2909.116.1.3 |pmid=8078973 |last1=Colvin |first1=C. R. |last2=Block |first2=J |access-date=2010-12-28 |archive-url=https://web.archive.org/web/20120304035204/http://www.radford.edu/~jaspelme/_private/gradsoc_artic
```

### Full section (plain rendering)
==References==

* [Adelson (2005) "Probing the puzzling workings of 'depressive realism'"]
* [Alicke (1985) "Global self-evaluation as determined by the desirability and controlla" doi:10.1037/0022-3514.49.6.1621]
* Alicke, M.D., & Govorun, O. (2005). "The better-than-average effect." In M.D. Alicke, D.A. Dunning, & J.I. Krueger (Eds.), The self in social judgment (pp.&nbsp;85 –108). Hove: Psychology.
* [Allan (2007) "The sad truth about depressive realism" doi:10.1080/17470210601002686]
* [Armor (1998) "Advances in Experimental Social Psychology" doi:10.1016/S0065-2601(08)60386-X]
* [Armor (2002) "Heuristics and Biases: The Psychology of Intuitive Judgment" doi:10.1017/CBO9780511808098.021]
* [Baumeister (1989) "The optimal margin of illusion" doi:10.1521/jscp.1989.8.2.176]
* [Biglan (2012) "The Critical Role of Nurturing Environments for Promoting Human Wellbe" doi:10.1037/a0026796]
* [Birinci (2010) "Depressive Realism: Happiness or Objectivity"]
* [Bonanno (2005) "Self-enhancement among high-exposure survivors of the September 11th t" doi:10.1037/0022-3514.88.6.984]
* [Bower (1998) "Cognitive processing, discovery of meaning, CD 4 decline, and AIDS-rel" doi:10.1037/0022-006X.66.6.979]
* [Boyd-Wilson (2000) "Do we need positive illusions to carry out plans? Illusion: and instru" doi:10.1016/S0191-8869(99)00261-5]
* [Brown (1986) "Evaluations of self and others: Self-enhancement biases in social judg" doi:10.1521/soco.1986.4.4.353]
*[Buehler (1994) "Exploring the "planning fallacy": Why people underestimate their task " doi:10.1037/0022-3514.67.3.366]
* [Campbell (1986) "Similarity and uniqueness: The effects of attribute type, relevance, a" doi:10.1037/0022-3514.50.2.281]
* [Carson (2010) "Depressive realism and clinical depression" doi:10.1016/j.brat.2009.11.011]
* [Colvin (1994) "Do positive illusions foster mental health? An Examination of the Tayl" doi:10.1037/0033-2909.116.1.3]
* [Compton (1992) "Are positive illusions necessary for self-esteem: a research note" doi:10.1016/0191-8869(92)90177-Q]
* {{cite journal | last1 = Coyne | first1 = J.C. | last2 = Gotlib | first2 = I. H. | year = 1983 | title = The role of cognition in depression: A critical appraisal | jour

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 098f4d519687b4aed607/article_plain.txt in the evidence directory.)

- There are controversies about the extent to which people reliably demonstrate positive illusions, as well as whether these illusions are beneficial to the people who have them. [ref: harvnb|Kruger|Chan|Roese|2009.] [ref: harvnb|McKay|Dennett|2009.] [ref: harvnb|Colvin|Block|1994.] [ref: harvnb|Birinci|Dirik|2010.]
- ==Benefits and liabilities==
Positive illusions can have advantages and disadvantages for the individual, and there is a controversy over whether they are evolutionarily adaptive. [ref: harvnb|McKay|Dennett|2009.] The illusions may have direct health benefits by helping the person cope with stress, or by promoting work towards success. [ref: harvnb|McKay|Dennett|2009.] On the other hand, unrealistically positive expectations may prevent people from taking sensible preventive action for medical risks. [ref: harvnb|Dunning|Heath|Suls|2004.] Research in 2001 provided evidence that people who have positive illusions may have both short term benefits and long term costs. Specifically, self-enhancement is not correlated with academic success or graduation rates in college. [ref: harvnb|Robins|Beer|2001.]
- When studying the link between self-esteem and positive illusions, identified a group which possessed high self-esteem without positive illusions, and that these individuals weren't depressed, neurotic, psychotic, maladjusted nor personality disordered, thus concluding that positive illusions aren't necessary for high self-esteem. Compared to the group with positive illusions and high self-esteem, the nonillusional group with high self-esteem was higher on self-criticism and personality integration and lower on psychoticism. [ref: Harvnb|Compton|1992.]
- A meta-analysis of 118 studies including 7013 subjects found that slightly more studies supported the idea of depressive realism, but these studies were poorer in quality, used non-clinical samples, were more readily generalized, used self-reports instead of interviews and used attentional bias or judgment of contingency as a method of measuring depressive realism, as methods such as recall of feedback and evaluation of performance showed results counter to depressive realism.
- Another recent meta-analysis supports Taylor and Browns central claim. Its results indicate that different forms of self-enhancement are positively linked to personal adjustment (high subjective well-being and low depressiveness). Self-enhancement was not only linked to self-ratings of personal adjustment, but also to adjustment ratings made by informants (including clinical experts). Furthermore, self-enhancement was also a longitudinal predictor of personal adjustment.
- However, these findings may not be because depressed people have fewer illusions than people who are not depressed. Studies such as show that depressed people believe they have no control in situations where they actually do, so their perspection is not more accurate overall. It might also be that the pessimistic bias of depressives results in "depressive realism" when, for example, measuring estimation of control when there is none, as proposed by . Also, and found that when replicating Alloy and Abramson's findings the overestimation of control in nondepressed people only showed up when the interval was long enough, implying that this is because they take more aspects of a situation into account than their depressed counterparts.
- * [Adelson (2005) "Probing the puzzling workings of 'depressive realism'"]
* [Alicke (1985) "Global self-evaluation as determined by the desirability and controlla" doi:10.1037/0022-3514.49.6.1621]
* Alicke, M.D., & Govorun, O. (2005). "The better-than-average effect." In M.D. Alicke, D.A. Dunning, & J.I. Krueger (Eds.), The self in social judgment (pp.&nbsp;85 –108). Hove: Psychology.
* [Allan (2007) "The sad truth about depressive realism" doi:10.1080/17470210601002686]
* [Armor (1998) "Advances in Experimental Social Psychology" doi:10.1016/S0065-2601(08)60386-X]
* [Armor (2002) "Heuristics and Biases: The Psychology of Intuitive Judgment" doi:10.1017/CBO9780511808098.021]
* [Baumeister (1989) "The optimal margin of illusion" doi:10.1521/jscp.1989.8.2.176]
* [Biglan (2012) "The Critical Role of Nurturing Environments for Promoting Human Wellbe" doi:10.1037/a0026796]
* [Birinci (2010) "Depressive Realism: Happiness or Objectivity"]
* [Bonanno (2005) "Self-enhancement among high-exposure survivors of the September 11th t" doi:10.1037/0022-3514.88.6.984]
* [Bower (1998) "Cognitive processing, discovery of meaning, CD 4 decline, and AIDS-rel" doi:10.1037/0022-006X.66.6.979]
* [Boyd-Wilson (2000) "Do we need positive illusions to carry out plans? Illusion: and instru" doi:10.1016/S0191-8869(99)00261-5]
* [Brown (1986) "Evaluations of self and others: Self-enhancement biases in social judg" doi:10.1521/soco.1986.4.4.353]
*[Buehler (1994) "Exploring the "planning fallacy": Why pe

## ORIGINAL STUDY: doi:10.1037/0022-3514.49.6.1621 (FLoRA title: Global self-evaluation as determined by the desirability and controllability of trait adjectives.)
Crossref: Global self-evaluation as determined by the desirability and controllability of trait adjectives. | Mark D. Alicke | Journal of Personality and Social Psychology | 1985 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W1979506848", "type": "article", "publication_year": 1985, "cited_by_count": 1032, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: METADATA_ONLY
Retrieved: 2026-10-09T12:19:01+00:00

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1177/1948550620948973 (FLoRA title: Replication and Extension of Alicke (1985) Better-Than-Average Effect for Desirable and Controllable Traits; FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: Replication and Extension of Alicke (1985) Better-Than-Average Effect for Desirable and Controllable Traits | Ignazio Ziano, Pui Yan (Cora) Mok, Gilad Feldman | Social Psychological and Personality Science | 2020 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W3087689742", "type": "article", "publication_year": 2020, "cited_by_count": 33, "is_retracted": false, "oa_status": "gold", "oa_pdf": null, "oa_landing": "https://osf.io/2y6wj"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_skill/10_1177_1948550620948973.txt (PDF via download-paper skill (fetchpdf open-access chain); may be a preprint or author manuscript)
Retrieved: 2026-10-09T12:19:02+00:00
### Abstract (Crossref deposited abstract)
People tend to regard themselves as better than average. We conducted a replication and extension of Alicke’s classic study on trait dimensions in evaluations of self versus others with U.S. American Mechanical Turk workers in two waves (total N = 1,573; 149 total traits). We successfully replicated the trait desirability effect, such that participants rated more desirable traits as being more descriptive of themselves than of others (original: [Formula: see text] = .78, 95% confidence interval [CI] [.73, .81]; replication: sr
                     2 
                    = .54, 95% CI [.43, .65]). The effect of desirability was stronger for more controllable traits (effect of Desirability × Controllability interaction on self–other-ratings difference; original: [Formula: see text] = .21, 95% CI [.12, .28]; replication: sr
                     2 
                    = .07, 95% CI [.02, .12]). In an extension, we found that desirable traits were rated as more common for others, but not for the self. Thirty-five years later, the better-than-average effect appears to remain robust. All materials, data, and code are available at https://osf.io/2y6wj/ .

## Other database studies cited on this same page (each has its own packet; drafted together)
- 56cb2612b28eac4d7fb7: Lake Wobegon be gone! The "below-average effect" and the egocentric nature of comparative ability judgments. (doi:10.1037/0022-3514.77.2.221)
- 8ae7ecd1c42737d7869c: Affective consequences of mere ownership: The name letter effect in twelve European languages (doi:10.1002/ejsp.2420170402)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1027/1864-9335/a000495 | Biased Social Comparison in the Moment of Crisis | 2022 | read: abstract | mentions replication: False
- doi:10.1016/j.jesp.2021.104222 | Numbing or sensitization? Replications and extensions of Fetherstonhaugh et al. (1997)'s “Insensitivity to the Value of Human Life” | 2021 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_1016_j_jesp_2021_104222.txt
  Snippet: an undergraduate students which were successfully replicated with mturk, even decades later. for instance, overestimation of others' willingness-to-pay (frederick, 2012) was successfully replicated on mturk (jung, moon, & nelson, 2019, study 3), and ziano et al. (2020) successfully replicated the above-average effect shown in alicke (1985). in order to increase the generalizability of both the original study and of the present replications, we conducted the replications of both studies also on prolif
  Snippet: sfully replicated a large number of judgment and decision making studies using mturk and prolific, with results consistent with student samples and each other (collaborative open-science research, 2020; chandrashekar et al., 2019; chen et al., 2020; ziano et al., 2020). overall, this supports the notion that both mturk and prolific are viable samples for a replication of the impactful findings in fetherstonhaugh et al. (1997). open science, pre-registrations, and disclosures materials, preregistratio
- doi:10.1017/s1930297500009189 | Both better and worse than others depending on difficulty: Replication and extensions of Kruger’s (1999) above and below average effects | 2022 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_1017_s1930297500009189.txt
  Snippet: 2020). expanding on self-enhancement, the self-verification theory describes that both self-enhancement and exposure to information which creates and strengthens a biased view of oneself can lead to phenomena such as the above-and-below-average 1see ziano et al. (2021) for a recent successful direct replication of alicke (1985), showing that people rate more desirable traits to be more descriptive of themselves than of others, and extending that the effect was stronger for more controllable traits. t
  Snippet: ckhouser, j. e., sedikides, c., & alicke, m. d. (2020). the better-than-average effect in comparative self-evaluation: a comprehensive review and meta-analysis. psychological bulletin, 146(2), 118-149. https://psycnet.apa.org/doi/10.1037/bul0000218. ziano, i., mok, p. y., & feldman, g. (2021). replication and extension of alicke (1985) better-than-average effect for desirable and controllable traits. social psychological and personality science, 12(6), 1005-1017. https://doi.org/10.1177/1948550620948
- doi:10.5334/spo.72 | Moral vs Agentic Self-Superiority and Self-Esteem: The Role of Trait Properties | 2024 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_5334_spo_72.txt
- doi:10.3389/fpsyg.2024.1367568 | The psychological mechanisms of the better-than-average effect in the moral and competence domains under self-enhancement and self-protection motives among young Japanese adults | 2024 | read: abstract | mentions replication: False

## Other papers relevant to this page that the pipeline looked up
- doi:10.1111/j.1745-6916.2008.00068.x | Self-Enhancement: Food for Thought | paper cited in the article (not a database study) | read: abstract
  Abstract (Crossref): Self-enhancement denotes a class of psychological phenomena that involve taking a tendentiously positive view of oneself. We distinguish between four levels of self-enhancement—an observed effect, an ongoing process, a personality trait, and an underlying motive—and then use these distinctions to organize the wealth of relevant research. Furthermore, to render these distinctions intuitive, we draw an extended analogy between self-enhancement and the phenomenon of eating. Among the topics we address are (a) manifestations of self-enhancement, both obvious and subtle, and rival interpretations; (b) experimentally documented dynamics of affirming and threatening the ego; and (c) primacy of self-enhancement, considered alongside other intrapsychic phenomena, and across different cultures. Self-enhancement, like eating, is a fundamental part of human nature.

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1146/annurev.psych.58.110405.085658 | Motivational and Emotional Aspects of the Self | 2006 | review | cited_by 842
  Abstract: Recent theory and research are reviewed regarding self-related motives (self-enhancement, self-verification, and self-expansion) and self-conscious emotions (guilt, shame, pride, social anxiety, and embarrassment), with an emphasis on how these motivational and emotional aspects of the self might be related. Specifically, these motives and emotions appear to function to protect people's social well-being. The motives to self-enhance, self-verify, and self-expand are partly rooted in people's concerns with social approval and acceptance, and self-conscious emotions arise in response to events that have real or imagined implications for others' judgments of the individual. Thus, these motives and emotions do not operate to maintain certain states of the self, as some have suggested, but rather to facilitate people's social interactions and relationships.
- [review citing original] doi:10.1080/15298860600805325 | Experimental manipulations of self-affirmation: A systematic review | 2006 | review | cited_by 567
  Abstract: The objective of this systematic review of studies using self-affirmation manipulations was to identify research gaps and provide information to guide future research. We describe study characteristics, categories of manipulations, and report effects on various dependent variables. Our search strategies yielded 47 eligible articles (69 studies). Manipulations varied by affirmation domain (values or personal characteristics), attainment (participant- or investigator-identified), and procedure (scale, essay, feedback, etc.). Most dependent variables were cognitive. Strong effects of self-affirmation were found for attitudes and persuasion/bias, but future work is needed for variables with mixed results including risk cognitions, intentions, and behavior. Suggestions and considerations for future research involving self-affirmation manipulations are discussed.
- [review citing original] doi:10.1108/rbf-01-2020-0020 | Overconfidence and financial decision-making: a meta-analysis | 2020 | review | cited_by 75
  Abstract: Purpose This meta-analysis reviews and summarizes the results of 34 studies to investigate the relationship between overconfidence and financial decision-making. Design/methodology/approach A correlation meta-analysis was conducted with three moderators of the relationship between overconfidence and financial decision-making examined: the type of overconfidence construct, the type of overconfidence measuring method and the type of financial decision-making. Findings It was found that the effect of overconfidence on financial decision-making was significant, but the magnitude of this effect was low. Additionally, indirect measures of overconfidence showed to have stronger effect than direct measures, and the overconfidence was mostly related to investment, followed by trading and innovativeness. Originality/value This was the first attempt to meta-analytically integrate results concerning the relationship between overconfidence and financial decision-making. Although overconfidence is described as a keystone for understanding financial decision-making, it was shown that it has rather limited effect on individuals' financial decisions. The findings suggest that indirect measures incr
- [review citing original] doi:10.1111/ijmr.12334 | The dark side of leadership: A systematic review of creativity and innovation | 2023 | review | cited_by 60
  Abstract: Abstract It is believed that workplace creativity and innovation are fostered by positive leader behaviors and positive workplace relationships and hindered by the opposite. However, some challenge this view and argue that creativity and innovation can also be fostered when employees experience what is increasingly referred to as “the dark side of leadership”. Research in this area is sparse, contradictory, and overly confusing. We provide a comprehensive systematic review of 106 empirical studies on this topic. We review research on a broad range of constructs, including abusive supervision, authoritarian leadership, narcissistic leadership, and close monitoring. As might be expected, a larger number of the articles reviewed found a negative relationship, but there are important discrepancies and details. Our review reports the main effects, summarizes the results of the mediating and moderating variables, and highlights methodological shortcomings of the previous literature. On this basis, several recommendations are made to advance this field of research.
- [cites original and replication 10.1177/1948550620948973] doi:10.1027/1864-9335/a000495 | Biased Social Comparison in the Moment of Crisis | 2022 | article | cited_by 9
  Abstract: Abstract. The better-than-average effect (BTAE) is a mechanism where people perceive oneself as better than others. The BTAE could be one of the phenomena explaining why people follow – in the moment of a global health crisis – guidelines (“I am superior to others, and I [will]) take extra precautions, e.g., a vaccine shot”). In this paper, we investigate the BTAE with 3,066 respondents. In Study 1, in all countries, across two measurements in time, the BTAE was present: Participants rated their involvement in self-protection as greater in comparison to others. Study 2 replicated this effect, proving its robustness. Participants estimated their willingness to vaccinate as higher than others. The BTAE was a significant predictor of willingness to vaccinate.
- [cites original and replication 10.1177/1948550620948973] doi:10.1016/j.jesp.2021.104222 | Numbing or sensitization? Replications and extensions of Fetherstonhaugh et al. (1997)'s “Insensitivity to the Value of Human Life” | 2021 | article | cited_by 8
  Abstract: Is it better to save 4500 lives out of 11,000 or 4500 lives out of 250,000? Fetherstonhaugh et al. (1997) showed that people prefer the former: to save lives if they are a higher proportion of the total, a phenomenon they termed “psychophysical numbing”. We attempted to replicate Studies 1 and 2 of Fetherstonhaugh et al. (1997) (5 data collections, total N = 4799, MTurk and Prolific, USA and UK), and added several extensions (e.g., donation amounts, procedural differences, and individual-level ideology and knowledge). We found mixed support, with two successful replications of Study 2 that indeed showed psychophysical numbing (original: η 2 p = 0.55, 90% CI [0.45, 0.62], Study 2a: η 2 p = 0.62, 90% CI [0.58, 0.66], Study 2b: η 2 p = 0.24, 90% CI [0.21, 0.27], all in same direction), yet also three unsuccessful replications of Study 1 showing instead an opposite psychophysical sensitization , a preference for saving a smaller proportion of lives (original effect size: η 2 p = 0.14, 90% CI [0.02, 0.28], replications: Study 1a: η 2 p = 0.06, 90% CI [0.02, 0.10], Study 1b: η 2 p = 0.21, 90% CI [0.17, 0.26]; Study 1c: η 2 p = 0.13, 90% CI [0.08, 0.17], all in the opposite direction). We
- [cites original and replication 10.1177/1948550620948973] doi:10.1017/s1930297500009189 | Both better and worse than others depending on difficulty: Replication and extensions of Kruger’s (1999) above and below average effects | 2022 | article | cited_by 7
  Abstract: Abstract Above-and-below-average effects are well-known phenomena that arise when comparing oneself to others. Kruger (1999) found that people rate themselves as above average for easy abilities and below average for difficult abilities. We conducted a successful pre-registered replication of Kruger’s (1999) Study 1, the first demonstration of the core phenomenon (N = 756, US MTurk workers). Extending the replication to also include a between-subject design, we added two conditions manipulating easy and difficult interpretations of the original ability domains, and with an additional dependent variable measuring perceived difficulty. We observed an above-average-effect in the easy extension and below-average-effect in the difficult extension, compared to the neutral replication condition. Both extension conditions were perceived as less ambiguous than the original neutral condition. Overall, we conclude strong empirical support for Kruger’s above-and-below-average effects, with boundary conditions laid out in the extensions expanding both generalizability and robustness of the phenomenon.
- [cites original and replication 10.1177/1948550620948973] doi:10.5334/spo.72 | Moral vs Agentic Self-Superiority and Self-Esteem: The Role of Trait Properties | 2024 | article | cited_by 4
  Abstract: People generally believe that they are better than others. This perceived self-superiority is stronger for moral (vs agentic) traits, whereas self-esteem mainly correlates with individual differences in agentic self-superiority beliefs. We replicated these seemingly contradictory findings within a single design in two studies that also examined the role of various properties of moral and agentic traits (controllability, verifiability, frequency of feedback, ambiguity, breadth, being typically human, taken-for-grantedness). The morality-agency difference in perceived self-superiority was partially mediated by the differential controllability, being typically human, and taken-for-grantedness of moral and agentic traits, but the lower verifiability of moral traits suppressed, rather than accounted for, the greater strength of moral self-superiority (Study 2). The stronger correlation between agentic self-superiority beliefs and self-esteem was moderated by differences between the traits’ controllability, verifiability, and being typically human (Study 2). Participants with low self-esteem showed self-superiority beliefs on morality traits only, whereas those with higher self-esteem al
- [cites original and replication 10.1177/1948550620948973] doi:10.3389/fpsyg.2024.1367568 | The psychological mechanisms of the better-than-average effect in the moral and competence domains under self-enhancement and self-protection motives among young Japanese adults | 2024 | article | cited_by 3
  Abstract: The better-than-average effect (BTAE) refers to the phenomenon where individuals perceive themselves as better than the average person. This effect has been independently examined in terms of social perception dimension and motivation. Additionally, no psychobehavioral traits have been found to be associated with the BTAE in the moral domain. However, the interactive effects of social perception dimension and motivation on the BTAE remain unclear, and its association with a broad range of psychobehavioral traits has not been extensively validated. In this study, we assess self-and average other-evaluations across four domains, based on two social perception dimensions and two motivations, to investigate their interactive effects on the BTAE ( n = 678). We measured seven sets of psychobehavioral characteristics to examine their association with the BTAE, as well as self-and other-evaluations. Results indicated that the BTAE occurred only under negative moral conditions, while the worse-than-others effect was observed under two competence conditions. Furthermore, the BTAE was associated with only a few psychobehavioral characteristics in the moral domains, compared to many in the com
