# Evidence packet 4031a6c18f78687c2ec3: CASS4

Frozen revision: 1367140079 (2026-08-01T06:44:47Z); https://en.wikipedia.org/w/index.php?oldid=1367140079
Live check: {"frozen_revid": "1367140079", "title": "CASS4", "live_revid": 1367140079, "live_timestamp": "2026-08-01T06:44:47Z", "checked_at": "2026-10-06T16:46:56+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "biomedical", "context_kind": "list", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 1}

## Article lead (plain rendering, approximate)
Cas scaffolding protein family member 4 is a protein that in humans is encoded by the CASS4 gene. [ref: "Entrez Gene: Cas scaffolding protein family member 4"]

## Article outline
History and discovery
Gene
Protein family
Structure
Function
Disease association
  Cancer
  Alzheimer's disease
  Immunopathological conditions
    Cystic fibrosis
  Thrombosis
Clinical significance
Notes
References
External links

## Categories
Proteins

## Occurrence 1: original (named-reference reuse) DOI 10.1038/ng.2802 in section 'Disease association'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
== Disease association ==
Altered expression or modification of CASS4 has been proposed as relevant to several human pathologies, typically based on detection of changes in CASS4 in high throughput screening, although the role of CASS4 in the pathology of these conditions has not yet been studied directly. These findings are summarized in Table 1; some examples are provided below.
{| class="wikitable"
|+Table 1. CASS4 disease association 
!Screen purpose
!Observation
|-
| rowspan="5" |Alzheimer's disease
|SNP rs7274581 T/C linked to risk.
Odds ratio 0.72; p-value 0.011. [ref: (2014) "Genome-wide association meta-analysis of neuropathologic features of A" doi:10.1371/journal.pgen.1004606]
|-
|SNP rs7274581 T/C linked to risk.
Odds ratio 0.88; p-value 2.5*10−8. [FOCAL REF: (2013) "Meta-analysis of 74,046 individuals identifies 11 new susceptibility l" doi:10.1038/ng.2802]
|-
|SNP rs7274581 T/C linked to risk
Odds ratio 0.8888; p-value 1.75 ×10−7. [ref: (2014) "Follow-up of loci from the International Genomics of Alzheimer's Disea" doi:10.1038/tp.2014.2]
|-
|SNP rs6024870, RegulomeDB [ref: "Search RegulomeDB"] score 2b, which means that this SNP is likely to affect transcription factor binding. [ref: (2014) "Connecting the dots: potential of data integration to identify regulat" doi:10.1371/journal.pone.0095152]
|-
|SNP rs16979934 T/G linked to risk.
Odds ratio 0.5956; p-value 0.03. [ref: (2015) "Genetic determinants of disease progression in Alzheimer's disease" doi:10.3233/JAD-140729]
|-
|Atopic asthma
|Upregulated in eosinophils post antigen exposure. [ref: (2013) "Identification of genes expressed by human airway eosinophils after an" doi:10.1371/journal.pone.0067560]
|-
|Cystic fibrosis
|Possible correlation with severity of the lung manifestation of the disease (according to GWAS). [ref: (2011) "Genome-wide association and linkage identify modifier loci of lung dis" doi:10.1038/ng.838]
|-
|Non-small cell lung cancer
|Overexpression is associated with lymph node metastasis, high TNM stage and poor prognosis. [ref: (2013) "Overexpression and cytoplasmic accumulation of Hepl is associated with" doi:10.1007/s13277-012-0517-x]
|-
|Phosphoproteome of resting human platelets
|Identified S305 phosphorylation by PKA/PKG in the unstructured region containing SH2-binding sites of CASS4. [ref: (2008) "Phosphoproteome of resting human platelets" doi:10.1021/pr0704130]
|-
|Platelet activation by oxidized phospholipids
|CASS4 S249 phosphorylation in the unstructured region containing SH2-binding sites is induced by oxidized phospholipid KODA-PC in platelets. [ref: (2014) "Phosphoproteomic analysis of platelets activated by pro-thrombotic oxi" doi:10.1371/journal.pone.0084488]
|}

### Paragraph (raw wikitext)
```
== Disease association ==
Altered expression or modification of CASS4 has been proposed as relevant to several human pathologies, typically based on detection of changes in CASS4 in high throughput screening, although the role of CASS4 in the pathology of these conditions has not yet been studied directly.  These findings are summarized in Table 1; some examples are provided below.
{| class="wikitable"
|+'''Table 1.''' CASS4 disease association 
!Screen purpose
!Observation
|-
| rowspan="5" |[[Alzheimer's disease]]
|[[Single-nucleotide polymorphism|SNP]] rs7274581 T/C linked to risk.<br />
Odds ratio 0.72; p-value 0.011.<ref name="Beecham_2014" />
|-
|[[Single-nucleotide polymorphism|SNP]] rs7274581 T/C linked to risk.<br />
Odds ratio 0.88; p-value 2.5*10<sup>−8</sup>.<ref name="Lambert_2013" />
|-
|[[Single-nucleotide polymorphism|SNP]] rs7274581 T/C linked to risk<br />
Odds ratio 0.8888; p-value 1.75 ×10<sup>−7</sup>.<ref name="Ruiz_2014" />
|-
|[[Single-nucleotide polymorphism|SNP]] rs6024870, RegulomeDB<ref>{{cite web|url=http://regulomedb.org/ |title=Search RegulomeDB |publisher=Regulomedb.org |date= |access-date=2016-01-30}}</ref> score 2b, which means that this SNP is likely to affect transcription factor binding.<ref name="Rosenthal_2014" />
|-
|[[Single-nucleotide polymorphism|SNP]] rs16979934 T/G linked to risk.
Odds ratio 0.5956; p-value 0.03.<ref name="Wang_2015" />
|-
|Atopic [[asthma]]
|Upregulated in eosinophils post antigen exposure.<ref name="Esnault_2013" />
|-
|[[Cystic fibrosis]]
|Possible correlation with severity of the lung manifestation of the disease (according to GWAS).<ref name="Wright_2011" />
|-
|[[Non-small-cell lung carcinoma|Non-small cell lung cancer]]
|Overexpression is associated with lymph node metastasis, high [[TNM staging system|TNM stage]] and poor prognosis.<ref name="Miao_2013" />
|-
|Phosphoproteome of resting human platelets
|Identified S305 phosphorylation by [[Protein kinase A|PKA]]/[[CGMP-dependent protein kinase|PKG]] in the unstructured region containing [[SH2 domain|SH2]]-binding sites of CASS4.<ref name="Zahedi_2008" />
|-
|Platelet activation by oxidized phospholipids
|CASS4 S249 phosphorylation in the unstructured region containing [[SH2 domain|SH2]]-binding sites is induced by oxidized phospholipid KODA-PC in platelets.<ref name="Zimman_2014" />
|}
```

### Full section (plain rendering)
== Disease association ==
Altered expression or modification of CASS4 has been proposed as relevant to several human pathologies, typically based on detection of changes in CASS4 in high throughput screening, although the role of CASS4 in the pathology of these conditions has not yet been studied directly. These findings are summarized in Table 1; some examples are provided below.
{| class="wikitable"
|+Table 1. CASS4 disease association 
!Screen purpose
!Observation
|-
| rowspan="5" |Alzheimer's disease
|SNP rs7274581 T/C linked to risk.
Odds ratio 0.72; p-value 0.011. [ref: (2014) "Genome-wide association meta-analysis of neuropathologic features of A" doi:10.1371/journal.pgen.1004606]
|-
|SNP rs7274581 T/C linked to risk.
Odds ratio 0.88; p-value 2.5*10−8. [FOCAL REF: (2013) "Meta-analysis of 74,046 individuals identifies 11 new susceptibility l" doi:10.1038/ng.2802]
|-
|SNP rs7274581 T/C linked to risk
Odds ratio 0.8888; p-value 1.75 ×10−7. [ref: (2014) "Follow-up of loci from the International Genomics of Alzheimer's Disea" doi:10.1038/tp.2014.2]
|-
|SNP rs6024870, RegulomeDB [ref: "Search RegulomeDB"] score 2b, which means that this SNP is likely to affect transcription factor binding. [ref: (2014) "Connecting the dots: potential of data integration to identify regulat" doi:10.1371/journal.pone.0095152]
|-
|SNP rs16979934 T/G linked to risk.
Odds ratio 0.5956; p-value 0.03. [ref: (2015) "Genetic determinants of disease progression in Alzheimer's disease" doi:10.3233/JAD-140729]
|-
|Atopic asthma
|Upregulated in eosinophils post antigen exposure. [ref: (2013) "Identification of genes expressed by human airway eosinophils after an" doi:10.1371/journal.pone.0067560]
|-
|Cystic fibrosis
|Possible correlation with severity of the lung manifestation of the disease (according to GWAS). [ref: (2011) "Genome-wide association and linkage identify modifier loci of lung dis" doi:10.1038/ng.838]
|-
|Non-small cell lung cancer
|Overexpression is associated with lymph node metastasis, high TNM stage and poor prognosis. [ref: (2013) "Overexpression and cytoplasmic accumulation of Hepl is associated with" doi:10.1007/s13277-012-0517-x]
|-
|Phosphoproteome of resting human platelets
|Identified S305 phosphorylation by PKA/PKG in the unstructured region containing SH2-binding sites of CASS4. [ref: (2008) "Phosphoproteome of resting human platelets" doi:10.1021/pr0704130]
|-
|Platelet activation by oxidized phospholipids
|CASS4 S249 phosphorylation in the unstructured region containing SH2-binding sites is induced by oxidized phospholipid KODA-PC in platelets. [ref: (2014) "Phosphoproteomic analysis of platelets activated by pro-thrombotic oxi" doi:10.1371/journal.pone.0084488]
|}

=== Cancer ===
Many CAS family proteins have altered activity and functional roles in cancer progression and metastasis, with functional roles in influencing cellular adhesion, migration and drug resistance. [ref: (2014) "Cas proteins: dodgy scaffolding in breast cancer" doi:10.1186/s13058-014-0443-5] [ref: (2014) "CAS proteins in health and disease: an update" doi:10.1002/iub.1282] Changes in CASS4 may also be associated with human malignancies. CASS4 function was linked to non-small cell lung cancer (NSCLC) in a study by Miao et al. that correlated elevated CASS4 expression with lymph node metastasis and high TNM stage. [ref: (2013) "Overexpression and cytoplasmic accumulation of Hepl is associated with" doi:10.1007/s13277-012-0517-x] In addition, this study detected a significant difference in cytoplasmic accumulation of CASS4 protein between high (H1299 and BE1) and low (LTE and A549) metastatic potential lung cancer cell lines. These may suggest CASS4 as a possible prognostic marker in clinical management of NSCLC.

=== Alzheimer's disease ===
CASS4 and corresponding SNP - rs7274581 T/C has been identified in a large meta-analysis as a locus for lower susceptibility to Alzheimer's disease (AD). [FOCAL REF: (2013) "Meta-analysis of 74,046 individuals identifies 11 new susceptibility l" doi:10.1038/ng.2802] [ref: "IGAP Summary Statistics"] However this SNP was not found predictive in a follow-up study. [ref: (2014) "Follow-up of loci from the International Genomics of Alzheimer's Disea" doi:10.1038/tp.2014.2]

In a genome wide association screen (GWAS), CASS4 showed a significant correlation with clinical pathological features of AD such as neurofibrillary tangles and neuritic plaques. [ref: (2014) "Genome-wide association meta-analysis of neuropathologic features of A" doi:10.1371/journal.pgen.1004606] Two additional CASS4 SNPs were reported to be associated with AD susceptibility: rs6024870, [ref: (2014) "Connecting the dots: potential of data integration to identify regulat" doi:10.1371/journal.pone.0095152] and rs16979934 T/G. [ref: (2015) "Genetic determinants of disease progression in Alzheimer's disease" doi:10.3233/JAD-140729] Given the likely conserved CAS-family cytoskeletal function of CASS4, it has been speculated that it may have a role in axonal transport and influence the expression of the amyloid precursor protein (APP) and tau, which are pathologically affected in AD. [ref: (2015) "Alzheimer's disease risk genes and mechanisms of disease pathogenesis" doi:10.1016/j.biopsych.2014.05.006] Several possible mechanisms for CASS4 action in AD have been proposed. [ref: (2014) "Adaptors for disorders of the brain? The cancer signaling proteins NED" doi:10.18632/oncoscience.64]

=== Immunopathological conditions ===
An association of CASS4 with atopic asthma has been shown. [ref: (2013) "Identification of genes expressed by human airway eosinophils after an" doi:10.1371/journal.pone.0067560] CASS4 has also been reported to be an eosinophil-associated gene, with expression in sputum cells increased more than 1.5-fold after whole lung allergen challenge. Moreover, the CASS4 mRNA was upregulated in cells collected by bronchoalveolar lavage after segmental broncho-provocation with an allergen. Reciprocally, the CASS4 mRNA was downregulated when this procedure was performed following administration of mepolizumab (a humanized monoclonal anti-IL-5 antibodies which reduces excessive eosinophilia). This suggests CASS4 activity may be associated with immune response in the context of atopic asthma development.

==== Cystic fibrosis ====
CASS4 has been reported to play a modifying role in cystic fibrosis severity, progression and comorbid conditions. [ref: (2011) "Genome-wide association and linkage identify modifier loci of lung dis" doi:10.1038/ng.838] The CAS family member NEDD9 has also been shown to interact directly with AURKA (encoding Aurora-A kinase) to regulate cell cycle [ref: (2005) "The focal adhesion scaffolding protein HEF1 regulates activation of th" doi:10.1038/ncb1309] and ciliary resorption; [ref: (2007) "HEF1-dependent Aurora A activation induces disassembly of the primary " doi:10.1016/j.cell.2007.04.035] it is possible that CASS4 may similarly interact with aurora-A kinase.

=== Thrombosis ===
CASS4 signaling may contribute to platelet activation and aggregation. A PKA/PKG phosphorylation site has been identified in CASS4 on residue S305 in the unstructured domain containing SH2-binding motifs; the functional significance of this phosphorylation is currently unknown. [ref: (2008) "Phosphoproteome of resting human platelets" doi:10.1021/pr0704130] Significantly increased phosphorylation on S249 of CASS4, also in the unstructured domain, after platelet stimulation with the oxidized phospholipid KODA-PC (9-keto-12-oxo-10-dodecenoic acid ester of 2-lyso-phosphocholine, a CD36 receptor agonist) versus thrombin treatment, which may implicate CASS4 mediated signaling in platelet hyperreactivity. [ref: (2014) "Phosphoproteomic analysis of platelets activated by pro-thrombotic oxi" doi:10.1371/journal.pone.0084488]

## Occurrence 2: original (named-reference reuse) DOI 10.1038/ng.2802 in section 'Alzheimer's disease'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
=== Alzheimer's disease ===
CASS4 and corresponding SNP - rs7274581 T/C has been identified in a large meta-analysis as a locus for lower susceptibility to Alzheimer's disease (AD). [FOCAL REF: (2013) "Meta-analysis of 74,046 individuals identifies 11 new susceptibility l" doi:10.1038/ng.2802] [ref: "IGAP Summary Statistics"] However this SNP was not found predictive in a follow-up study. [ref: (2014) "Follow-up of loci from the International Genomics of Alzheimer's Disea" doi:10.1038/tp.2014.2]

### Paragraph (raw wikitext)
```
=== Alzheimer's disease ===
CASS4 and corresponding [[Single-nucleotide polymorphism|SNP]] - rs7274581 T/C has been identified in a large meta-analysis as a locus for lower susceptibility to [[Alzheimer's disease]] (AD).<ref name="Lambert_2013"/><ref name="urlIGAP Summary Statistics"/>  However this SNP was not found predictive in a follow-up study.<ref name="Ruiz_2014"/>
```

### Full section (plain rendering)
=== Alzheimer's disease ===
CASS4 and corresponding SNP - rs7274581 T/C has been identified in a large meta-analysis as a locus for lower susceptibility to Alzheimer's disease (AD). [FOCAL REF: (2013) "Meta-analysis of 74,046 individuals identifies 11 new susceptibility l" doi:10.1038/ng.2802] [ref: "IGAP Summary Statistics"] However this SNP was not found predictive in a follow-up study. [ref: (2014) "Follow-up of loci from the International Genomics of Alzheimer's Disea" doi:10.1038/tp.2014.2]

In a genome wide association screen (GWAS), CASS4 showed a significant correlation with clinical pathological features of AD such as neurofibrillary tangles and neuritic plaques. [ref: (2014) "Genome-wide association meta-analysis of neuropathologic features of A" doi:10.1371/journal.pgen.1004606] Two additional CASS4 SNPs were reported to be associated with AD susceptibility: rs6024870, [ref: (2014) "Connecting the dots: potential of data integration to identify regulat" doi:10.1371/journal.pone.0095152] and rs16979934 T/G. [ref: (2015) "Genetic determinants of disease progression in Alzheimer's disease" doi:10.3233/JAD-140729] Given the likely conserved CAS-family cytoskeletal function of CASS4, it has been speculated that it may have a role in axonal transport and influence the expression of the amyloid precursor protein (APP) and tau, which are pathologically affected in AD. [ref: (2015) "Alzheimer's disease risk genes and mechanisms of disease pathogenesis" doi:10.1016/j.biopsych.2014.05.006] Several possible mechanisms for CASS4 action in AD have been proposed. [ref: (2014) "Adaptors for disorders of the brain? The cancer signaling proteins NED" doi:10.18632/oncoscience.64]

## Occurrence 3: original DOI 10.1038/ng.2802 in section 'References'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
[FOCAL REF: (2013) "Meta-analysis of 74,046 individuals identifies 11 new susceptibility l" doi:10.1038/ng.2802]

### Paragraph (raw wikitext)
```
<ref name = "Lambert_2013">{{cite journal | vauthors = Lambert JC, Ibrahim-Verbaas CA, Harold D, Naj AC, Sims R, Bellenguez C, DeStafano AL, Bis JC, Beecham GW, Grenier-Boley B, Russo G, Thorton-Wells TA, Jones N, Smith AV, Chouraki V, Thomas C, Ikram MA, Zelenika D, Vardarajan BN, Kamatani Y, Lin CF, Gerrish A, Schmidt H, Kunkle B, Dunstan ML, Ruiz A, Bihoreau MT, Choi SH, Reitz C, Pasquier F, Cruchaga C, Craig D, Amin N, Berr C, Lopez OL, De Jager PL, Deramecourt V, Johnston JA, Evans D, Lovestone S, Letenneur L, Morón FJ, Rubinsztein DC, Eiriksdottir G, Sleegers K, Goate AM, Fiévet N, Huentelman MW, Gill M, Brown K, Kamboh MI, Keller L, Barberger-Gateau P, McGuiness B, Larson EB, Green R, Myers AJ, Dufouil C, Todd S, Wallon D, Love S, Rogaeva E, Gallacher J, St George-Hyslop P, Clarimon J, Lleo A, Bayer A, Tsuang DW, Yu L, Tsolaki M, Bossù P, Spalletta G, Proitsi P, Collinge J, Sorbi S, Sanchez-Garcia F, Fox NC, Hardy J, Deniz Naranjo MC, Bosco P, Clarke R, Brayne C, Galimberti D, Mancuso M, Matthews F, Moebus S, Mecocci P, Del Zompo M, Maier W, Hampel H, Pilotto A, Bullido M, Panza F, Caffarra P, Nacmias B, Gilbert JR, Mayhaus M, Lannefelt L, Hakonarson H, Pichler S, Carrasquillo MM, Ingelsson M, Beekly D, Alvarez V, Zou F, Valladares O, Younkin SG, Coto E, Hamilton-Nelson KL, Gu W, Razquin C, Pastor P, Mateo I, Owen MJ, Faber KM, Jonsson PV, Combarros O, O'Donovan MC, Cantwell LB, Soininen H, Blacker D, Mead S, Mosley TH, Bennett DA, Harris TB, Fratiglioni L, Holmes C, de Bruijn RF, Passmore P, Montine TJ, Bettens K, Rotter JI, Brice A, Morgan K, Foroud TM, Kukull WA, Hannequin D, Powell JF, Nalls MA, Ritchie K, Lunetta KL, Kauwe JS, Boerwinkle E, Riemenschneider M, Boada M, Hiltuenen M, Martin ER, Schmidt R, Rujescu D, Wang LS, Dartigues JF, Mayeux R, Tzourio C, Hofman A, Nöthen MM, Graff C, Psaty BM, Jones L, Haines JL, Holmans PA, Lathrop M, Pericak-Vance MA, Launer LJ, Farrer LA, van Duijn CM, Van Broeckhoven C, Moskvina V, Seshadri S, Williams J, Schellenberg GD, Amouyel P | title = Meta-analysis of 74,046 individuals identifies 11 new susceptibility loci for Alzheimer's disease | journal = Nature Genetics | volume = 45 | issue = 12 | date = December 2013 | pmid = 24162737 | doi = 10.1038/ng.2802 | pmc=3896259 | pages=1452–8| url = https://eprints.soton.ac.uk/369403/1/ng.2802.pdf }}</ref>
```

### Full section (plain rendering)
== References ==
{{Reflist|33em|refs =

 [ref: (2014) "Adaptors for disorders of the brain? The cancer signaling proteins NED" doi:10.18632/oncoscience.64]

 [ref: (2014) "Genome-wide association meta-analysis of neuropathologic features of A" doi:10.1371/journal.pgen.1004606]

 [ref: (2009) "Charting the molecular network of the drug target Bcr-Abl" doi:10.1073/pnas.0900653106]

 [ref: (2013) "Identification of genes expressed by human airway eosinophils after an" doi:10.1371/journal.pone.0067560]

 [ref: (2003) "Differential regulation of cell motility and invasion by FAK" doi:10.1083/jcb.200212114]

 [ref: (2015) "Alzheimer's disease risk genes and mechanisms of disease pathogenesis" doi:10.1016/j.biopsych.2014.05.006]

 [FOCAL REF: (2013) "Meta-analysis of 74,046 individuals identifies 11 new susceptibility l" doi:10.1038/ng.2802]

 [ref: (2013) "Overexpression and cytoplasmic accumulation of Hepl is associated with" doi:10.1007/s13277-012-0517-x]

 [ref: (2014) "CAS proteins in health and disease: an update" doi:10.1002/iub.1282]

 [ref: (2005) "The focal adhesion scaffolding protein HEF1 regulates activation of th" doi:10.1038/ncb1309]

 [ref: (2007) "HEF1-dependent Aurora A activation induces disassembly of the primary " doi:10.1016/j.cell.2007.04.035]

 [ref: (2014) "Connecting the dots: potential of data integration to identify regulat" doi:10.1371/journal.pone.0095152]

 [ref: (2014) "Follow-up of loci from the International Genomics of Alzheimer's Disea" doi:10.1038/tp.2014.2]

 [ref: (2008) "A novel Cas family member, HEPL, regulates FAK and cell spreading" doi:10.1091/mbc.E07-09-0953]

 [ref: (1997) "Tyrosine phosphorylation of Crk-associated substrates by focal adhesio" doi:10.1074/jbc.272.46.29083]

 [ref: (2010) "CAS proteins in normal and pathological cell growth control" doi:10.1007/s00018-009-0213-1]

 [ref: (2010) "Dcas supports cell polarization and cell-cell adhesion complexes in de" doi:10.1371/journal.pone.0012369]

 [ref: (2014) "Cas proteins: dodgy scaffolding in breast cancer" doi:10.1186/s13058-014-0443-5]

 [ref: (2015) "Genetic determinants of disease progression in Alzheimer's disease" doi:10.3233/JAD-140729]

{{cite journal | vauthors = Wright FA, Strug LJ, Doshi VK, Commander CW, Blackman SM, Sun L, Berthiaume Y, Cutler D, Cojocaru A, Collaco JM, Corey M, Dorfman R, Goddard K, Green D, Kent JW, Lange EM, Lee S, Li W, Luo J, Mayhew GM, Naughton KM, Pace RG, Paré P, Rommens JM, Sandford A, Stonebraker JR, Sun W, Taylor C, Vanscoy LL, Zou F, Blangero J, Zielenski J, O'Neal WK, Drumm ML, Durie PR, Knowles MR, Cutting GR | title = Genome-wide association and linkage identify modifier loci of lung disease severity in cystic fibrosis at 11p13 and 20q13.2 | journal = Nature Genetics | volume = 43 | issue = 6 | date = June 2011 | pmid = 21602797 | doi = 1

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 4031a6c18f78687c2ec3/article_plain.txt in the evidence directory.)

- == Disease association ==
Altered expression or modification of CASS4 has been proposed as relevant to several human pathologies, typically based on detection of changes in CASS4 in high throughput screening, although the role of CASS4 in the pathology of these conditions has not yet been studied directly. These findings are summarized in Table 1; some examples are provided below.
{| class="wikitable"
|+Table 1. CASS4 disease association 
!Screen purpose
!Observation
|-
| rowspan="5" |Alzheimer's disease
|SNP rs7274581 T/C linked to risk.
Odds ratio 0.72; p-value 0.011. [ref: (2014) "Genome-wide association meta-analysis of neuropathologic features of A" doi:10.1371/journal.pgen.1004606]
|-
|SNP rs7274581 T/C linked to risk.
Odds ratio 0.88; p-value 2.5*10−8. [FOCAL REF: (2013) "Meta-analysis of 74,046 individuals identifies 11 new susceptibility l" doi:10.1038/ng.2802]
|-
|SNP rs7274581 T/C linked to risk
Odds ratio 0.8888; p-value 1.75 ×10−7. [ref: (2014) "Follow-up of loci from the International Genomics of Alzheimer's Disea" doi:10.1038/tp.2014.2]
|-
|SNP rs6024870, RegulomeDB [ref: "Search RegulomeDB"] score 2b, which means that this SNP is likely to affect transcription factor binding. [ref: (2014) "Connecting the dots: potential of data integration to identify regulat" doi:10.1371/journal.pone.0095152]
|-
|SNP rs16979934 T/G linked to risk.
Odds ratio 0.5956; p-value 0.03. [ref: (2015) "Genetic determinants of disease progression in Alzheimer's disease" doi:10.3233/JAD
- === Alzheimer's disease ===
CASS4 and corresponding SNP - rs7274581 T/C has been identified in a large meta-analysis as a locus for lower susceptibility to Alzheimer's disease (AD). [FOCAL REF: (2013) "Meta-analysis of 74,046 individuals identifies 11 new susceptibility l" doi:10.1038/ng.2802] [ref: "IGAP Summary Statistics"] However this SNP was not found predictive in a follow-up study. [ref: (2014) "Follow-up of loci from the International Genomics of Alzheimer's Disea" doi:10.1038/tp.2014.2]
- In a genome wide association screen (GWAS), CASS4 showed a significant correlation with clinical pathological features of AD such as neurofibrillary tangles and neuritic plaques. [ref: (2014) "Genome-wide association meta-analysis of neuropathologic features of A" doi:10.1371/journal.pgen.1004606] Two additional CASS4 SNPs were reported to be associated with AD susceptibility: rs6024870, [ref: (2014) "Connecting the dots: potential of data integration to identify regulat" doi:10.1371/journal.pone.0095152] and rs16979934 T/G. [ref: (2015) "Genetic determinants of disease progression in Alzheimer's disease" doi:10.3233/JAD-140729] Given the likely conserved CAS-family cytoskeletal function of CASS4, it has been speculated that it may have a role in axonal transport and influence the expression of the amyloid precursor protein (APP) and tau, which are pathologically affected in AD. [ref: (2015) "Alzheimer's disease risk genes and mechanisms of disease pathogenesis" doi:10.1016/j.biopsych.2014.05.006] Several possible mechanisms for CASS4 action in AD have been proposed. [ref: (2014) "Adaptors for disorders of the brain? The cancer signaling proteins NED" doi:10.18632/oncoscience.64]

## ORIGINAL STUDY: doi:10.1038/ng.2802 (FLoRA title: Meta-analysis of 74,046 individuals identifies 11 new susceptibility loci for Alzheimer's disease)
Crossref: Meta-analysis of 74,046 individuals identifies 11 new susceptibility loci for Alzheimer's disease | European Alzheimer's Disease Initiative (EADI), Jean-Charles Lambert, Genetic and Environmental Risk in Alzheimer's Disease (GERAD), Alzheimer's Disease Genetic Consortium (ADGC), Cohorts for Heart and Aging Research in Genomic Epidemiology (CHARGE), Carla A Ibrahim-Verbaas et al. | Nature Genetics | 2013 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2115779804", "type": "review", "publication_year": 2013, "cited_by_count": 4718, "is_retracted": false, "oa_status": "bronze", "oa_pdf": "https://www.nature.com/articles/ng.2802.pdf", "oa_landing": "https://doi.org/10.1038/ng.2802"}
Evidence level available to you: ABSTRACT — full text file: cache/fulltext_skill/10_1038_ng_2802.txt (Supplementary material only (via download-paper skill); the article itself was not read)
Retrieved: 2026-10-06T16:17:18+00:00
### Abstract (Europe PMC abstract)
Eleven susceptibility loci for late-onset Alzheimer's disease (LOAD) were identified by previous studies; however, a large portion of the genetic risk for this disease remains unexplained. We conducted a large, two-stage meta-analysis of genome-wide association studies (GWAS) in individuals of European ancestry. In stage 1, we used genotyped and imputed data (7,055,881 SNPs) to perform meta-analysis on 4 previously published GWAS data sets consisting of 17,008 Alzheimer's disease cases and 37,154 controls. In stage 2, 11,632 SNPs were genotyped and tested for association in an independent set of 8,572 Alzheimer's disease cases and 11,312 controls. In addition to the APOE locus (encoding apolipoprotein E), 19 loci reached genome-wide significance (P < 5 × 10(-8)) in the combined stage 1 and stage 2 analysis, of which 11 are newly associated with Alzheimer's disease.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.18632/oncotarget.7945 (FLoRA title: ZCWPW1 is associated with late-onset Alzheimer's disease in Han Chinese: a replication study and meta-analyses; FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: ZCWPW1 is associated with late-onset Alzheimer's disease in Han Chinese: a replication study and meta-analyses | Yu Gao, Meng-Shan Tan, Hui-Fu Wang, Wei Zhang, Zi-Xuan Wang, Teng Jiang et al. | Oncotarget | 2016 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2302711420", "type": "article", "publication_year": 2016, "cited_by_count": 30, "is_retracted": false, "oa_status": "diamond", "oa_pdf": "https://www.oncotarget.com/article/7945/pdf/", "oa_landing": "https://doi.org/10.18632/oncotarget.7945"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext/10_18632_oncotarget_7945.txt (Europe PMC open-access full text (PMC4991456))
Retrieved: 2026-10-06T16:17:21+00:00
### Abstract (Europe PMC abstract)
Recently, a large genome-wide association study (GWAS) has identified a novel variant (rs1476679) within ZCWPW1 showing strong association with late-onset Alzheimer's disease (LOAD) in Caucasian. However, the effect of rs1476679 on other populations remains unclear. In order to explore whether rs1476679 is also associated with the LOAD risk in other ethnic groups, we recruited 2350 unrelated Northern Han Chinese subjects, which include 992 LOAD patients and 1358 healthy controls. Analysis of data from these subjects suggests that the rs1476679 polymorphism is significantly associated with the LOAD (genotype P = 0.017, allele P = 0.044). The logistic regression reveals the C allele at rs1476679 is a protective factor for LOAD in the dominant model (OR = 0.779, 95%CI = 0.659-0.921, Pc = 0.009) adjusting for gender, age and APOE ε4 status. Furthermore, rs1476679 can decrease the AD risk (Dominant: OR = 0.733, 95%CI = 0.607-0.884, Pc = 0.006; Additive: OR = 0.820, 95%CI = 0.708-0.950, Pc = 0.048) in APOE ε4 non-carriers after stratification. Furthermore, meta-analysis of 82525 individuals confirmed that rs1476679 within ZCWPW1 decreased the risk of LOAD (OR = 0.91, 95%CI = 0.89-0.94). To summarize, the rs1476679 polymorphism in ZCWPW1 is associated with LOAD in Northern Han Chinese population.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.18632/oncotarget.12648 (FLoRA title: INPP5D rs35349669 polymorphism with late-onset Alzheimer's disease: A replication study and meta-analysis; FLoRA outcome code: failed [screening input only, not citable]; DOI detected on page: False)
Crossref: <i>INPP5D</i> rs35349669 polymorphism with late-onset Alzheimer's disease: A replication study and meta-analysis | Hua Jing, Jun-Xia Zhu, Hui-Fu Wang, Wei Zhang, Zhan-Jie Zheng, Ling-Li Kong et al. | Oncotarget | 2016 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2530299997", "type": "article", "publication_year": 2016, "cited_by_count": 32, "is_retracted": false, "oa_status": "diamond", "oa_pdf": "http://www.oncotarget.com/index.php?journal=oncotarget&page=article&op=download&path%5B%5D=12648&path%5B%5D=40073", "oa_landing": "https://doi.org/10.18632/oncotarget.12648"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext/10_18632_oncotarget_12648.txt (Europe PMC open-access full text (PMC5342472))
Retrieved: 2026-10-06T16:17:22+00:00
### Abstract (Europe PMC abstract)
Inositol polyphosphate-5-phosphatase (INPP5D) was reported to be associated with Alzheimer's disease (AD) through modulating the inflammatory process and immune response. A recent genome-wide association study discovered a new locus single nucleotide polymorphism (SNP, rs35349669) of INPP5D which was significantly associated with susceptibility to late-onset Alzheimer's disease (LOAD) in Caucasians. In this study, we investigated the relations between the INPP5D polymorphism rs35349669 and LOAD in Han Chinese population comprising 984 LOAD cases and 1352 healthy controls being matched for age and gender. Our results showed no obvious differences in the genotypic or allelic distributions of rs35349669 polymorphism between LOAD cases and healthy controls (genotype: p = 0.167; allele: p = 0.094). Additionally, when these data were stratified by APOEε4 status, there are still no evident differences in the genotypic or allelic distributions in APOEε4 carriers (p > 0.05). Furthermore, meta-analysis of 81964 individuals confirmed that rs35349669 was significantly associated with the risk for LOAD (OR=1.08, 95%CI=1.06-1.11), but the results remained negative in Chinese subgroup (OR=0.77, 95%CI=0.53-1.13). Overall, the current evidence did not indicate that INPP5D rs35349669 polymorphism play a role in the genetic predisposition to LOAD in Chinese population.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.18632/oncotarget.9819 (FLoRA title: MEF2C rs190982 polymorphism with late-onset Alzheimer's disease in Han Chinese: A replication study and meta-analyses; FLoRA outcome code: failed [screening input only, not citable]; DOI detected on page: False)
Crossref: <i>MEF2C</i> rs190982 polymorphism with late-onset Alzheimer's disease in Han Chinese: A replication study and meta-analyses | Shan-Shan Tang, Hui-Fu Wang, Wei Zhang, Ling-Li Kong, Zhan-Jie Zheng, Meng-Shan Tan et al. | Oncotarget | 2016 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2409955980", "type": "article", "publication_year": 2016, "cited_by_count": 14, "is_retracted": false, "oa_status": "diamond", "oa_pdf": "http://www.oncotarget.com/index.php?journal=oncotarget&page=article&op=download&path%5B%5D=9819&path%5B%5D=30817", "oa_landing": "https://doi.org/10.18632/oncotarget.9819"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext/10_18632_oncotarget_9819.txt (Europe PMC open-access full text (PMC5129919))
Retrieved: 2026-10-06T16:17:25+00:00
### Abstract (Europe PMC abstract)
The myocyte enhancer factor (MEF2) family of transcription factors plays a vital role in memory and learning due to its functions in regulating synapse number and reducing dendritic spines. Myocyte enhancer factor 2 C (MEF2C) is regarded as modulator of amyloid-protein precursor (APP) proteolytic processing, in which amyloid-β (Aβ) is produced. A common single nucleotide polymorphism (SNP, rs190982) in MEF2C gene was identified to be related to late-onset Alzheimer's disease (LOAD) in Caucasians in a large meta-analysis of genome-wide association studies (GWAS). Here, we recruited unrelated 984 LOAD patients and 1348 healthy controls matched for gender and age to ascertain whether the rs190982 polymorphism is related to LOAD in Han Chinese. No difference in the genotype and allele distributions of the MEF2C rs190982 polymorphism was found between LOAD cases and healthy controls (genotype: P = 0.861; allele: P = 0.862), even after stratification for APOE ε4 allele as well as statistical adjustment for age, gender and APOE ε4 status. Furthermore, the meta-analysis in 4089 Chinese individuals did not detect the association of rs190982 within MEF2C with the risk for LOAD (OR = 1.03, 95%CI = 0.90-1.18). Overall, the current evidence did not support the relation between rs190982 polymorphism within MEF2C and the LOAD risk in Northern Han Chinese.

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1016/j.biopsych.2018.04.017 | A Longitudinal Imaging Genetics Study of Neuroanatomical Asymmetry in Alzheimer’s Disease | 2018 | read: metadata_only | mentions replication: False
- doi:10.3390/bioengineering11010045 | Alzheimer’s Disease: Models and Molecular Mechanisms Informing Disease and Treatments | 2024 | read: abstract | mentions replication: False
- doi:10.3390/ijms25052645 | Exploring the Genetic Landscape of Mild Behavioral Impairment as an Early Marker of Cognitive Decline: An Updated Review Focusing on Alzheimer’s Disease | 2024 | read: abstract | mentions replication: False
- doi:10.1111/jgs.16735 | Association Between Episodic Memory and Genetic Risk Factors for Alzheimer's Disease in South Asians from the Longitudinal Aging Study in India–Diagnostic Assessment of Dementia (LASI‐DAD) | 2020 | read: abstract | mentions replication: False
- doi:10.1016/j.jfma.2023.10.021 | Classifying Alzheimer’s disease and normal subjects using machine learning techniques and genetic-environmental features | 2023 | read: abstract | mentions replication: False

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1038/s41582-020-00435-y | Neuroinflammation and microglial activation in Alzheimer disease: where do we go from here? | 2020 | review | cited_by 3315
  Abstract: (none)
- [review citing original] doi:10.1038/s41588-019-0358-2 | Genetic meta-analysis of diagnosed Alzheimer’s disease identifies new risk loci and implicates Aβ, tau, immunity and lipid processing | 2019 | review | cited_by 3285
  Abstract: (none)
- [review citing original] doi:10.1038/nrm3810 | The amyloid state and its association with protein misfolding diseases | 2014 | review | cited_by 2476
  Abstract: (none)
- [review citing original] doi:10.1038/s43586-021-00092-5 | Mendelian randomization | 2022 | review | cited_by 2307
  Abstract: (none)
- [review citing original] doi:10.1152/physrev.00050.2017 | Blood-Brain Barrier: From Physiology to Disease and Back | 2018 | review | cited_by 2296
  Abstract: The blood-brain barrier (BBB) prevents neurotoxic plasma components, blood cells, and pathogens from entering the brain. At the same time, the BBB regulates transport of molecules into and out of the central nervous system (CNS), which maintains tightly controlled chemical composition of the neuronal milieu that is required for proper neuronal functioning. In this review, we first examine molecular and cellular mechanisms underlying the establishment of the BBB. Then, we focus on BBB transport physiology, endothelial and pericyte transporters, and perivascular and paravascular transport. Next, we discuss rare human monogenic neurological disorders with the primary genetic defect in BBB-associated cells demonstrating the link between BBB breakdown and neurodegeneration. Then, we review the effects of genes underlying inheritance and/or increased susceptibility for Alzheimer's disease (AD), Parkinson's disease (PD), Huntington's disease, and amyotrophic lateral sclerosis (ALS) on BBB in relation to other pathologies and neurological deficits. We next examine how BBB dysfunction relates to neurological deficits and other pathologies in the majority of sporadic AD, PD, and ALS cases, m
- [cites original and replication 10.18632/oncotarget.7945] doi:10.1016/j.biopsych.2018.04.017 | A Longitudinal Imaging Genetics Study of Neuroanatomical Asymmetry in Alzheimer’s Disease | 2018 | article | cited_by 55
  Abstract: (none)
- [cites original and replication 10.18632/oncotarget.7945] doi:10.3390/bioengineering11010045 | Alzheimer’s Disease: Models and Molecular Mechanisms Informing Disease and Treatments | 2024 | article | cited_by 26
  Abstract: Alzheimer’s Disease (AD) is a complex neurodegenerative disease resulting in progressive loss of memory, language and motor abilities caused by cortical and hippocampal degeneration. This review captures the landscape of understanding of AD pathology, diagnostics, and current therapies. Two major mechanisms direct AD pathology: (1) accumulation of amyloid β (Aβ) plaque and (2) tau-derived neurofibrillary tangles (NFT). The most common variants in the Aβ pathway in APP, PSEN1, and PSEN2 are largely responsible for early-onset AD (EOAD), while MAPT, APOE, TREM2 and ABCA7 have a modifying effect on late-onset AD (LOAD). More recent studies implicate chaperone proteins and Aβ degrading proteins in AD. Several tests, such as cognitive function, brain imaging, and cerebral spinal fluid (CSF) and blood tests, are used for AD diagnosis. Additionally, several biomarkers seem to have a unique AD specific combination of expression and could potentially be used in improved, less invasive diagnostics. In addition to genetic perturbations, environmental influences, such as altered gut microbiome signatures, affect AD. Effective AD treatments have been challenging to develop. Currently, there are
- [cites original and replication 10.18632/oncotarget.7945] doi:10.3390/ijms25052645 | Exploring the Genetic Landscape of Mild Behavioral Impairment as an Early Marker of Cognitive Decline: An Updated Review Focusing on Alzheimer’s Disease | 2024 | article | cited_by 22
  Abstract: The clinical features and pathophysiology of neuropsychiatric symptoms (NPSs) in dementia have been extensively studied. However, the genetic architecture and underlying neurobiological mechanisms of NPSs at preclinical stages of cognitive decline and Alzheimer's disease (AD) remain largely unknown. Mild behavioral impairment (MBI) represents an at-risk state for incident cognitive impairment and is defined by the emergence of persistent NPSs among non-demented individuals in later life. These NPSs include affective dysregulation, decreased motivation, impulse dyscontrol, abnormal perception and thought content, and social inappropriateness. Accumulating evidence has recently begun to shed more light on the genetic background of MBI, focusing on its potential association with genetic factors related to AD. The Apolipoprotein E (APOE) genotype and the MS4A locus have been associated with affective dysregulation, ZCWPW1 with social inappropriateness and psychosis, BIN1 and EPHA1 with psychosis, and NME8 with apathy. The association between MBI and polygenic risk scores (PRSs) in terms of AD dementia has been also explored. Potential implicated mechanisms include neuroinflammation, sy
- [cites original and replication 10.18632/oncotarget.7945] doi:10.1111/jgs.16735 | Association Between Episodic Memory and Genetic Risk Factors for Alzheimer's Disease in South Asians from the Longitudinal Aging Study in India–Diagnostic Assessment of Dementia (LASI‐DAD) | 2020 | article | cited_by 18
  Abstract: BACKGROUND/OBJECTIVES: Genetic factors play an important role in Alzheimer's disease (AD) and cognitive aging. However, it is unclear whether risk loci identified in European ancestry (EA) populations have similar effects in other groups, such as South Asians. DESIGN: We investigated the allelic distribution and cognitive associations of 56 known AD risk single-nucleotide polymorphisms (SNPs) identified from three EA genome-wide association studies (EA-GWASs) in a South Asian population. Single SNP and genetic risk score (GRS) associations with measures of episodic memory were assessed. SETTING: The Diagnostic Assessment of Dementia for the Longitudinal Aging Study in India (LASI-DAD). PARTICIPANTS: A total of 906 LASI-DAD participants from diverse states in India. MEASUREMENTS: Participants were genotyped using the Illumina Global Screening Array and imputed with 1000G Phase 3v5. Cognitive measures included total learning and delayed word recall. RESULTS: Although only a few SNPs were significantly associated with memory scores (P < .05), effect estimates from the EA-GWAS and the LASI-DAD showed moderate correlation (0.35-0.88) in the expected direction. GRSs were also associated 
- [cites original and replication 10.18632/oncotarget.7945] doi:10.1016/j.jfma.2023.10.021 | Classifying Alzheimer’s disease and normal subjects using machine learning techniques and genetic-environmental features | 2023 | article | cited_by 14
  Abstract: BACKGROUND: Alzheimer's disease (AD) is complicated by multiple environmental and polygenetic factors. The accuracy of artificial neural networks (ANNs) incorporating the common factors for identifying AD has not been evaluated. METHODS: A total of 184 probable AD patients and 3773 healthy individuals aged 65 and over were enrolled. AD-related genes (51 SNPs) and 8 environmental factors were selected as features for multilayer ANN modeling. Random Forest (RF) and Support Vector Machine with RBF kernel (SVM) were also employed for comparison. Model results were verified using traditional statistics. RESULTS: The ANN achieved high accuracy (0.98), sensitivity (0.95), and specificity (0.96) in the intrinsic test for AD classification. Excluding age and genetic data still yielded favorable results (accuracy: 0.97, sensitivity: 0.94, specificity: 0.96). The assigned weights to ANN features highlighted the importance of mental evaluation, years of education, and specific genetic variations (CASS4 rs7274581, PICALM rs3851179, and TOMM40 rs2075650) for AD classification. Receiver operating characteristic analysis revealed AUC values of 0.99 (intrinsic test), 0.60 (TWB-GWA), and 0.72 (CG-WG
- [cites original and replication 10.18632/oncotarget.12648] doi:10.1016/s1474-4422(18)30490-3 | The role of astroglia in Alzheimer's disease: pathophysiology and clinical implications | 2019 | article | cited_by 365
  Abstract: (none)
- [cites original and replication 10.18632/oncotarget.12648] doi:10.1016/j.neuron.2020.09.029 | Emerging Microglia Biology Defines Novel Therapeutic Approaches for Alzheimer’s Disease | 2020 | article | cited_by 230
  Abstract: (none)
- [cites original and replication 10.18632/oncotarget.12648] doi:10.1016/j.nbd.2021.105303 | INPP5D expression is associated with risk for Alzheimer's disease and induced by plaque-associated microglia | 2021 | article | cited_by 113
  Abstract: Alzheimer's disease (AD) is a progressive neurodegenerative disorder characterized by cognitive decline, robust microgliosis, neuroinflammation, and neuronal loss. Genome-wide association studies recently highlighted a prominent role for microglia in late-onset AD (LOAD). Specifically, inositol polyphosphate-5-phosphatase (INPP5D), also known as SHIP1, is selectively expressed in brain microglia and has been reported to be associated with LOAD. Although INPP5D is likely a crucial player in AD pathophysiology, its role in disease onset and progression remains unclear. We performed differential gene expression analysis to investigate INPP5D expression in AD and its association with plaque density and microglial markers using transcriptomic (RNA-Seq) data from the Accelerating Medicines Partnership for Alzheimer's Disease (AMP-AD) cohort. We also performed quantitative real-time PCR, immunoblotting, and immunofluorescence assays to assess INPP5D expression in the 5xFAD amyloid mouse model. Differential gene expression analysis found that INPP5D expression was upregulated in LOAD and positively correlated with amyloid plaque density. In addition, in 5xFAD mice, Inpp5d expression increa
- [cites original and replication 10.18632/oncotarget.12648] doi:10.1186/s13195-020-00760-w | AlzGPS: a genome-wide positioning systems platform to catalyze multi-omics for Alzheimer’s drug discovery | 2021 | article | cited_by 89
  Abstract: BACKGROUND: Recent DNA/RNA sequencing and other multi-omics technologies have advanced the understanding of the biology and pathophysiology of AD, yet there is still a lack of disease-modifying treatments for AD. A new approach to integration of the genome, transcriptome, proteome, and human interactome in the drug discovery and development process is essential for this endeavor. METHODS: In this study, we developed AlzGPS (Genome-wide Positioning Systems platform for Alzheimer's Drug Discovery, https://alzgps.lerner.ccf.org ), a comprehensive systems biology tool to enable searching, visualizing, and analyzing multi-omics, various types of heterogeneous biological networks, and clinical databases for target identification and development of effective prevention and treatment for AD. RESULTS: Via AlzGPS: (1) we curated more than 100 AD multi-omics data sets capturing DNA, RNA, protein, and small molecule profiles underlying AD pathogenesis (e.g., early vs. late stage and tau or amyloid endophenotype); (2) we constructed endophenotype disease modules by incorporating multi-omics findings and human protein-protein interactome networks; (3) we provided possible treatment information f
- [cites original and replication 10.18632/oncotarget.12648] doi:10.1002/alz.12849 | INPP5D deficiency attenuates amyloid pathology in a mouse model of Alzheimer's disease | 2022 | article | cited_by 59
  Abstract: INTRODUCTION: Inositol polyphosphate-5-phosphatase (INPP5D) is a microglia-enriched lipid phosphatase in the central nervous system. A non-coding variant (rs35349669) in INPP5D increases the risk for Alzheimer's disease (AD), and elevated INPP5D expression is associated with increased plaque deposition. INPP5D negatively regulates signaling via several microglial cell surface receptors, including triggering receptor expressed on myeloid cells 2 (TREM2); however, the impact of INPP5D inhibition on AD pathology remains unclear. METHODS: We used the 5xFAD mouse model of amyloidosis to assess how Inpp5d haplodeficiency regulates amyloid pathogenesis. RESULTS: Inpp5d haplodeficiency perturbs the microglial intracellular signaling pathways regulating the immune response, including phagocytosis and clearing of amyloid beta (Aβ). It is important to note that Inpp5d haploinsufficiency leads to the preservation of cognitive function. Spatial transcriptomic analysis revealed that pathways altered by Inpp5d haploinsufficiency are related to synaptic regulation and immune cell activation. CONCLUSION: These data demonstrate that Inpp5d haplodeficiency enhances microglial functions by increasing 
