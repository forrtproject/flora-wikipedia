# Evidence packet 6a61b434691693f085f2: Choice architecture

Frozen revision: 1376379283 (2026-09-23T20:47:13Z); https://en.wikipedia.org/w/index.php?oldid=1376379283
Live check: {"frozen_revid": "1376379283", "title": "Choice architecture", "live_revid": 1376379283, "live_timestamp": "2026-09-23T20:47:13Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "broad_topic", "context_kind": "list", "living_person_category": false, "health_term_flag": true, "co_cited": false, "large_project": false, "flora_originals_on_page": 2}

## Article lead (plain rendering, approximate)
Choice architecture is the design of different ways in which choices can be presented to decision makers, and the impact of that presentation on decision-making. Choice architecture is the design of different ways in which choices can be presented to consumers, and the impact of that presentation on consumer decision-making. In workplace organizations the actual deployment of choice architecture interventions  has mostly been found to be agreeable not only to employs but also to the implementers, primarily when the interventions facilitate the consumption of healthy food and physical activity without binding any choices. [ref: Rantala (2023) "Acceptability of workplace choice architecture modification for health" doi:10.1186/s12889-023-17331-x]Choice architecture refers to how options are arranged and presented, and it influences decision making across a wide range of everyday and significant choices. [ref: (2013) "A nudge in the right direction" doi:10.1016/S0262-4079(13)61510-9]Nudging is a concept in behavioral science, political theory and economics which argues that positive reinforcement and indirect suggestions can influence behavior and decision-making .Research suggests that the activation of personal norms through choice architecture nudges is a particularly effective compared to simply relying on social pressures. [ref: Trujillo (2021) "Norm-focused nudges influence pro-environmental choices and moderate p" doi:10.1371/journal.pone.0247519] Several factors in choice architecture can influence decision- making including:

* the number of choices presented [ref: Scheibehenne (2010) "Can there ever be too many options? A meta-analytic review of choice o" doi:10.1086/651235]
* the manner in which attributes are described [ref: Larrick (2008) "The MPG Illusion" doi:10.1126/science.1154983]
* the presence of a default option [FOCAL REF: Johnson (2003) "Do Defaults Save Lives?" doi:10.1126/science.1091721] [ref: Cronqvist (2004) "Design choices in privatized social security systems: Learning from th" doi:10.1257/0002828041301632]

these elements can significantly affect consumer choice. As a result, advocates of libertarian paternalism and asymmetric paternalism have endorsed the deliberate design of choice architecture to nudge consumers toward personally and socially desirable behaviors like saving for retirement, choosing healthier foods, or registering as an organ donor. These interventions are often justified by advocates of libertarian paternalism in that well-designed choice architectures can compensate for irrational decision-making biases to improve consumer welfare. [ref: Thaler (2013) "The Behavioral Foundations of Public Policy"] These techniques have consequently become popular among policymakers, leading to the formation of the UK's Behavioural Insights Team and the White House "Nudge Unit" for example. [ref: Nesterak "Head of White House "Nudge Unit" Maya Shankar Speaks about Newly Forme"] While many behavioral scientists stress that there is no neutral choice-architecture and that consumers maintain autonomy and freedom of choice despite manipulations of choice architecture, [ref: Johnson (2012) "Beyond Nudges: Tools of a choice architecture" doi:10.1007/s11002-012-9186-1] critics of libertarian paternalism often argue that choice architectures designed to overcome irrational decision biases may impose costs on rational agents, for example by limiting choice [ref: Mitchell (2005) "Libertarian Paternalism is an Oxymor

## Article outline
Background
Elements
  Reducing choice overload
  Defaults
  Choice over time
  Partitioning options and attributes
  Avoiding attribute overload
  Translating attributes
Examples
Criticisms
Terminology
See also
References
External links

## Categories
Behavioral finance; Decision-making; Libertarian terms; Political philosophy; Selling techniques; Decision theory

## Occurrence 1: original DOI 10.1126/science.1091721 in section '(lead)'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
* the number of choices presented [ref: Scheibehenne (2010) "Can there ever be too many options? A meta-analytic review of choice o" doi:10.1086/651235]
* the manner in which attributes are described [ref: Larrick (2008) "The MPG Illusion" doi:10.1126/science.1154983]
* the presence of a default option [FOCAL REF: Johnson (2003) "Do Defaults Save Lives?" doi:10.1126/science.1091721] [ref: Cronqvist (2004) "Design choices in privatized social security systems: Learning from th" doi:10.1257/0002828041301632]

### Paragraph (raw wikitext)
```
* the number of choices presented<ref>{{cite journal|last1= Scheibehenne|first1= Benjamin|last2= Greifeneder|first2= Rainer|last3=Todd|first3= Peter|title= Can there ever be too many options? A meta-analytic review of choice overload|journal= Journal of Consumer Research|date= 2010|volume= 37|issue= 3|pages= 409–25|jstor= 10.1086/651235|doi= 10.1086/651235|s2cid= 5802575|url= http://edoc.unibas.ch/20586/1/PUBL_scheibehenne_greifeneder_JCR37_2010_409-425.pdf}}</ref>
* the manner in which attributes are described<ref name=Larrick>{{cite journal|last1= Larrick|first1= R.P.|last2= Soll|first2= J.B|title= The MPG Illusion|journal= Science|date= 2008|volume= 320|issue= 5883|pages= 1593–4|doi= 10.1126/science.1154983|pmid= 18566271|s2cid= 206511466}}</ref>
* the presence of a default option <ref name=Johnson2>{{cite journal|last1= Johnson|first1= E.J.|last2= Goldstein|first2= D.G.|title= Do Defaults Save Lives?|date= 2003|journal=Science|volume= 302|issue= 5649|pages=1338–1339|doi=10.1126/science.1091721|pmid= 14631022|s2cid= 166476782|url= http://pdfs.semanticscholar.org/0720/63c3d295f0c1d38ac0e9bc24827c7b5ee095.pdf|archive-url= https://web.archive.org/web/20200110222204/http://pdfs.semanticscholar.org/0720/63c3d295f0c1d38ac0e9bc24827c7b5ee095.pdf|archive-date= 2020-01-10}}</ref><ref name=Cronqvist>{{cite journal|last1= Cronqvist|first1= H|last2= Thaler|first2= R|title= Design choices in privatized social security systems: Learning from the Swedish experience|journal= American Economic Review|date= 2004|volume= 94|issue= 2|pages= 424–8|doi= 10.1257/0002828041301632|s2cid= 14415952}}</ref>
```

### Full section (plain rendering)
Choice architecture is the design of different ways in which choices can be presented to decision makers, and the impact of that presentation on decision-making. Choice architecture is the design of different ways in which choices can be presented to consumers, and the impact of that presentation on consumer decision-making. In workplace organizations the actual deployment of choice architecture interventions  has mostly been found to be agreeable not only to employs but also to the implementers, primarily when the interventions facilitate the consumption of healthy food and physical activity without binding any choices. [ref: Rantala (2023) "Acceptability of workplace choice architecture modification for health" doi:10.1186/s12889-023-17331-x]Choice architecture refers to how options are arranged and presented, and it influences decision making across a wide range of everyday and significant choices. [ref: (2013) "A nudge in the right direction" doi:10.1016/S0262-4079(13)61510-9]Nudging is a concept in behavioral science, political theory and economics which argues that positive reinforcement and indirect suggestions can influence behavior and decision-making .Research suggests that the activation of personal norms through choice architecture nudges is a particularly effective compared to simply relying on social pressures. [ref: Trujillo (2021) "Norm-focused nudges influence pro-environmental choices and moderate p" doi:10.1371/journal.pone.0247519] Several factors in choice architecture can influence decision- making including:

* the number of choices presented [ref: Scheibehenne (2010) "Can there ever be too many options? A meta-analytic review of choice o" doi:10.1086/651235]
* the manner in which attributes are described [ref: Larrick (2008) "The MPG Illusion" doi:10.1126/science.1154983]
* the presence of a default option [FOCAL REF: Johnson (2003) "Do Defaults Save Lives?" doi:10.1126/science.1091721] [ref: Cronqvist (2004) "Design choices in privatized social security systems: Learning from th" doi:10.1257/0002828041301632]

these elements can significantly affect consumer choice. As a result, advocates of libertarian paternalism and asymmetric paternalism have endorsed the deliberate design of choice architecture to nudge consumers toward personally and socially desirable behaviors like saving for retirement, choosing healthier foods, or registering as an organ donor. These interventions are often justified by advocates of libertarian paternalism in that well-designed choice architectures can compensate for irrational decision-making biases to improve consumer welfare. [ref: Thaler (2013) "The Behavioral Foundations of Public Policy"] These techniques have consequently become popular among policymakers, leading to the formation of the UK's Behavioural Insights Team and the White House "Nudge Unit" for example. [ref: Nesterak "Head of White House "Nudge Unit" Maya Shankar Speaks about Newly Forme"] While many behavioral scientists stress that there is no neutral choice-architecture and that consumers maintain autonomy and freedom of choice despite manipulations of choice architecture, [ref: Johnson (2012) "Beyond Nudges: Tools of a choice architecture" doi:10.1007/s11002-012-9186-1] critics of libertarian paternalism often argue that choice architectures designed to overcome irrational decision biases may impose costs on rational agents, for example by limiting choice [ref: Mitchell (2005) "Libertarian Paternalism is an Oxymoron"] or undermining respect for individual human agency and moral autonomy. [ref: Goodwin (2016) "Choice Architecture in Democracies: Exploring the Legitimacy of Nudgin"] Moreover, it can result in dark patterns because of the principal–agent problem.

==Background==
The term "choice architecture" was coined by Richard Thaler and Cass Sunstein in their 2008 book Nudge: Improving Decisions about Health, Wealth, and Happiness. [ref: (2008) "Designing better choices"] Thaler and Sunstein have endorsed thoughtful design of choice architecture as a means to improve consumer decision-making by minimizing biases and errors that arise as the result of bounded rationality. This approach is an example of "libertarian paternalism", a philosophy endorsed by Thaler and Sunstein that aims to "nudge" individuals toward choices that are in their best interest without forbidding options or significantly changing their economic incentives. [ref: Thaler (2008) "Nudge: improving decisions about health, wealth, and happiness"] They go further to say that completely restricting options is no longer a nudge, but simply making something more obvious amongst a group of choices is. 

Libertarian paternalism may also be described as soft paternalism.

Behavioral scientists have grouped the elements of choice architecture in different ways. For example, Thaler, Sunstein, and John P. Balz have focused on the following "tools" of choice architecture: defaults, expecting error, understanding mappings (which involves exploring the different ways that information presentation affects option comparisons), giving feedback, structuring complex choices, and creating incentives. [ref: Thaler (2013) "The Behavioral Foundations of Public Policy"] Another group of leading behavioral scientists has cr

## Occurrence 2: original (named-reference reuse) DOI 10.1126/science.1091721 in section 'Defaults'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
One of the most commonly cited studies on the power of defaults is the example of organ donation. One study found that donor registration rates were twice as high when potential donors had to opt out versus opt into donor registration. [FOCAL REF: Johnson (2003) "Do Defaults Save Lives?" doi:10.1126/science.1091721] However, the influence of defaults has been demonstrated across a range of domains including investment [ref: Cronqvist (2004) "Design choices in privatized social security systems: Learning from th" doi:10.1257/0002828041301632] [ref: Madrian (2001) "The power of suggestion: inertia in 401(k) participation and savings b" doi:10.1162/003355301753265543] and insurance [ref: Johnson (1993) "Framing, probability distortions, and insurance decisions" doi:10.1007/BF01065313]

### Paragraph (raw wikitext)
```
One of the most commonly cited studies on the power of defaults is the example of organ donation. One study found that donor registration rates were twice as high when potential donors had to opt out versus opt into donor registration.<ref name=Johnson2/> However, the influence of defaults has been demonstrated across a range of domains including investment<ref name=Cronqvist/><ref>{{cite journal|last1=Madrian|first1=B.C.|last2=Shea|first2=D.F.|title=The power of suggestion: inertia in 401(k) participation and savings behavior|journal=Quarterly Journal of Economics|date=2001|volume=116|issue=4| doi = 10.1162/003355301753265543|pages=1149–1187|url=http://www.nber.org/papers/w7682.pdf}}</ref> and insurance<ref>{{cite journal|last1=Johnson|first1=E.J.|title=Framing, probability distortions, and insurance decisions|journal=Journal of Risk and Uncertainty|date=1993|volume=7|pages=35–51|doi=10.1007/BF01065313|s2cid=154911666|display-authors=etal}}</ref>
```

### Full section (plain rendering)
===Defaults===
A large body of research has shown that, all things being equal, consumers are more likely to choose default options. [ref: Smith (2013) "Choice without awareness: Ethical and policy implications of defaults"] A default is defined as a choice frame in which one selection is pre-selected so that individuals must take active steps to select another option. [ref: Brown (2004) "The skeptical shopper: a metacognitive account for the effects of defa" doi:10.1086/425087] Defaults can take many forms ranging from the automatic enrollment of college students in university health insurance plans to forms which default to a specific option unless changed.

Several mechanisms have been proposed to explain the influence of defaults. For example, individuals may interpret defaults as policymaker recommendations, cognitive biases related to loss aversion like the status quo bias or endowment effect might be at work, or consumers may fail to opt-out of the default due to associated effort. [ref: Smith (2013) "Choice without awareness: Ethical and policy implications of defaults"] These mechanisms are not mutually exclusive and their relative influence will likely differ across decision contexts.

Types of default include simple defaults where one choice is automatically selected for all consumers, forced-choice in which a product or service is denied until the consumer makes a proactive selection, and sensory defaults in which the choice is pre-selected based upon other information that was gathered about specific consumers. Choices that are made repeatedly may also be affected by defaults, for instance, persistent defaults may be continually reset regardless of past decisions, whereas reoccurring defaults "remember" past decisions for use as the default, and predictive defaults use algorithms to set defaults based upon other related behavior. [ref: Johnson (2012) "Beyond Nudges: Tools of a choice architecture" doi:10.1007/s11002-012-9186-1]

One of the most commonly cited studies on the power of defaults is the example of organ donation. One study found that donor registration rates were twice as high when potential donors had to opt out versus opt into donor registration. [FOCAL REF: Johnson (2003) "Do Defaults Save Lives?" doi:10.1126/science.1091721] However, the influence of defaults has been demonstrated across a range of domains including investment [ref: Cronqvist (2004) "Design choices in privatized social security systems: Learning from th" doi:10.1257/0002828041301632] [ref: Madrian (2001) "The power of suggestion: inertia in 401(k) participation and savings b" doi:10.1162/003355301753265543] and insurance [ref: Johnson (1993) "Framing, probability distortions, and insurance decisions" doi:10.1007/BF01065313]

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 6a61b434691693f085f2/article_plain.txt in the evidence directory.)

- * the number of choices presented [ref: Scheibehenne (2010) "Can there ever be too many options? A meta-analytic review of choice o" doi:10.1086/651235]
* the manner in which attributes are described [ref: Larrick (2008) "The MPG Illusion" doi:10.1126/science.1154983]
* the presence of a default option [FOCAL REF: Johnson (2003) "Do Defaults Save Lives?" doi:10.1126/science.1091721] [ref: Cronqvist (2004) "Design choices in privatized social security systems: Learning from th" doi:10.1257/0002828041301632]

## ORIGINAL STUDY: doi:10.1126/science.1091721 (FLoRA title: Do Defaults Save Lives?)
Crossref: Do Defaults Save Lives? | Eric J. Johnson, Daniel Goldstein | Science | 2003 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W1933689484", "type": "article", "publication_year": 2003, "cited_by_count": 44, "is_retracted": false, "oa_status": "green", "oa_pdf": null, "oa_landing": "https://papers.ssrn.com/sol3/Delivery.cfm/SSRN_ID1324774_code1144166.pdf?abstractid=1324774&mirid=1"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1126_science_1091721.txt (Free copy found by source search (published): https://www.dangoldstein.com/papers/DefaultsScience.pdf)
Retrieved: 2026-10-06T16:11:04+00:00
### Abstract (OpenAlex reconstructed abstract)
Default options can lead to striking differences in preferences, with significant economic impact. The authors of this Policy Forum use natural and experimental data to examine the impact of simple policy defaults on the decision to become an organ donor, finding large effects that significantly increase donation rates.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.15626/mp.2022.3108 (FLoRA title: Defaults versus framing: Revisiting Default Effect and Framing Effect with replications and extensions of Johnson and Goldstein (2003) and Johnson, Bellman, and Lohse (2002); FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: Defaults versus framing: Revisiting Default Effect and Framing Effect with replications and extensions of Johnson and Goldstein (2003) and Johnson, Bellman, and Lohse (2002) | Subramanya Prasad Chandrashekar, Nadia Adelina, Shiyuan Zeng, Yan Ying Esther Chiu, Grace Yat Sum Leung, Paul Henne et al. | Meta-Psychology | 2023 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W4383908678", "type": "article", "publication_year": 2023, "cited_by_count": 4, "is_retracted": false, "oa_status": "diamond", "oa_pdf": "https://open.lnu.se/index.php/metapsychology/article/download/3108/3438", "oa_landing": "https://doi.org/10.15626/mp.2022.3108"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext/10_15626_mp_2022_3108.txt (open-access PDF via OpenAlex best_oa_location (https://open.lnu.se/index.php/metapsychology/article/download/3108/3438))
Retrieved: 2026-10-06T16:11:06+00:00
### Abstract (Crossref deposited abstract)
People tend to stick with a default option instead of switching to another option. For instance, Johnson and Goldstein (2003) found a default effect in an organ donation scenario: if organ donation is the default option, people are more inclined to consent to it. Johnson et al. (2002) found a similar default effect in health-survey scenarios: if receiving more information about your health is the default, people are more inclined to consent to it. Much of the highly cited, impactful work on these default effects, however, has not been replicated in well-powered samples. In two well-powered samples (N = 1920), we conducted a close replication of the default effect in Johnson and Goldstein (2003) and in Johnson, Bellman, and Lohse (2002). We successfully replicated Johnson and Goldstein (2003). In an extension of the original findings, we also show that default effects are unaffected by the permanence of these selections. We, however, failed to replicate the findings of Johnson, Bellman, and Lohse’s (2002) study; we did not find evidence for a default effect. We did, however, find a framing effect: participants who read a positively-framed scenario consented to receive health-related information at a higher rate than participants who read a negatively framed scenario. We also conducted a conceptual replication of Johnson et al. (2002) that was based on an organ-donation scenario, but this attempt failed to find a default effect. Our results suggest that default effects depend on framing and context. Materials, data, and code are available on: https://osf.io/8wd2b/.

## Other database studies cited on this same page (each has its own packet; drafted together)
- 9148bd2437f3f0e96106: Partition Priming in Judgment Under Uncertainty (doi:10.1111/1467-9280.02431)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1017/bpp.2018.43 | When and why defaults influence decisions: a meta-analysis of default effects | 2019 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_1017_bpp_2018_43.txt

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1017/bpp.2018.43 | When and why defaults influence decisions: a meta-analysis of default effects | 2019 | review | cited_by 491
  Abstract: Abstract When people make decisions with a pre-selected choice option – a ‘default’ – they are more likely to select that option. Because defaults are easy to implement, they constitute one of the most widely employed tools in the choice architecture toolbox. However, to decide when defaults should be used instead of other choice architecture tools, policy-makers must know how effective defaults are and when and why their effectiveness varies. To answer these questions, we conduct a literature search and meta-analysis of the 58 default studies (pooled n = 73,675) that fit our criteria. While our analysis reveals a considerable influence of defaults ( d = 0.68, 95% confidence interval = 0.53–0.83), we also discover substantial variation: the majority of default studies find positive effects, but several do not find a significant effect, and two even demonstrate negative effects. To explain this variability, we draw on existing theoretical frameworks to examine the drivers of disparity in effectiveness. Our analysis reveals two factors that partially account for the variability in defaults’ effectiveness. First, we find that defaults in consumer domains are more effective and in envi
