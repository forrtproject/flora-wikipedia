# Evidence packet 9148bd2437f3f0e96106: Choice architecture

Frozen revision: 1376379283 (2026-09-23T20:47:13Z); https://en.wikipedia.org/w/index.php?oldid=1376379283
Live check: {"frozen_revid": "1376379283", "title": "Choice architecture", "live_revid": 1376379283, "live_timestamp": "2026-09-23T20:47:13Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "broad_topic", "context_kind": "inline", "living_person_category": false, "health_term_flag": true, "co_cited": false, "large_project": false, "flora_originals_on_page": 2}

## Article lead (plain rendering, approximate)
Choice architecture is the design of different ways in which choices can be presented to decision makers, and the impact of that presentation on decision-making. Choice architecture is the design of different ways in which choices can be presented to consumers, and the impact of that presentation on consumer decision-making. In workplace organizations the actual deployment of choice architecture interventions  has mostly been found to be agreeable not only to employs but also to the implementers, primarily when the interventions facilitate the consumption of healthy food and physical activity without binding any choices. [ref: Rantala (2023) "Acceptability of workplace choice architecture modification for health" doi:10.1186/s12889-023-17331-x]Choice architecture refers to how options are arranged and presented, and it influences decision making across a wide range of everyday and significant choices. [ref: (2013) "A nudge in the right direction" doi:10.1016/S0262-4079(13)61510-9]Nudging is a concept in behavioral science, political theory and economics which argues that positive reinforcement and indirect suggestions can influence behavior and decision-making .Research suggests that the activation of personal norms through choice architecture nudges is a particularly effective compared to simply relying on social pressures. [ref: Trujillo (2021) "Norm-focused nudges influence pro-environmental choices and moderate p" doi:10.1371/journal.pone.0247519] Several factors in choice architecture can influence decision- making including:

* the number of choices presented [ref: Scheibehenne (2010) "Can there ever be too many options? A meta-analytic review of choice o" doi:10.1086/651235]
* the manner in which attributes are described [ref: Larrick (2008) "The MPG Illusion" doi:10.1126/science.1154983]
* the presence of a default option [ref: Johnson (2003) "Do Defaults Save Lives?" doi:10.1126/science.1091721] [ref: Cronqvist (2004) "Design choices in privatized social security systems: Learning from th" doi:10.1257/0002828041301632]

these elements can significantly affect consumer choice. As a result, advocates of libertarian paternalism and asymmetric paternalism have endorsed the deliberate design of choice architecture to nudge consumers toward personally and socially desirable behaviors like saving for retirement, choosing healthier foods, or registering as an organ donor. These interventions are often justified by advocates of libertarian paternalism in that well-designed choice architectures can compensate for irrational decision-making biases to improve consumer welfare. [ref: Thaler (2013) "The Behavioral Foundations of Public Policy"] These techniques have consequently become popular among policymakers, leading to the formation of the UK's Behavioural Insights Team and the White House "Nudge Unit" for example. [ref: Nesterak "Head of White House "Nudge Unit" Maya Shankar Speaks about Newly Forme"] While many behavioral scientists stress that there is no neutral choice-architecture and that consumers maintain autonomy and freedom of choice despite manipulations of choice architecture, [ref: Johnson (2012) "Beyond Nudges: Tools of a choice architecture" doi:10.1007/s11002-012-9186-1] critics of libertarian paternalism often argue that choice architectures designed to overcome irrational decision biases may impose costs on rational agents, for example by limiting choice [ref: Mitchell (2005) "Libertarian Paternalism is an Oxymoron"] o

## Article outline
Background
Elements
  Reducing choice overload
  Defaults
  Choice over time
  Partitioning options and attributes
  Avoiding attribute overload
  Translating attributes
Examples
Criticisms
Terminology
See also
References
External links

## Categories
Behavioral finance; Decision-making; Libertarian terms; Political philosophy; Selling techniques; Decision theory

## Occurrence 1: original DOI 10.1111/1467-9280.02431 in section 'Partitioning options and attributes'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
===Partitioning options and attributes===
The ways in which options and attributes are grouped influence the choices that are made. Examples of such partitioning of options include the division of a household budget into categories (e.g. rent, food, utilities, transportation etc.), or categories of investments within a portfolio (e.g. real estate, stocks, bonds, etc.), while examples of partitioning attributes include the manner in which attributes are grouped together for example a label may group several related attributes together (e.g. convenient) or list them individually (e.g. short running time, little cleanup, low maintenance). The number and type of these categories is important because individuals have a tendency to allocate scarce resources equally across them. People tend to divide investments over the options listed in 401K plans [ref: Benartzi (2001) "Naive Diversification Strategies in Defined Contribution Saving Plans" doi:10.1257/aer.91.1.79] they favor equal allocation of resources and costs across individuals (all else being equal), [ref: Messick (1993) "Equality as a decision heuristic" doi:10.1017/CBO9780511552069.003] and are biased to assign equal probabilities to all events that could occur. [ref: Fox (2005) "Subjective probability assessment in decision analysis: partition depe" doi:10.1287/mnsc.1050.0409] [FOCAL REF: Fox (2003) "Partition priming in judgement in judgement under uncertainty" doi:10.1111/1467-9280.02431] As a result, aggregate consumption can be changed by the number and types of categorizations. For instance, car buyers can be nudged toward more responsible purchases by itemizing practical attributes (gas mileage, safety, warranty etc.) and aggregating less practical attributes (i.e. speed, radio, and design are grouped together as "stylishness"). [ref: Martin (2009) "Shaping online consumer choice by partitioning the web" doi:10.1002/mar.20305]

### Paragraph (raw wikitext)
```
===Partitioning options and attributes===
The ways in which options and attributes are grouped influence the choices that are made. Examples of such partitioning of options include the division of a household budget into categories (e.g. rent, food, utilities, transportation etc.), or categories of investments within a portfolio (e.g. real estate, stocks, bonds, etc.), while examples of partitioning attributes include the manner in which attributes are grouped together for example a label may group several related attributes together (e.g. convenient) or list them individually (e.g. short running time, little cleanup, low maintenance). The number and type of these categories is important because individuals have a tendency to allocate scarce resources equally across them. People tend to divide investments over the options listed in 401K plans<ref>{{cite journal|last1=Benartzi|first1=S.|last2=Thaler|first2=R.|title=Naive Diversification Strategies in Defined Contribution Saving Plans|journal=American Economic Review|date=2001|volume=91|pages=79–98|doi=10.1257/aer.91.1.79|s2cid=14955737 }}</ref> they favor equal allocation of resources and costs across individuals (all else being equal),<ref>{{cite journal|last1=Messick|first1=D.M.|title=Equality as a decision heuristic|journal=In Psychological Perspectives on Justice|date=1993|pages=11–31|doi=10.1017/CBO9780511552069.003|isbn=978-0-521-43199-6}}</ref> and are biased to assign equal probabilities to all events that could occur.<ref>{{cite journal|last1=Fox|first1=C.R.|last2=Clemen|first2=R.T.|title=Subjective probability assessment in decision analysis: partition dependence and bias toward the ignorance prior|journal=Management Science|date=2005|volume=51|issue=9|doi=10.1287/mnsc.1050.0409|pages=1417–1432|s2cid=14760347}}</ref><ref>{{cite journal|last1=Fox|first1=C.R.|last2=Rottenstreich|first2=Y.|title=Partition priming in judgement in judgement under uncertainty|journal=Psychological Science|date=2003|volume=14|issue=3|doi=10.1111/1467-9280.02431|pages=195–200|pmid=12741740|s2cid=12590325}}</ref> As a result, aggregate consumption can be changed by the number and types of categorizations. For instance, car buyers can be nudged toward more responsible purchases by itemizing practical attributes (gas mileage, safety, warranty etc.) and aggregating less practical attributes (i.e. speed, radio, and design are grouped together as "stylishness").<ref>{{cite journal|last1=Martin|first1=J.M.|last2=Norton|first2=M.I.|title=Shaping online consumer choice by partitioning the web|journal=Psychology and Marketing|date=2009|volume=26|issue=10|pages=908–926|doi=10.1002/mar.20305}}</ref>
```

### Full section (plain rendering)
===Partitioning options and attributes===
The ways in which options and attributes are grouped influence the choices that are made. Examples of such partitioning of options include the division of a household budget into categories (e.g. rent, food, utilities, transportation etc.), or categories of investments within a portfolio (e.g. real estate, stocks, bonds, etc.), while examples of partitioning attributes include the manner in which attributes are grouped together for example a label may group several related attributes together (e.g. convenient) or list them individually (e.g. short running time, little cleanup, low maintenance). The number and type of these categories is important because individuals have a tendency to allocate scarce resources equally across them. People tend to divide investments over the options listed in 401K plans [ref: Benartzi (2001) "Naive Diversification Strategies in Defined Contribution Saving Plans" doi:10.1257/aer.91.1.79] they favor equal allocation of resources and costs across individuals (all else being equal), [ref: Messick (1993) "Equality as a decision heuristic" doi:10.1017/CBO9780511552069.003] and are biased to assign equal probabilities to all events that could occur. [ref: Fox (2005) "Subjective probability assessment in decision analysis: partition depe" doi:10.1287/mnsc.1050.0409] [FOCAL REF: Fox (2003) "Partition priming in judgement in judgement under uncertainty" doi:10.1111/1467-9280.02431] As a result, aggregate consumption can be changed by the number and types of categorizations. For instance, car buyers can be nudged toward more responsible purchases by itemizing practical attributes (gas mileage, safety, warranty etc.) and aggregating less practical attributes (i.e. speed, radio, and design are grouped together as "stylishness"). [ref: Martin (2009) "Shaping online consumer choice by partitioning the web" doi:10.1002/mar.20305]

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 9148bd2437f3f0e96106/article_plain.txt in the evidence directory.)

- * the number of choices presented [ref: Scheibehenne (2010) "Can there ever be too many options? A meta-analytic review of choice o" doi:10.1086/651235]
* the manner in which attributes are described [ref: Larrick (2008) "The MPG Illusion" doi:10.1126/science.1154983]
* the presence of a default option [ref: Johnson (2003) "Do Defaults Save Lives?" doi:10.1126/science.1091721] [ref: Cronqvist (2004) "Design choices in privatized social security systems: Learning from th" doi:10.1257/0002828041301632]

## ORIGINAL STUDY: doi:10.1111/1467-9280.02431 (FLoRA title: Partition Priming in Judgment Under Uncertainty)
Crossref: Partition Priming in Judgment Under Uncertainty | Craig R. Fox, Yuval Rottenstreich | Psychological Science | 2003 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2106307464", "type": "article", "publication_year": 2003, "cited_by_count": 249, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1111_1467_9280_02431.txt (Free copy found by source search (published): https://598f3c0e-531c-4140-a159-ac5f745bc10b.filesusr.com/ugd/feb64a_a0b789fdfe9045f89ebf3df9d351b694.pdf)
Retrieved: 2026-10-06T16:15:38+00:00
### Abstract (Crossref deposited abstract)
We show that likelihood judgments are biased toward an ignorance-prior probability that assigns equal credence to each mutually exclusive event considered by the judge. The value of the ignorance prior depends crucially on how the set of possibilities (i.e., the state space) is subjectively partitioned by the judge. For instance, asking “what is the probability that Sunday will be hotter than any other day next week?” facilitates a two-fold case partition, (Sunday hotter, Sunday not hotter), thus priming an ignorance prior of 1/2. In contrast, asking “what is the probability that the hottest day of the week will be Sunday?” facilitates a seven-fold class partition, (Sunday hottest, Monday hottest, etc.), priming an ignorance prior of 1/7. In four studies, we observed systematic partition dependence: Judgments made by participants presented with either case or class formulations of the same query were biased toward the corresponding ignorance prior.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1098/rsos.250669 (FLoRA title: Revisiting partition priming in judgement under uncertainty: replication and extension Registered Report of Fox and Rottenstreich (2003); FLoRA outcome code: mixed [screening input only, not citable]; DOI detected on page: False)
Crossref: Revisiting partition priming in judgement under uncertainty: replication and extension Registered Report of Fox and Rottenstreich (2003) | Kerou Ding, Gilad Feldman | Royal Society Open Science | 2025 | type journal-article
Updates/relations (Crossref): [] {"has-review": [{"id-type": "doi", "id": "10.1098/RSOS.250669/v1/decision1", "asserted-by": "object"}, {"id-type": "doi", "id": "10.1098/RSOS.250669/v2/decision1", "asserted-by": "object"}, {"id-type": "doi", "id": "10.1098/RSOS.250669/v2/response1", "asserted-by": "object"}]}
OpenAlex: {"id": "https://openalex.org/W4412109780", "type": "article", "publication_year": 2025, "cited_by_count": 1, "is_retracted": false, "oa_status": "gold", "oa_pdf": null, "oa_landing": "https://doi.org/10.1098/rsos.250669"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext/10_1098_rsos_250669.txt (Europe PMC open-access full text (PMC12308232))
Retrieved: 2026-10-06T16:15:39+00:00
### Abstract (Crossref deposited abstract)
Partition dependence is the phenomenon in which individuals’ evaluations of probabilities are influenced by the partitioning of the information in the way the information is presented or framed. In a Registered Report experiment with an American online Prolific sample (
                     N 
                    = 603), we conducted a replication and extension of Studies 1a, 1b, 3 and 4 from a classic article by Fox and Rottenstreich (Fox & Rottenstreich 2003
                     Psychol. Sci 
                    .
                     14 
                    , 195–200 (doi:
                     10.1111/1467-9280.02431 
                    )) demonstrating the phenomenon. They showed that participants’ estimations of an event’s likelihood shifted based on minor adjustments of the framing that suggested a change in partitioning perspective (‘ignorance prior’ priming). Based on a pre-registered replication evaluation criterion, we concluded a mostly successful replication of the findings of Fox and Rottenstreich (2003). Specifically, we found support for partition dependence in scenarios from Study 1a Items 1 and 2, Study 1b and Study 3, with weaker effects, yet with no consistent support for Study 1a Item 3 and Study 4. Our extensions further explored the robustness of partition dependence by examining participants’ probability evaluations of complementary events (happen versus not happen) and the impact of task order on judgement and decision making. Overall, the findings suggest support for partition dependence, yet as more nuanced and context-dependent than expected, and the need for further research to understand its mechanisms, robustness and implications across different contexts. Materials, data and code are available on at
                     https://osf.io/g9czs/ 
                    . This Registered Report has been officially endorsed by Peer Community in Registered Reports:
                     https://doi.org/10.24072/pci.rr.100877 
                    .

## Other database studies cited on this same page (each has its own packet; drafted together)
- 6a61b434691693f085f2: Do Defaults Save Lives? (doi:10.1126/science.1091721)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1098/rsos.250669 | Revisiting partition priming in judgement under uncertainty: replication and extension Registered Report of Fox and Rottenstreich (2003) | 2025 | read: abstract | mentions replication: False

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [cites original and replication 10.1098/rsos.250669] doi:10.1098/rsos.250669 | Revisiting partition priming in judgement under uncertainty: replication and extension Registered Report of Fox and Rottenstreich (2003) | 2025 | article | cited_by 1
  Abstract: Partition dependence is the phenomenon in which individuals’ evaluations of probabilities are influenced by the partitioning of the information in the way the information is presented or framed. In a Registered Report experiment with an American online Prolific sample ( N = 603), we conducted a replication and extension of Studies 1a, 1b, 3 and 4 from a classic article by Fox and Rottenstreich (Fox & Rottenstreich 2003 Psychol. Sci . 14 , 195–200 (doi: 10.1111/1467-9280.02431 )) demonstrating the phenomenon. They showed that participants’ estimations of an event’s likelihood shifted based on minor adjustments of the framing that suggested a change in partitioning perspective (‘ignorance prior’ priming). Based on a pre-registered replication evaluation criterion, we concluded a mostly successful replication of the findings of Fox and Rottenstreich (2003). Specifically, we found support for partition dependence in scenarios from Study 1a Items 1 and 2, Study 1b and Study 3, with weaker effects, yet with no consistent support for Study 1a Item 3 and Study 4. Our extensions further explored the robustness of partition dependence by examining participants’ probability evaluations of com
