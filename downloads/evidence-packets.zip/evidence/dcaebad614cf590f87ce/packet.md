# Evidence packet dcaebad614cf590f87ce: Money illusion

Frozen revision: 1341877605 (2026-03-05T18:04:27Z); https://en.wikipedia.org/w/index.php?oldid=1341877605
Live check: {"frozen_revid": "1341877605", "title": "Money illusion", "live_revid": 1341877605, "live_timestamp": "2026-03-05T18:04:27Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "central_effect", "context_kind": "inline", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 1}

## Article lead (plain rendering, approximate)
In economics, money illusion, or price illusion, is a cognitive bias where money is thought of in nominal, rather than real terms. In other words, the face value (nominal value) of money is mistaken for its purchasing power (real value) at a previous point in time. Viewing purchasing power as measured by the nominal value is false, as modern fiat currencies have no intrinsic value and their real value depends purely on the price level. The term was coined by Irving Fisher in Stabilizing the Dollar. It was popularized by John Maynard Keynes in the early twentieth century, and Irving Fisher wrote an important book on the subject, The Money Illusion, in 1928. [ref: Fisher (1928) "The Money Illusion"]

The existence of money illusion is disputed by monetary economists who contend that people act rationally (i.e. think in real prices) with regard to their wealth. [ref: Marianne Bertran (2004) "A behavioral-economics view of poverty" doi:10.1257/0002828041302019] Eldar Shafir, Peter A. Diamond, and Amos Tversky (1997) have provided empirical evidence for the existence of the effect and it has been shown to affect behaviour in a variety of experimental and real-world situations. [FOCAL REF: Shafir (1997) "On Money Illusion" doi:10.1162/003355397555208]

Shafir et al. [FOCAL REF: Shafir (1997) "On Money Illusion" doi:10.1162/003355397555208] also state that money illusion influences economic behaviour in three main ways:

*Price stickiness. Money illusion has been proposed as one reason why nominal prices are slow to change even where inflation has caused real prices to fall or costs to rise.
*Contracts and laws are not indexed to inflation as frequently as one would rationally expect.
*Social discourse, in formal media and more generally, reflects some confusion about real and nominal value.

Money illusion can also influence people's perceptions of outcomes. Experiments have shown that people generally perceive an approximate 2% cut in nominal income with no change in monetary value as unfair, but see a 2% rise in nominal income where there is 4% inflation as fair, despite them being almost rational equivalents. This result is consistent with the 'Myopic Loss Aversion theory'. [ref: Benartzi (1995) "Myopic Loss Aversion and the Equity Premium Puzzle" doi:10.2307/2118511] Furthermore, the money illusion means nominal changes in price can influence demand even if real prices have remained constant. [ref: Patinkin (1969) "The Chicago Tradition, The Quantity Theory, And Friedman" doi:10.2307/1991376]

## Article outline
Explanations and implications
See also
References
Further reading

## Categories
Heuristics; Inflation; Behavioral finance; Cognitive biases

## Occurrence 1: original DOI 10.1162/003355397555208 in section '(lead)'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
The existence of money illusion is disputed by monetary economists who contend that people act rationally (i.e. think in real prices) with regard to their wealth. [ref: Marianne Bertran (2004) "A behavioral-economics view of poverty" doi:10.1257/0002828041302019] Eldar Shafir, Peter A. Diamond, and Amos Tversky (1997) have provided empirical evidence for the existence of the effect and it has been shown to affect behaviour in a variety of experimental and real-world situations. [FOCAL REF: Shafir (1997) "On Money Illusion" doi:10.1162/003355397555208]

### Paragraph (raw wikitext)
```
The existence of money illusion is disputed by [[monetary]] economists  who contend that people act rationally (i.e. think in real prices) with regard to their wealth.<ref name=poverty>{{cite journal|author1=Marianne Bertran |author2=Sendhil Mullainathan |author3=Eldar Shafir  |name-list-style=amp |title=A behavioral-economics view of poverty|journal=The American Economic Review|date=May 2004|volume=94|issue=2|pages=419–423|jstor=3592921|doi=10.1257/0002828041302019|s2cid=2865749 |url=https://dash.harvard.edu/bitstream/1/2907437/2/behav%20econ%20poverty.pdf }}</ref> [[Eldar Shafir]], [[Peter A. Diamond]], and [[Amos Tversky]] (1997) have provided  [[empirical evidence]] for the existence of the effect and it has been shown to affect behaviour in a variety of experimental and real-world situations.<ref name="Shafir">{{Citation |last1=Shafir |first1=E. |last2=Diamond |first2=P. A. |last3=Tversky |first3=A. |year=1997 |title=On Money Illusion |journal=Quarterly Journal of Economics |volume=112 |issue=2 |pages=341–374 |doi=10.1162/003355397555208 }}</ref>
```

### Full section (plain rendering)
In economics, money illusion, or price illusion, is a cognitive bias where money is thought of in nominal, rather than real terms. In other words, the face value (nominal value) of money is mistaken for its purchasing power (real value) at a previous point in time. Viewing purchasing power as measured by the nominal value is false, as modern fiat currencies have no intrinsic value and their real value depends purely on the price level. The term was coined by Irving Fisher in Stabilizing the Dollar. It was popularized by John Maynard Keynes in the early twentieth century, and Irving Fisher wrote an important book on the subject, The Money Illusion, in 1928. [ref: Fisher (1928) "The Money Illusion"]

The existence of money illusion is disputed by monetary economists who contend that people act rationally (i.e. think in real prices) with regard to their wealth. [ref: Marianne Bertran (2004) "A behavioral-economics view of poverty" doi:10.1257/0002828041302019] Eldar Shafir, Peter A. Diamond, and Amos Tversky (1997) have provided empirical evidence for the existence of the effect and it has been shown to affect behaviour in a variety of experimental and real-world situations. [FOCAL REF: Shafir (1997) "On Money Illusion" doi:10.1162/003355397555208]

Shafir et al. [FOCAL REF: Shafir (1997) "On Money Illusion" doi:10.1162/003355397555208] also state that money illusion influences economic behaviour in three main ways:

*Price stickiness. Money illusion has been proposed as one reason why nominal prices are slow to change even where inflation has caused real prices to fall or costs to rise.
*Contracts and laws are not indexed to inflation as frequently as one would rationally expect.
*Social discourse, in formal media and more generally, reflects some confusion about real and nominal value.

Money illusion can also influence people's perceptions of outcomes. Experiments have shown that people generally perceive an approximate 2% cut in nominal income with no change in monetary value as unfair, but see a 2% rise in nominal income where there is 4% inflation as fair, despite them being almost rational equivalents. This result is consistent with the 'Myopic Loss Aversion theory'. [ref: Benartzi (1995) "Myopic Loss Aversion and the Equity Premium Puzzle" doi:10.2307/2118511] Furthermore, the money illusion means nominal changes in price can influence demand even if real prices have remained constant. [ref: Patinkin (1969) "The Chicago Tradition, The Quantity Theory, And Friedman" doi:10.2307/1991376]

==Explanations and implications==

Explanations of money illusion generally describe the phenomenon in terms of heuristics. Nominal prices provide a convenient rule of thumb for determining value and real prices are only calculated if they seem highly salient (e.g. in periods of hyperinflation or in long term contracts).

Some have suggested that money illusion implies that the negative relationship between inflation and unemployment described by the Phillips curve might hold, contrary to more recent macroeconomic theories such as the "expectations-augmented Phillips curve". [ref: Romer (2006) "Advanced macroeconomics"] If workers use their nominal wage as a reference point when evaluating wage offers, firms can keep real wages relatively lower in a period of high inflation as workers accept the seemingly high nominal wage increase. These lower real wages would allow firms to hire more workers in periods of high inflation.

Money illusion is believed to be instrumental in the Friedmanian version of the Phillips curve. Actually, money illusion is not enough to explain the mechanism underlying this Phillips curve. It requires two additional assumptions. First, prices respond differently to modified demand conditions: an increased aggregate demand exerts its influence on commodity prices sooner than it does on labour market prices. Therefore, the drop in unemployment is, after all, the result of decreasing real wages and an accurate judgement of the situation by employees is the only reason for the return to an initial (natural) rate of unemployment (i.e. the end of the money illusion, when they finally recognize the actual dynamics of prices and wages). The other (arbitrary) assumption refers to a special informational asymmetry: whatever employees are unaware of in connection with the changes in (real and nominal) wages and prices can be clearly observed by employers. The new classical version of the Phillips curve was aimed at removing the puzzling additional presumptions, but its mechanism still requires money illusion. [ref: Galbács (2015) "The Theory of New Classical Macroeconomics. A Positive Critique" doi:10.1007/978-3-319-17578-2]

==See also==

*Behavioural economics
*Fiscal Illusion
*Framing (social science)
*Homo economicus
*Map-territory relation

==References==

==Further reading==
*[Fehr (2001) "Does Money Illusion Matter?" doi:10.1257/aer.91.5.1239]
*[Howitt (1987) "The New Palgrave: A Dictionary of Economics"]
*[Weber (2009) "The medial prefrontal cortex exhibits money illusion" doi:10.1073/pnas.0901490106]
*[Akerlof (2009) "Animal Spirits"]
* Thaler, Richard H.(1997) "Irving Fisher: Modern Behavioral Economist" in The American Economic Review Vol 87, No 2, Papers and Proceedings of the Hundred and Fourth Annual Meeting of the American Economic Association (May, 1997)
*Huw Dixon (2008), New Keynesian Economics, New Palgrave Dictionary of Economics New Keynesian macroeconomics.

## Occurrence 2: original (named-reference reuse) DOI 10.1162/003355397555208 in section '(lead)'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
Shafir et al. [FOCAL REF: Shafir (1997) "On Money Illusion" doi:10.1162/003355397555208] also state that money illusion influences economic behaviour in three main ways:

### Paragraph (raw wikitext)
```
Shafir et al.<ref name="Shafir" /> also state that money illusion influences economic behaviour in three main ways:
```

### Full section (plain rendering)
In economics, money illusion, or price illusion, is a cognitive bias where money is thought of in nominal, rather than real terms. In other words, the face value (nominal value) of money is mistaken for its purchasing power (real value) at a previous point in time. Viewing purchasing power as measured by the nominal value is false, as modern fiat currencies have no intrinsic value and their real value depends purely on the price level. The term was coined by Irving Fisher in Stabilizing the Dollar. It was popularized by John Maynard Keynes in the early twentieth century, and Irving Fisher wrote an important book on the subject, The Money Illusion, in 1928. [ref: Fisher (1928) "The Money Illusion"]

The existence of money illusion is disputed by monetary economists who contend that people act rationally (i.e. think in real prices) with regard to their wealth. [ref: Marianne Bertran (2004) "A behavioral-economics view of poverty" doi:10.1257/0002828041302019] Eldar Shafir, Peter A. Diamond, and Amos Tversky (1997) have provided empirical evidence for the existence of the effect and it has been shown to affect behaviour in a variety of experimental and real-world situations. [FOCAL REF: Shafir (1997) "On Money Illusion" doi:10.1162/003355397555208]

Shafir et al. [FOCAL REF: Shafir (1997) "On Money Illusion" doi:10.1162/003355397555208] also state that money illusion influences economic behaviour in three main ways:

*Price stickiness. Money illusion has been proposed as one reason why nominal prices are slow to change even where inflation has caused real prices to fall or costs to rise.
*Contracts and laws are not indexed to inflation as frequently as one would rationally expect.
*Social discourse, in formal media and more generally, reflects some confusion about real and nominal value.

Money illusion can also influence people's perceptions of outcomes. Experiments have shown that people generally perceive an approximate 2% cut in nominal income with no change in monetary value as unfair, but see a 2% rise in nominal income where there is 4% inflation as fair, despite them being almost rational equivalents. This result is consistent with the 'Myopic Loss Aversion theory'. [ref: Benartzi (1995) "Myopic Loss Aversion and the Equity Premium Puzzle" doi:10.2307/2118511] Furthermore, the money illusion means nominal changes in price can influence demand even if real prices have remained constant. [ref: Patinkin (1969) "The Chicago Tradition, The Quantity Theory, And Friedman" doi:10.2307/1991376]

==Explanations and implications==

Explanations of money illusion generally describe the phenomenon in terms of heuristics. Nominal prices provide a convenient rule of thumb for determining value and real prices are only calculated if they seem highly salient (e.g. in periods of hyperinflation or in long term contracts).

Some have suggested that money illusion implies that the negative relationship between inflation and unemployment described by the Phillips curve might hold, contrary to more recent macroeconomic theories such as the "expectations-augmented Phillips curve". [ref: Romer (2006) "Advanced macroeconomics"] If workers use their nominal wage as a reference point when evaluating wage offers, firms can keep real wages relatively lower in a period of high inflation as workers accept the seemingly high nominal wage increase. These lower real wages would allow firms to hire more workers in periods of high inflation.

Money illusion is believed to be instrumental in the Friedmanian version of the Phillips curve. Actually, money illusion is not enough to explain the mechanism underlying this Phillips curve. It requires two additional assumptions. First, prices respond differently to modified demand conditions: an increased aggregate demand exerts its influence on commodity prices sooner than it does on labour market prices. Therefore, the drop in unemployment is, after all, the result of decreasing real wages and an accurate judgement of the situation by employees is the only reason for the return to an initial (natural) rate of unemployment (i.e. the end of the money illusion, when they finally recognize the actual dynamics of prices and wages). The other (arbitrary) assumption refers to a special informational asymmetry: whatever employees are unaware of in connection with the changes in (real and nominal) wages and prices can be clearly observed by employers. The new classical version of the Phillips curve was aimed at removing the puzzling additional presumptions, but its mechanism still requires money illusion. [ref: Galbács (2015) "The Theory of New Classical Macroeconomics. A Positive Critique" doi:10.1007/978-3-319-17578-2]

==See also==

*Behavioural economics
*Fiscal Illusion
*Framing (social science)
*Homo economicus
*Map-territory relation

==References==

==Further reading==
*[Fehr (2001) "Does Money Illusion Matter?" doi:10.1257/aer.91.5.1239]
*[Howitt (1987) "The New Palgrave: A Dictionary of Economics"]
*[Weber (2009) "The medial prefrontal cortex exhibits money illusion" doi:10.1073/pnas.0901490106]
*[Akerlof (2009) "Animal Spirits"]
* Thaler, Richard H.(1997) "Irving Fisher: Modern Behavioral Economist" in The American Economic Review Vol 87, No 2, Papers and Proceedings of the Hundred and Fourth Annual Meeting of the American Economic Association (May, 1997)
*Huw Dixon (2008), New Keynesian Economics, New Palgrave Dictionary of Economics New Keynesian macroeconomics.

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: dcaebad614cf590f87ce/article_plain.txt in the evidence directory.)

- The existence of money illusion is disputed by monetary economists who contend that people act rationally (i.e. think in real prices) with regard to their wealth. [ref: Marianne Bertran (2004) "A behavioral-economics view of poverty" doi:10.1257/0002828041302019] Eldar Shafir, Peter A. Diamond, and Amos Tversky (1997) have provided empirical evidence for the existence of the effect and it has been shown to affect behaviour in a variety of experimental and real-world situations. [FOCAL REF: Shafir (1997) "On Money Illusion" doi:10.1162/003355397555208]

## ORIGINAL STUDY: doi:10.1162/003355397555208 (FLoRA title: Money Illusion)
Crossref: Money Illusion | E. Shafir, P. Diamond, A. Tversky | The Quarterly Journal of Economics | 1997 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W4233461763", "type": "article", "publication_year": 1997, "cited_by_count": 630, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: ABSTRACT
Retrieved: 2026-10-06T16:10:26+00:00
### Abstract (OpenAlex reconstructed abstract)
The term “money illusion” refers to a tendency to think in terms of nominal rather than real monetary values. Money illusion has significant implications for economic theory, yet it implies a lack of rationality that is alien to economists. This paper reviews survey questions regarding people's reactions to variations in inflation and prices, designed to shed light on the psychology that underlies money illusion. We propose that people often think about economic transactions in both nominal and real terms, and that money illusion arises from an interaction between these representations, which results in a bias toward a nominal evaluation.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1016/j.joep.2020.102349 (FLoRA title: Revisiting “money illusion”: Replication and extension of Shafir, Diamond, and Tversky (1997); FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: Revisiting “money illusion”: Replication and extension of Shafir, Diamond, and Tversky (1997) | Ignazio Ziano, Jie Li, Shue Man Tsun, Hoi Ching Lei, Anvita Anil Kamath, Bo Ley Cheng et al. | Journal of Economic Psychology | 2021 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W3118114617", "type": "article", "publication_year": 2020, "cited_by_count": 17, "is_retracted": false, "oa_status": "gold", "oa_pdf": null, "oa_landing": "https://osf.io/rv9mw"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1016_j_joep_2020_102349.txt (Free copy found by source search (accepted manuscript): https://osf.io/download/vtcmn/)
Retrieved: 2026-10-06T16:10:27+00:00
### Abstract (OpenAlex reconstructed abstract)
Shafir et al. (1997) described money illusion as people’s inclination to think of money without taking inflation sufficiently into account, i.e., in nominal terms rather than in real terms. We successfully replicated Problems 1 to 4 of Shafir, Diamond, and Tversky’s study (1997) on money illusion (MTurk; N = 604). We found effect sizes in line with the original ones for assessments of income (Problem 1; original: Cramer’s V = 0.26, 95% CI [0.17, 0.37]; replication: V = 0.28 [0.21, 0.36]), transactions (Problem 2; original: 48% [42%, 52%]; replication: 70% [66%, 73%]), sales and consumption (Problem 3; original buy: 38% [33%, 43%]; replication buy: 47% [43%, 51%]; original sell: 43%% [38%, 48%]; replication sell: 43% [39%, 47%]), and contracts (Problem 4; original: V = 0.25 [0.13, 0.42]; replication: V = 0.17 [0.10, 0.25]). With an added extension, we found no support for the notion that knowing about or correctly estimating the inflation rate affected money illusion. We discuss theoretical implications for the study of money illusion and the psychological meaning of inflation, as well as for the understanding of the antecedents of money illusion. All data, code, and materials are available on https://osf.io/rv9mw/ .

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1016/j.joep.2023.102665 | Transcranial stimulation over the medial prefrontal cortex increases money illusion | 2023 | read: metadata_only | mentions replication: False
- doi:10.1111/ssqu.13121 | Context and the Perceived Fairness of Price Increases Coming out of COVID‐19 | 2022 | read: abstract | mentions replication: False
- doi:10.31234/osf.io/fh597 | Replication of the “money illusion” effect in a Brazilian sample | 2023 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_31234_osf_io_fh597.txt
  Snippet: inertia", as proposed by fehr & tyran (2001). despite its widespread citation and application across various fields, the original study has not yet received consistent and direct replication. as of now, there has been only one such attempt, in which ziano and colleagues (2021) conducted a replication study with very close results to the original study. acknowledging that enhancing a theory's generalizability entails subjecting it to new evidence (nosek & errington, 2020), our study endeavors to adapt
  Snippet: lem was completed, the data was included in the analysis (for the total sample for each problem, see table s1). the self-administered questionnaire was created using the qualtrics xm platform and the structure was adapted from the study conducted by ziano et al. (2021). the questionnaire's link was disseminated through social networks. data collection took place online over a period of 8 months, spanning from december 2021 to july 2022. open science framework in accordance with best practices in repr
- doi:10.1186/s12651-021-00284-2 | Can reference points explain wage rigidity? Experimental evidence | 2021 | read: abstract | mentions replication: False
- doi:10.1016/j.joep.2024.102744 | Replication: The money illusion effect in a Brazilian sample and meta-analyses | 2024 | read: metadata_only | mentions replication: False

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1146/annurev.economics.050708.143217 | A Behavioral Account of the Labor Market: The Role of Fairness Concerns | 2009 | review | cited_by 314
  Abstract: In this paper, we argue that important labor market phenomena can be better understood if one takes (a) the inherent incompleteness and relational nature of most employment contracts and (b) the existence of reference-dependent fairness concerns among a substantial share of the population into account. Theory shows and experiments confirm that, even if fairness concerns were to exert only weak effects in one-shot interactions, repeated interactions greatly magnify the relevance of such concerns on economic outcomes. We also review evidence from laboratory and field experiments examining the role of wages and fairness on effort, derive predictions from our approach for entry-level wages and incumbent workers' wages, confront these predictions with the evidence, and show that reference-dependent fairness concerns may have important consequences for the effects of economic policies such as minimum wage laws.
- [cites original and replication 10.1016/j.joep.2020.102349] doi:10.1016/j.joep.2023.102665 | Transcranial stimulation over the medial prefrontal cortex increases money illusion | 2023 | article | cited_by 6
  Abstract: (none)
- [cites original and replication 10.1016/j.joep.2020.102349] doi:10.1111/ssqu.13121 | Context and the Perceived Fairness of Price Increases Coming out of COVID‐19 | 2022 | article | cited_by 6
  Abstract: Objective: As the U.S. economy responds to prolonged COVID-19 disruptions, it is important to understand what factors affect the perceived fairness of pandemic-driven price increases. Methods: Participants read a vignette and rated how fair they found a pandemic-driven price increase. Versions vary (1) the source (hardware-store products or bus fare), (2) the magnitude of the price increase (6 percent or 18 percent), and (3) the tone of an initial description of COVID (positive or negative). Results: The price increase was perceived to be fairer when it involved the hardware store or when it was smaller. The relationship between fairness and magnitude was context-specific, as fairness perceptions were insensitive to the magnitude of the price increase in the bus scenario or when the initial description of COVID had a positive tone. Conclusion: Retailers and municipalities may face different fairness constraints as they consider pandemic-driven price increases. The tone of COVID information may affect price fairness through its impact on sensitivity to magnitude.
- [cites original and replication 10.1016/j.joep.2020.102349] doi:10.31234/osf.io/fh597 | Replication of the “money illusion” effect in a Brazilian sample | 2023 | preprint | cited_by 3
  Abstract: Shafir, Diamond, and Tversky (1997, Money illusion, The Quarterly Journal of Economics, 112(2), 341–374) described the phenomenon of money illusion as the inclination to consider money without adequately taking into account the inflation factor, emphasizing nominal values rather than real ones. This study aims to replicate the four conditions outlined in the original research by Shafir and colleagues, adapted to the Brazilian context: problems that include different situations (earnings, transactions, contracts) in which people should make financial decisions that might be affected by money illusion. This cross-sectional and pre-registered study evaluated the money illusion in a sample of 372 Brazilian participants, conducted via mobile phone/computer. Inferential analyses of all problems were performed with the chi-square test (X²), and the results found were very similar to the original findings: depending on the terms used (real, nominal, or neutral framing), participants showed varying inclinations towards opting for economically advantageous opportunities. The present study successfully replicated all four problems, both in the complete sample and the sensitivity analyses, whi
- [cites original and replication 10.1016/j.joep.2020.102349] doi:10.1186/s12651-021-00284-2 | Can reference points explain wage rigidity? Experimental evidence | 2021 | article | cited_by 3
  Abstract: Abstract I examine whether reference points can provide an explanation for rigid wages in recessions. Even though a recession provides a good reason to adjust wages downward, workers’ perception of a “fair wage” may depend on their previous wage, their reference point. Using a laboratory experiment, I test this idea by varying whether initially concluded contracts—and their stipulated wages—can serve as reference points. My experimental results show that with initial contracts workers punish wage cuts even in recessions, leading to considerable more rigid wages. Surprisingly, this is even true without an “objective” justification to feel entitled to initial contracts.
- [cites original and replication 10.1016/j.joep.2020.102349] doi:10.1016/j.joep.2024.102744 | Replication: The money illusion effect in a Brazilian sample and meta-analyses | 2024 | article | cited_by 2
  Abstract: (none)
