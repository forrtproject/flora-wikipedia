# Evidence packet 7d53a3ae7f8f425cfab6: List of Ig Nobel Prize winners

Frozen revision: 1376076686 (2026-09-21T22:53:52Z); https://en.wikipedia.org/w/index.php?oldid=1376076686
Live check: {"frozen_revid": "1376076686", "title": "List of Ig Nobel Prize winners", "live_revid": 1376076686, "live_timestamp": "2026-09-21T22:53:52Z", "checked_at": "2026-10-06T16:46:56+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "history_list", "context_kind": "inline", "living_person_category": false, "health_term_flag": true, "co_cited": false, "large_project": false, "flora_originals_on_page": 4}

## Article lead (plain rendering, approximate)
A parody of the Nobel Prizes, the Ig Nobel Prizes are awarded each year in mid-September, around the time the recipients of the genuine Nobel Prizes are announced, for ten achievements that "first make people laugh, and then make them think". Commenting on the 2006 awards, Marc Abrahams, editor of Annals of Improbable Research and co-sponsor of the awards, said that "[t]he prizes are intended to celebrate the unusual, honor the imaginative, and spur people's interest in science, medicine, and technology". [ref: (2006) "Teen repellent is Ig Nobel winner"] All prizes are awarded for real achievements, except for three in 1991 and one in 1994, due to an erroneous press release.

## Article outline
1991
  Apocryphal achievements
1992
1993
1994
  No longer officially listed
1995
1996
1997
1998
1999
2000
2001
2002
2003
2004
2005
2006
2007
2008
2009
2010
2011
2012
2013
2014
2015
2016
2017
2018
2019
2020
2021
2022
2023
2024
2025
2026
2027
People who received multiple Ig Nobel Prizes
Ig Nobel Prize winners who also received the Nobel Prize
Notes
References
External links

## Categories
Humor-related lists; Ig Nobel laureates; Ig Nobel Prize; Lists of award winners; Science and technology award winners

## Occurrence 1: original DOI 10.1017/s1930297500006999 in section '2016'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
{| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Reproduction
| Ahmed Shafik 
| "for studying the effects of wearing polyester, cotton, or wool trousers on the sex life of rats, and for conducting similar tests with human males"
| [ref: Shafik (1993) "Effect of Different Types of Textiles on Sexual Activity" doi:10.1159/000474332] [ref: Shafik (1992) "Contraceptive efficacy of polyester-induced azoospermia in normal men" doi:10.1016/0010-7824(92)90157-O]
|-
| Economics
| Mark Avis, Sarah Forbes, and Shelagh Ferguson
| "for assessing the perceived personalities of rocks, from a sales and marketing perspective"
| [ref: Avis (2014) "The brand personality of rocks: A critical evaluation of a brand perso" doi:10.1177/1470593113512323]
|-
| Physics
| Gábor Horváth, Miklós Blahó, György Kriska, Ramón Hegedüs, Balázs Gerics, Róbert Farkas, Susanne Åkesson, Péter Malik, and Hansruedi Wildermuth
| "for discovering why white-haired horses are the most horsefly-proof horses, and for discovering why dragonflies are fatally attracted to black tombstones"
| [ref: Horváth (2010) "An unexpected advantage of whiteness in horses: the most horsefly-proo" doi:10.1098/rspb.2009.2202] [ref: Horváth (2007) "Ecological traps for dragonflies in a cemetery: the attraction of Symp" doi:10.1111/j.1365-2427.2007.01798.x]
|-
| Chemistry
| Volkswagen
| "for solving the problem of excessive automobile pollution emissions by automatically, electromechanically producing fewer emissions whenever the cars are being tested"
| [ref: (2016) "EPA, California Notify Volkswagen of Clean Air Act Violations / Carmak"]
|-
| Medicine
| Christoph Helmchen, Carina Palzer, Thomas Münte, Silke Anders, and Andreas Sprenger
| "for discovering that if you have an itch on the left side of your body, you can relieve it by looking into a mirror and scratching the right side of your body (and vice versa)."
| [ref: Helmchen (2013) "Itch Relief by Mirror Scratching. A Psychophysical Study" doi:10.1371/journal.pone.0082756]
|-
| Psychology
| Evelyne Debey, Maarten De Schryver, Gordon Logan, Kristina Suchotzki, and Bruno Verschuere
| "for asking a thousand liars how often they lie, and for deciding whether to believe those answers"
| [ref: Debey (2015) "From junior to senior Pinocchio: A cross-sectional lifespan investigat" doi:10.1016/j.actpsy.2015.06.007]
|-
| Peace
| Gordon Pennycook, James Allan Cheyne, Nathaniel Barr, Derek Koehler, and Jonathan Fugelsang
| "for their scholarly study called On the Reception and Detection of Pseudo-Profound Bullshit"
| [FOCAL REF: Pennycook (2015) "On the reception and detection of pseudo-profound bullshit" doi:10.1017/S1930297500006999]
|-
| rowspan="2" | Biology
| Charles Foster
| "for living in the wild as, at different times, a badger, an otter, a deer, a fox, and a bird"
| [ref: Foster (2016) "Being a Beast: Adventures Across the Species Divide"]
|-
| Thomas Thwaites
| "for creating prosthetic extensions of his limbs that allowed him to move in the manner of, and spend time roaming hills in the company of, goats"
| [ref: Thwaites (2016) "GoatMan: How I Took a Holiday from Being Human (one man's journey to l"]
|-
| Literature
| 
| "for his three-volume autobiographical work about the pleasures of collecting flies that are dead, and flies that are not yet dead"
| [ref: Sjöberg (2015) "The Fly Trap: A Memoir"]
|-
| Perception
| Atsuki Higashiyama and Kohei Adachi
| "for investigating whether things look different when you bend over and view them between your legs"
| [ref: Higashiyama (2006) "Perceived size and perceived distance of targets viewed from between t" doi:10.1016/j.visres.2006.04.002]
|}

### Paragraph (raw wikitext)
```
{| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Reproduction
| [[Ahmed Shafik (sexologist)|Ahmed Shafik]]{{dagger|sup=yes}} 
| "for studying the effects of wearing polyester, cotton, or wool trousers on the sex life of rats, and for conducting similar tests with human males"
| <ref>{{cite journal |last1=Shafik |first1=Ahmed |title=Effect of Different Types of Textiles on Sexual Activity |journal=European Urology |date=1993 |volume=24 |issue=3 |pages=375–380 |doi=10.1159/000474332 |pmid=8262106 }}</ref><ref>{{cite journal | last=Shafik | first=Ahmed | title=Contraceptive efficacy of polyester-induced azoospermia in normal men | journal=Contraception | volume=45 | issue=5 |year=1992 | pmid=1623716 | doi=10.1016/0010-7824(92)90157-O | pages=439–451 }}</ref>
|-
| Economics
| Mark Avis, Sarah Forbes, and Shelagh Ferguson
| "for assessing the perceived personalities of rocks, from a sales and marketing perspective"
| <ref>{{cite journal | last1=Avis | first1=Mark | last2=Forbes | first2=Sarah | last3=Ferguson | first3=Shelagh | title=The brand personality of rocks: A critical evaluation of a brand personality scale | journal=Marketing Theory | volume=14 | issue=4 |year=2014 | doi=10.1177/1470593113512323 | pages=451–475 }}</ref>
|-
| Physics
| Gábor Horváth, Miklós Blahó, György Kriska, Ramón Hegedüs, Balázs Gerics, Róbert Farkas, Susanne Åkesson, Péter Malik, and Hansruedi Wildermuth
| "for discovering why white-haired horses are the most [[horsefly]]-proof horses, and for discovering why [[dragonfly|dragonflies]] are fatally attracted to black tombstones"
| <ref name="n127">{{cite journal | last1=Horváth | first1=Gábor | last2=Blahó | first2=Miklós | last3=Kriska | first3=György | last4=Hegedüs | first4=Ramón | last5=Gerics | first5=Balázs | last6=Farkas | first6=Róbert | last7=Åkesson | first7=Susanne | title=An unexpected advantage of whiteness in horses: the most horsefly-proof horse has a depolarizing white coat | journal=Proceedings of the Royal Society B: Biological Sciences | volume=277 | issue=1688 | date=2010-06-07 | pmid=20129982 | pmc=2871857 | doi=10.1098/rspb.2009.2202 | pages=1643–1650 | bibcode=2010RSPSB.277.1643H }}</ref><ref>{{cite journal | last1=Horváth | first1=Gábor | last2=Malik | first2=Péter | last3=Kriska | first3=György | last4=Wildermuth | first4=Hansruedi | title=Ecological traps for dragonflies in a cemetery: the attraction of Sympetrum species (Odonata: Libellulidae) by horizontally polarizing black gravestones | journal=Freshwater Biology | volume=52 | issue=9 |year=2007 | doi=10.1111/j.1365-2427.2007.01798.x | pages=1700–1709 | bibcode=2007FrBio..52.1700H }}</ref>
|-
| Chemistry
| [[Volkswagen]]
| "for solving the problem of excessive automobile pollution emissions by automatically, electromechanically producing fewer emissions [[Volkswagen emissions scandal|whenever the cars are being tested]]"
| <ref>{{cite web | title=EPA, California Notify Volkswagen of Clean Air Act Violations / Carmaker allegedly used software that circumvents emissions testing for certain air pollutants | website=19january2017snapshot.epa.gov | date=2016-04-15 | url=https://19january2017snapshot.epa.gov/newsreleases/epa-california-notify-volkswagen-clean-air-act-violations-carmaker-allegedly-used_.html | access-date=2025-12-14}}</ref>
|-
| Medicine
| [[Christoph Helmchen]], Carina Palzer, Thomas Münte, Silke Anders, and Andreas Sprenger
| "for discovering that if you have an itch on the left side of your body, you can relieve it by looking into a mirror and scratching the right side of your body (and vice versa)."
| <ref>{{cite journal | last1=Helmchen | first1=Christoph | last2=Palzer | first2=Carina | last3=Münte | first3=Thomas F. | last4=Anders | first4=Silke | last5=Sprenger | first5=Andreas | title=Itch Relief by Mirror Scratching. A Psychophysical Study | journal=PLOS ONE | volume=8 | issue=12 | date=2013-12-26 | pmid=24386113 | pmc=3873464 | doi=10.1371/journal.pone.0082756 | doi-access=free | article-number=e82756 | bibcode=2013PLoSO...882756H }}</ref>
|-
| Psychology
| Evelyne Debey, Maarten De Schryver, Gordon Logan, Kristina Suchotzki, and Bruno Verschuere
| "for asking a thousand liars how often they lie, and for deciding whether to believe those answers"
| <ref>{{cite journal | last1=Debey | first1=Evelyne | last2=De Schryver | first2=Maarten | last3=Logan | first3=Gordon D. | last4=Suchotzki | first4=Kristina | last5=Verschuere | first5=Bruno | title=From junior to senior Pinocchio: A cross-sectional lifespan investigation of deception | journal=Acta Psychologica | volume=160 |year=2015 | pmid=26182909 | doi=10.1016/j.actpsy.2015.06.007 | pages=58–68 }}</ref>
|-
| Peace
| [[Gordon Pennycook]], James Allan Cheyne, Nathaniel Barr, Derek Koehler, and Jonathan Fugelsang
| "for their scholarly study called ''On the Reception and Detection of Pseudo-Profound Bullshit''"
| <ref>{{cite journal | last1=Pennycook | first1=Gordon | last2=Allan Cheyne | first2=James | last3=Barr | first3=Nathaniel | last4=Koehler | first4=Derek J. | last5=Fugelsang | first5=Jonathan A. | title=On the reception and detection of pseudo-profound bullshit | journal=Judgment and Decision Making | volume=10 | issue=6 |year=2015 | doi=10.1017/S1930297500006999 | pages=549–563 | doi-access=free }}</ref>
|-
| rowspan="2" | Biology
| [[Charles A. Foster|Charles Foster]]
| "for living in the wild as, at different times, a badger, an otter, a deer, a fox, and a bird"
| <ref>{{cite book | last=Foster | first=Charles | title=Being a Beast: Adventures Across the Species Divide | publisher=Serpent's Tail | publication-place=London | date=2016 | isbn=978-1-78125-534-6 }}{{pn|date=September 2026}}</ref>
|-
| [[Thomas Thwaites (designer)|Thomas Thwaites]]
| "for creating prosthetic extensions of his limbs that allowed him to move in the manner of, and spend time roaming hills in the company of, goats"
```

### Full section (plain rendering)
==2016==

The ceremony took place on 22 September 2016. [ref: Amos (2016) "Ig Nobel win for Alpine 'goat man'"]

{| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Reproduction
| Ahmed Shafik 
| "for studying the effects of wearing polyester, cotton, or wool trousers on the sex life of rats, and for conducting similar tests with human males"
| [ref: Shafik (1993) "Effect of Different Types of Textiles on Sexual Activity" doi:10.1159/000474332] [ref: Shafik (1992) "Contraceptive efficacy of polyester-induced azoospermia in normal men" doi:10.1016/0010-7824(92)90157-O]
|-
| Economics
| Mark Avis, Sarah Forbes, and Shelagh Ferguson
| "for assessing the perceived personalities of rocks, from a sales and marketing perspective"
| [ref: Avis (2014) "The brand personality of rocks: A critical evaluation of a brand perso" doi:10.1177/1470593113512323]
|-
| Physics
| Gábor Horváth, Miklós Blahó, György Kriska, Ramón Hegedüs, Balázs Gerics, Róbert Farkas, Susanne Åkesson, Péter Malik, and Hansruedi Wildermuth
| "for discovering why white-haired horses are the most horsefly-proof horses, and for discovering why dragonflies are fatally attracted to black tombstones"
| [ref: Horváth (2010) "An unexpected advantage of whiteness in horses: the most horsefly-proo" doi:10.1098/rspb.2009.2202] [ref: Horváth (2007) "Ecological traps for dragonflies in a cemetery: the attraction of Symp" doi:10.1111/j.1365-2427.2007.01798.x]
|-
| Chemistry
| Volkswagen
| "for solving the problem of excessive automobile pollution emissions by automatically, electromechanically producing fewer emissions whenever the cars are being tested"
| [ref: (2016) "EPA, California Notify Volkswagen of Clean Air Act Violations / Carmak"]
|-
| Medicine
| Christoph Helmchen, Carina Palzer, Thomas Münte, Silke Anders, and Andreas Sprenger
| "for discovering that if you have an itch on the left side of your body, you can relieve it by looking into a mirror and scratching the right side of your body (and vice versa)."
| [ref: Helmchen (2013) "Itch Relief by Mirror Scratching. A Psychophysical Study" doi:10.1371/journal.pone.0082756]
|-
| Psychology
| Evelyne Debey, Maarten De Schryver, Gordon Logan, Kristina Suchotzki, and Bruno Verschuere
| "for asking a thousand liars how often they lie, and for deciding whether to believe those answers"
| [ref: Debey (2015) "From junior to senior Pinocchio: A cross-sectional lifespan investigat" doi:10.1016/j.actpsy.2015.06.007]
|-
| Peace
| Gordon Pennycook, James Allan Cheyne, Nathaniel Barr, Derek Koehler, and Jonathan Fugelsang
| "for their scholarly study called On the Reception and Detection of Pseudo-Profound Bullshit"
| [FOCAL REF: Pennycook (2015) "On the reception and detection of pseudo-profound bullshit" doi:10.1017/S1930297500006999]
|-
| rowspan="2" | Biology
| Charles Foster
| "for living in the wild as, at different times, a badger, an otter, a deer, a fox, and a bird"
| [ref: Foster (2016) "Being a Beast: Adventures Across the Species Divide"]
|-
| Thomas Thwaites
| "for creating prosthetic extensions of his limbs that allowed him to move in the manner of, and spend time roaming hills in the company of, goats"
| [ref: Thwaites (2016) "GoatMan: How I Took a Holiday from Being Human (one man's journey to l"]
|-
| Literature
| 
| "for his three-volume autobiographical work about the pleasures of collecting flies that are dead, and flies that are not yet dead"
| [ref: Sjöberg (2015) "The Fly Trap: A Memoir"]
|-
| Perception
| Atsuki Higashiyama and Kohei Adachi
| "for investigating whether things look different when you bend over and view them between your legs"
| [ref: Higashiyama (2006) "Perceived size and perceived distance of targets viewed from between t" doi:10.1016/j.visres.2006.04.002]
|}

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 7d53a3ae7f8f425cfab6/article_plain.txt in the evidence directory.)

- {| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Reproduction
| Ahmed Shafik 
| "for studying the effects of wearing polyester, cotton, or wool trousers on the sex life of rats, and for conducting similar tests with human males"
| [ref: Shafik (1993) "Effect of Different Types of Textiles on Sexual Activity" doi:10.1159/000474332] [ref: Shafik (1992) "Contraceptive efficacy of polyester-induced azoospermia in normal men" doi:10.1016/0010-7824(92)90157-O]
|-
| Economics
| Mark Avis, Sarah Forbes, and Shelagh Ferguson
| "for assessing the perceived personalities of rocks, from a sales and marketing perspective"
| [ref: Avis (2014) "The brand personality of rocks: A critical evaluation of a brand perso" doi:10.1177/1470593113512323]
|-
| Physics
| Gábor Horváth, Miklós Blahó, György Kriska, Ramón Hegedüs, Balázs Gerics, Róbert Farkas, Susanne Åkesson, Péter Malik, and Hansruedi Wildermuth
| "for discovering why white-haired horses are the most horsefly-proof horses, and for discovering why dragonflies are fatally attracted to black tombstones"
| [ref: Horváth (2010) "An unexpected advantage of whiteness in horses: the most horsefly-proo" doi:10.1098/rspb.2009.2202] [ref: Horváth (2007) "Ecological traps for dragonflies in a cemetery: the attraction of Symp" doi:10.1111/j.1365-2427.2007.01798.x]
|-
| Chemistry
| Volkswagen
| "for solving the problem of excessive 
- {| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Medicine
| Marc Mitchell and David Wartinger
| "for using roller coaster rides to try to hasten the passage of kidney stones"
| [ref: Mitchell (2016) "Validation of a Functional Pyelocalyceal Renal Model for the Evaluatio" doi:10.7556/jaoa.2016.128]
|-
| Anthropology
| Tomas Persson, Gabriela-Alina Sauciuc, and Elainie Madsen
| "for collecting evidence, in a zoo, that chimpanzees imitate humans about as often, and about as well, as humans imitate chimpanzees"
| [ref: Persson (2018) "Spontaneous cross-species imitation in interactions between chimpanzee" doi:10.1007/s10329-017-0624-9]
|-
| Biology
| Paul Becher, Sebastien Lebreton, Erika Wallin, Erik Hedenstrom, Felipe Borrero-Echeverry, Marie Bengtsson, Volker Jorger, and Peter Witzgall
| "for demonstrating that wine experts can reliably identify, by smell, the presence of a single fly in a glass of wine"
| [ref: Becher (2018) "The Scent of the Fly" doi:10.1007/s10886-018-0950-4] 
|-
| Chemistry
| Paula Romão, Adília Alarcão and the late César Viana
| "for measuring the degree to which human saliva is a good cleaning agent for dirty surfaces"
| [ref: Romão (1990) "Human saliva as a cleaning agent for dirty surfaces" doi:10.1179/sic.1990.35.3.153]
|-
| Medical Education
| Akira Horiuchi
| "for the medical report Colonoscopy in the Sitting Position: Lessons Learn
- {| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Acoustics
| Stephan Reber, Takeshi Nishimura, Judith Janisch, Mark Robertson, and Tecumseh Fitch,
| "for inducing a female Chinese alligator to bellow in an airtight chamber filled with helium-enriched air"
| [ref: Reber (2015) "A Chinese alligator in heliox: formant frequencies in a crocodilian" doi:10.1242/jeb.119552]
|-
| Economics
| Christopher Watkins, Juan David Leongómez, Jeanne Bovet, Agnieszka Żelaźniewicz, Max Korbmacher, Marco Antônio Corrêa Varella, Ana Maria Fernandez, Danielle Wagstaff, and Samuela Bolgan
| "for trying to quantify the relationship between different countries' national income inequality and the average amount of mouth-to-mouth kissing"
| [ref: Watkins (2019) "National income inequality predicts cultural variation in mouth to mou" doi:10.1038/s41598-019-43267-7]
|-
| Entomology
| Richard Vetter
| "for collecting evidence that many entomologists (scientists who study insects) are afraid of spiders, which are not insects"
| [ref: Vetter (2013) "Arachnophobic Entomologists: When Two More Legs Makes a Big Difference" doi:10.1093/ae/59.3.168]
|-
| Management
| Xi Guang-An, Mo Tian-Xiang, Yang Kang-Sheng, Yang Guang-Sheng, and Ling Xian Si
| "five professional hitmen in Guangxi, China, who managed a contract for a hit job (a murder performed for money) in the following way: After acceptin

## ORIGINAL STUDY: doi:10.1017/s1930297500006999 (FLoRA title: On the reception and detection of pseudo-profound bullshit)
Crossref: On the reception and detection of pseudo-profound bullshit | Gordon Pennycook, James Allan Cheyne, Nathaniel Barr, Derek J. Koehler, Jonathan A. Fugelsang | Judgment and Decision Making | 2015 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2282631200", "type": "article", "publication_year": 2015, "cited_by_count": 558, "is_retracted": false, "oa_status": "gold", "oa_pdf": "https://www.cambridge.org/core/services/aop-cambridge-core/content/view/0D3C87BCC238BCA38BC55E395BDC9999/S1930297500006999a.pdf/div-class-title-on-the-reception-and-detection-of-pseudo-profound-bullshit-div.pdf", "oa_landing": "https://doi.org/10.1017/s1930297500006999"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext/10_1017_s1930297500006999.txt (open-access PDF via OpenAlex best_oa_location (https://www.cambridge.org/core/services/aop-cambridge-core/content/view/0D3C87BCC238BCA38BC55E395BDC9999/S1930297500006999a.pdf/div-class-title-on-the-reception-and-detection-of-pseudo-profound-bullshit-div.pdf))
Retrieved: 2026-10-09T12:18:49+00:00
### Abstract (Crossref deposited abstract)
Although bullshit is common in everyday life and has attracted attention from philosophers, its reception (critical or ingenuous) has not, to our knowledge, been subject to empirical investigation. Here we focus on pseudo-profound bullshit, which consists of seemingly impressive assertions that are presented as true and meaningful but are actually vacuous. We presented participants with bullshit statements consisting of buzzwords randomly organized into statements with syntactic structure but no discernible meaning (e.g., “Wholeness quiets infinite phenomena”). Across multiple studies, the propensity to judge bullshit statements as profound was associated with a variety of conceptually relevant variables (e.g., intuitive cognitive style, supernatural belief). Parallel associations were less evident among profundity judgments for more conventionally profound (e.g., “A wet person does not fear the rain”) or mundane (e.g., “Newborn babies require constant attention”) statements. These results support the idea that some people are more receptive to this type of bullshit and that detecting it is not merely a matter of indiscriminate skepticism but rather a discernment of deceptive vagueness in otherwise impressive sounding claims. Our results also suggest that a bias toward accepting statements as true may be an important component of pseudo-profound bullshit receptivity.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1002/per.2176 (FLoRA title: Openness/Intellect and Susceptibility to Pseudo–Profound Bullshit: A Replication and Extension; FLoRA outcome code: mixed [screening input only, not citable]; DOI detected on page: False)
Crossref: Openness/Intellect and Susceptibility to Pseudo–Profound Bullshit: A Replication and Extension | Timothy F. Bainbridge, Joshua A. Quinlan, Raymond A. Mar, Luke D. Smillie | European Journal of Personality | 2019 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2898012511", "type": "article", "publication_year": 2018, "cited_by_count": 45, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1002_per_2176.txt (Free copy found by source search (published): https://www.yorku.ca/mar/Bainbridge_et_al-2019-European_Journal_of_Personality.pdf)
Retrieved: 2026-10-09T12:18:54+00:00
### Abstract (Crossref deposited abstract)
‘Pseudo–profound bullshit’ (PPBS) is a class of meaningless statements designed to appear profound. Profundity ratings for PPBS have been found to be negatively related to analytical thinking and positively related to epistemically suspect beliefs (e.g. belief in the paranormal). Conceptually similar traits within the Openness/Intellect (O/I) domain form a simplex, whereby traits are arranged along a single dimension from intelligence to apophenia (i.e. observing patterns or causal connections were none exist). Across two studies (total N = 297), we attempted to replicate the O/I simplex and determine how it relates to perceiving PPBS as profound. Participants completed questionnaires measuring traits from the O/I simplex and provided profundity ratings for PPBS. Profundity ratings of PPBS tended to correlate negatively with intelligence and positively with apophenia. The association with intelligence generally reflected a greater ability to discriminate the profound from the pseudo–profound, whereas the association with apophenia reflected poorer discrimination in Study 1, with less conclusive results in Study 2. In both studies, the O/I simplex was closely replicated. The results suggest a link between the O/I domain and perceiving PPBS as profound and tentatively support the theory that intelligence may protect against apophenia. © 2018 European Association of Personality Psychology

## Other database studies cited on this same page (each has its own packet; drafted together)
- 7b3d33cc48f39207c3b6: Bottomless Bowls: Why Visual Cues of Portion Size May Influence Intake** (doi:10.1038/oby.2005.12)
- 2fd9886968cf6c26751b: Higher social class predicts increased unethical behavior (doi:10.1073/pnas.1118373109)
- f84ff1fe303855ec730c: Inhibiting and facilitating conditions of the human smile: A nonobtrusive test of the facial feedback hypothesis. (doi:10.1037/0022-3514.54.5.768)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1089/cyber.2020.0149 | Deepfakes Unmasked: The Effects of Information Priming and Bullshit Receptivity on Deepfake Recognition and Sharing Intention | 2021 | read: abstract | mentions replication: False
- doi:10.1177/2631787720929704 | Playing the Bullshit Game: How Empty and Misleading Communication Takes Over Organizations | 2020 | read: abstract | mentions replication: False
- doi:10.1007/s12144-020-00617-3 | Expanding the bullshit research out of pseudo-transcendental domain | 2020 | read: metadata_only | mentions replication: False
- doi:10.1111/bjso.12559 | It is double pleasure to deceive the deceiver: Machiavellianism is associated with producing but not necessarily with falling for bullshit | 2022 | read: abstract | mentions replication: False
- doi:10.1177/14747049211000317 | Bullshit Ability as an Honest Signal of Intelligence | 2021 | read: abstract | mentions replication: False

## Other papers relevant to this page that the pipeline looked up
- doi:10.3389/fpsyg.2017.00702 | From Data to Truth in Psychological Science. A Personal Perspective. | paper cited in the article (not a database study) | read: abstract
  Abstract (Semantic Scholar): Over 30 years ago, Leonard Martin, Sabine Stepper, and I (Strack et al., 1988) conducted two studies to test the “facial feedback” hypothesis (Darwin, 1872). At the time, the hypothesis itself, namely that facial expressionsmay affect emotional experiences, was well established and frequently tested (e.g., Leventhal andMace, 1970; Laird, 1974). However, the underlying mechanism remained largely unexplored. On the one hand, the feedback could have been mediated by an inference from the emotional meaning of the expression to the underlying emotional state. On the other hand it could have been a more direct mechanism that does not involve any inferences. To resolve this ambiguity, we attempted to eliminate the inferential route by preventing participants from interpreting their facial action as “a smile.” This was accomplished by having participants holding a pen either between their protruded lips, which prevents smiling, or between their teeth, which facilitates it. Holding the pen in either of these positions, participants had to perform a series of tasks, among them a rating of the funniness of cartoons. As predicted, the cartoons were rated to be funnier if the pen was held between the teeth than between the lips. The effect was not strong but met the standard criteria of significance. The resulting “pen study” was meant neither to demonstrate a cute phenomenon nor to identify a powerful intervention to improve people’s feelings. Instead, it was intended to be one piece in the theoretical puzzle. This was underscored in the last sentence of the original article: “Obviously, more research is needed to understand the exact mechanisms that are responsible for facial feedback. In this endeavor, an alternative methodology that eliminates possible confounds may be helpful (p. 776).” Since 1988, more research on facial feedback has been conducted (Laird and Lacasse, 2014) and even a new methodology was introduced that was robust enough to even afford therapeutic interventions, namely the suppression (injecting Botox) of the corrugator muscle, which contracts the eyebrows and is implied in negative emotions (Finzi and Rosenthal, 2016). In 2013, I volunteered to be part of a Registered Replication Report project and submitted the experimental materials. In September 2016, the results came out (Wagenmakers et al., 2016). Seventeen replication groups had tested 1,894 participants. For nine groups, the result was in the predicted direction, for eight groups in the opposite direction. Overall, there was no significant effect.

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1016/j.tics.2021.02.007 | The Psychology of Fake News | 2021 | review | cited_by 1275
  Abstract: We synthesize a burgeoning literature investigating why people believe and share false or highly misleading news online. Contrary to a common narrative whereby politics drives susceptibility to fake news, people are 'better' at discerning truth from falsehood (despite greater overall belief) when evaluating politically concordant news. Instead, poor truth discernment is associated with lack of careful reasoning and relevant knowledge, and the use of heuristics such as familiarity. Furthermore, there is a substantial disconnect between what people believe and what they share on social media. This dissociation is largely driven by inattention, more so than by purposeful sharing of misinformation. Thus, interventions can successfully nudge social media users to focus more on accuracy. Crowdsourced veracity ratings can also be leveraged to improve social media ranking algorithms.
- [review citing original] doi:10.1371/journal.pone.0153039 | Atheists and Agnostics Are More Reflective than Religious Believers: Four Empirical Studies and a Meta-Analysis | 2016 | review | cited_by 241
  Abstract: Individual differences in the mere willingness to think analytically has been shown to predict religious disbelief. Recently, however, it has been argued that analytic thinkers are not actually less religious; rather, the putative association may be a result of religiosity typically being measured after analytic thinking (an order effect). In light of this possibility, we report four studies in which a negative correlation between religious belief and performance on analytic thinking measures is found when religious belief is measured in a separate session. We also performed a meta-analysis on all previously published studies on the topic along with our four new studies (N = 15,078, k = 31), focusing specifically on the association between performance on the Cognitive Reflection Test (the most widely used individual difference measure of analytic thinking) and religious belief. This meta-analysis revealed an overall negative correlation (r) of -.18, 95% CI [-.21, -.16]. Although this correlation is modest, self-identified atheists (N = 133) scored 18.7% higher than religiously affiliated individuals (N = 597) on a composite measure of analytic thinking administered across our four 
- [review citing original] doi:10.1016/j.intell.2021.101614 | Cognitive reflection, cognitive intelligence, and cognitive abilities: A meta-analysis | 2021 | review | cited_by 105
  Abstract: This paper presents a series of psychometric meta-analysis on the relationship between cognitive reflection (CR) and several cognitive abilities (i.e., cognitive intelligence, numerical ability, verbal ability, mechanical-spatial ability, and working memory), and skills (i.e., numeracy skills). Also, the paper presents a bifactor analysis carried out to determine whether CR is a related but independent factor or a second-stratum factor in a hierarchical model of cognitive intelligence. Finally, the study also tested a path meta-analytic model of the CR-cognitive ability relationships. The results showed that CR correlated substantially with all the cognitive abilities and skills (K ranged from 3 to 44 and N ranged from 624 to 20,307). The bifactor analysis showed that CR variance was mainly accounted for by a general factor of cognitive intelligence plus a second-stratum factor of numerical ability. The results of the bifactor analysis were similar for numerical-CRT and verbal-CRT. It was not found evidence supporting the existence of a cognitive reflection factor. Finally, the path meta-analytic model showed that the combination of cognitive intelligence and numerical ability acco
- [review citing original] doi:10.1017/s1930297500008913 | Reflective thinking predicts lower conspiracy beliefs: A meta-analysis | 2022 | review | cited_by 70
  Abstract: Abstract One of the many established predictors of conspiracy beliefs is reflective thinking, but no meta-analysis so far has examined this relationship. In the current meta-analysis of published and unpublished correlational data (145 samples, 181 effect sizes), we found a significant negative association between reflective thinking and conspiracy beliefs with a medium-level effect size (r = –.189) . Similar levels of correlations were found across different types of measures (self-report vs. performance-based) and conspiracy beliefs (generic vs. specific). Further, no evidence suggested publication bias in this body of work. Suggestions for future research are discussed.
- [review citing original] doi:10.1016/j.copsyc.2022.101387 | Intuition, reason, and conspiracy beliefs | 2022 | review | cited_by 60
  Abstract: (none)
- [cites original and replication 10.1002/per.2176] doi:10.1089/cyber.2020.0149 | Deepfakes Unmasked: The Effects of Information Priming and Bullshit Receptivity on Deepfake Recognition and Sharing Intention | 2021 | article | cited_by 60
  Abstract: The study aims to test whether simple priming of deepfake (DF) information significantly increases users' ability to recognize DF media. Although undoubtedly fascinating from a technological point of view, these highly realistic artificial intelligent (AI)-generated fake videos hold high deceptive potential. Both practitioners and institutions are thus joining forces to develop debunking strategies to counter the spread of such difficult-to-recognize and potentially misleading video content. On this premise, this study addresses the following research questions: does simple priming with the definition of DFs and information about their potentially harmful applications increase users' ability to recognize DFs? Does bullshit receptivity, as an individual tendency to be overly accepting of epistemically suspect beliefs, moderate the relationship between such priming and DF recognition? Results indicate that the development of strategies to counter the deceitfulness of DFs from an educational and cultural perspective might work well, but only for people with a lower susceptibility to believe willfully misleading claims. Finally, through a serial mediation analysis, we show that DF reco
- [cites original and replication 10.1002/per.2176] doi:10.1177/2631787720929704 | Playing the Bullshit Game: How Empty and Misleading Communication Takes Over Organizations | 2020 | article | cited_by 60
  Abstract: Why is bullshit so common in some organizations? Existing explanations focus on the characteristics of bullshitters, the nature of the audience, and social structural factors which encourage bullshitting. In this paper, I offer an alternative explanation: bullshitting is a social practice that organizational members engage with to become part of a speech community, to get things done in that community, and to reinforce their identity. When the practice of bullshitting works, it can gradually expand from a small group to take over an entire organization and industry. When bullshitting backfires, previously sacred concepts can become seen as empty and misleading talk.
- [cites original and replication 10.1002/per.2176] doi:10.1007/s12144-020-00617-3 | Expanding the bullshit research out of pseudo-transcendental domain | 2020 | article | cited_by 31
  Abstract: (none)
- [cites original and replication 10.1002/per.2176] doi:10.1111/bjso.12559 | It is double pleasure to deceive the deceiver: Machiavellianism is associated with producing but not necessarily with falling for bullshit | 2022 | article | cited_by 24
  Abstract: Machiavellianism is a personality trait emphasizing fraud at others' expense. It is yet unclear whether Machiavellianism is also predictive of less obvious deception, for example inaccurate or meaningless information supposed to gain advantages and to avoid disadvantages (i.e., bullshit). Similarly, it is unclear whether those high in Machiavellianism can recognize bullshit claims and valuable information as such (i.e., bullshit sensitivity). In this study, we investigated whether different facets of Machiavellianism are prone to the production of different sorts of bullshit and how these facets of Machiavellianism relate to bullshit sensitivity. In a sample of 525 participants (72% women), we found that the manipulative side of Machiavellianism (Machiavellian approach) was linked to persuasive bullshitting, that is, the production of bullshit intended to gain desired resources. Likewise, the distrustful side of Machiavellianism (Machiavellian avoidance) went along with higher evasive bullshitting, which means spreading information that ought to prevent individual disadvantages. Next, we found that those high in Machiavellian avoidance, but not Machiavellian approach, were better a
- [cites original and replication 10.1002/per.2176] doi:10.1177/14747049211000317 | Bullshit Ability as an Honest Signal of Intelligence | 2021 | article | cited_by 23
  Abstract: Navigating social systems efficiently is critical to our species. Humans appear endowed with a cognitive system that has formed to meet the unique challenges that emerge for highly social species. Bullshitting, communication characterised by an intent to be convincing or impressive without concern for truth, is ubiquitous within human societies. Across two studies ( N = 1,017), we assess participants’ ability to produce satisfying and seemingly accurate bullshit as an honest signal of their intelligence. We find that bullshit ability is associated with an individual’s intelligence and individuals capable of producing more satisfying bullshit are judged by second-hand observers to be more intelligent. We interpret these results as adding evidence for intelligence being geared towards the navigation of social systems. The ability to produce satisfying bullshit may serve to assist individuals in negotiating their social world, both as an energetically efficient strategy for impressing others and as an honest signal of intelligence.
