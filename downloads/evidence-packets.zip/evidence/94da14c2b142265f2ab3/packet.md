# Evidence packet 94da14c2b142265f2ab3: List of cognitive biases

Frozen revision: 1376537524 (2026-09-24T19:42:49Z); https://en.wikipedia.org/w/index.php?oldid=1376537524
Live check: {"frozen_revid": "1376537524", "title": "List of cognitive biases", "live_revid": 1376537524, "live_timestamp": "2026-09-24T19:42:49Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "history_list", "context_kind": "inline", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 7}

## Article lead (plain rendering, approximate)
In psychology and cognitive science, cognitive biases are systematic patterns of deviation from norm and/or rationality in judgment. [ref: (2005) "The Handbook of Evolutionary Psychology"] [ref: (2022) "Cognitive Bias. Philogenesis or Ontogenesis" doi:10.3389/fpsyg.2022.892829] They are often studied in psychology, sociology and behavioral economics. [ref: (2005) "The Handbook of Evolutionary Psychology"]

A memory bias is a cognitive bias that either enhances or impairs the recall of a memory (either the chances that the memory will be recalled at all, or the amount of time it takes for it to be recalled, or both), or that alters the content of a reported memory.

Explanations include information-processing rules (i.e., mental shortcuts), called heuristics, that the brain uses to produce decisions or judgments. Biases have a variety of forms and appear as cognitive ("cold") bias, such as mental noise, [ref: (2012) "Toward a synthesis of cognitive biases: how noisy information processi" doi:10.1037/a0025940] or motivational ("hot") bias, such as when beliefs are distorted by wishful thinking. Both effects can be present at the same time. [ref: MacCoun RJ (1998) "Biases in the interpretation and use of research results" doi:10.1146/annurev.psych.49.1.259] [ref: (1998) "Confirmation Bias: A Ubiquitous Phenomenon in Many Guises" doi:10.1037/1089-2680.2.2.175]

There are also controversies over some of these biases as to whether they count as useless or irrational, or whether they result in useful attitudes or behavior. For example, when getting to know others, people tend to ask leading questions which seem biased towards confirming their assumptions about the person. However, this kind of confirmation bias has also been argued to be an example of social skill; a way to establish a connection with the other person. [ref: (1995) "Confirmation Bias as a Social Skill" doi:10.1177/01461672952111011]

Although this research overwhelmingly involves human subjects, some studies have found bias in non-human animals as well. For example, loss aversion has been shown in monkeys and hyperbolic discounting has been observed in rats, pigeons, and monkeys. [ref: (2010) "Hyperbolically discounted temporal difference learning" doi:10.1162/neco.2010.08-09-1080]

## Article outline
Organization of cognitive biases
Estimation
  Association
  Baseline
  Inertia
  Outcome
  Self-perspective
Decision
  Association
  Baseline
  Inertia
  Outcome
  Self-perspective
Hypothesis assessment
  Association
  Outcome
Causal attribution
  Outcome
  Self-perspective
Recall
  Association
  Baseline
  Inertia
  Outcome
  Self-perspective
Opinion reporting
  Association
  Inertia
  Outcome
  Self-perspective
See also
Footnotes
References
Further reading
External links

## Categories
Cognitive biases; Psychology lists; Behavioral finance; Cognitive science lists

## Occurrence 1: original DOI 10.1038/s41586-021-03380-y in section 'Baseline'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
===Baseline===
* Action bias: The tendency for someone to act when faced with a problem even when inaction would be more effective, or to act when no evident problem exists. [ref: (2021) "Why do we prefer doing something to doing nothing"] [ref: (2000) "Action Bias and Environmental Decisions" doi:10.1023/A:1026517309871]
* Additive bias: The tendency to solve problems through addition, even when subtraction is a better approach. [ref: (2021) "People add by default even when subtraction makes more sense"] [FOCAL REF: (2021) "People systematically overlook subtractive changes" doi:10.1038/s41586-021-03380-y]
* Decoy effect, where preferences for either option A or B change in favor of option B when option C is presented, which is completely dominated by option B (inferior in all respects) and partially dominated by option A. [ref: "Evolution and cognitive biases: the decoy effect"]
* Ballot order effect, where candidates who are listed first often receive a small but statistically significant increase in votes compared to those listed in lower positions. [ref: Miller, J. M., & Krosnick, J. A. (1998). The impact of candidate name order on election ou]
* Cheerleader effect, the tendency for people to appear more attractive in a group than in isolation. [ref: (2014) "Hierarchical encoding makes individuals in a group seem more attractiv" doi:10.1177/0956797613497969]
* Compromise effect, choices affected if presented as extreme or average [ref: Dimara (2020) "A Task-Based Taxonomy of Cognitive Biases for Information Visualizatio" doi:10.1109/TVCG.2018.2872577]
* Denomination effect, the tendency to spend more money when it is denominated in small amounts (e.g., coins) rather than large amounts (e.g., bills). [ref: https://www.npr.org/templates/story/story.php?storyId=104063298 Why We Spend Coins Faster ]
* Disposition effect, the tendency to sell an asset that has accumulated in value and resist selling an asset that has declined in value. [ref: Shefrin, H., & Statman, M. (1985). The disposition to sell winners too early and ride lose]
* Distinction bias, the tendency to view two options as more dissimilar when evaluating them simultaneously than when evaluating them separately. [ref: (2004) "Distinction bias: misprediction and mischoice due to joint evaluation" doi:10.1037/0022-3514.86.5.680]
* Less-is-better effect, the tendency to prefer a smaller set to a larger set judged separately, but not jointly.
* Money illusion: The tendency to concentrate on the nominal value (face value) of money rather than its value in terms of purchasing power. [ref: (2000) "Choices, values, and frames"]
* Phantom effect: choices affected by dominant but unavailable options. [ref: Dimara (2020) "A Task-Based Taxonomy of Cognitive Biases for Information Visualizatio" doi:10.1109/TVCG.2018.2872577]
* Normalcy bias, a form of cognitive dissonance, is the refusal to plan for, or react to, a disaster which has never happened before. [ref: Omer, H., & Alon, N. (1994). The continuity principle: A unified approach to disaster and ]
* Projection bias: The tendency to overestimate how much one's future selves will share one's current preferences, thoughts and values, thus leading to sub-optimal choices. [ref: (2006) "Decision and experience: why don't we choose what makes us happy?" doi:10.1016/j.tics.2005.11.007]
* Scope neglect or scope insensitivity, the tendency to be insensitive to the size of a problem when evaluating it. For example, being willing to pay as much to save 2,000 children or 20,000 children. [ref: Kahneman, D., & Knetsch, J. L. (1992). Valuing public goods: The purchase of moral satisfa]

### Paragraph (raw wikitext)
```
===Baseline===
* [[Action bias]]: The tendency for someone to act when faced with a problem even when inaction would be more effective, or to act when no evident problem exists.<ref>{{cite news |title=Why do we prefer doing something to doing nothing |url=https://thedecisionlab.com/biases/action-bias/ |access-date=30 November 2021 |work=The Decision Lab |date=30 September 2021}}</ref><ref>{{cite journal | vauthors = Patt A, Zeckhauser R |date=July 2000 |title=Action Bias and Environmental Decisions |journal=Journal of Risk and Uncertainty |language=en |volume=21 |pages=45–72 |doi=10.1023/A:1026517309871 |s2cid=154662174}}</ref>
* [[Additive bias]]: The tendency to solve problems through addition, even when subtraction is a better approach.<ref>{{cite news | vauthors = Gupta S |date=7 April 2021 |title=People add by default even when subtraction makes more sense |work=Science News |url=https://www.sciencenews.org/article/psychology-numbers-people-add-default-subtract-better |access-date=10 May 2021}}</ref><ref>{{cite journal | vauthors = Adams GS, Converse BA, Hales AH, Klotz LE | title = People systematically overlook subtractive changes | journal = Nature | volume = 592 | issue = 7853 | pages = 258–261 | date = April 2021 | pmid = 33828317 | doi = 10.1038/s41586-021-03380-y | s2cid = 233185662 | bibcode = 2021Natur.592..258A }}</ref>
* [[Decoy effect]], where preferences for either option A or B change in favor of option B when option C is presented, which is completely dominated by option B (inferior in all respects) and partially dominated by option A.<ref>{{Cite web|url=https://www.futurelearn.com/courses/complexity-and-uncertainty/0/steps/1882|title=Evolution and cognitive biases: the decoy effect |website=FutureLearn|language=en-GB|access-date=2018-10-10}}</ref>
* [[Ballot order effect]], where candidates who are listed first often receive a small but statistically significant increase in votes compared to those listed in lower positions.<ref>Miller, J. M., & Krosnick, J. A. (1998). The impact of candidate name order on election outcomes. ''Public Opinion Quarterly, 62''(3), 291–330. https://doi.org/10.1086/297848</ref>
* [[Cheerleader effect]], the tendency for people to appear more attractive in a group than in isolation.<ref>{{cite journal | vauthors = Walker D, Vul E | title = Hierarchical encoding makes individuals in a group seem more attractive | journal = Psychological Science | volume = 25 | issue = 1 | pages = 230–235 | date = January 2014 | pmid = 24163333 | doi = 10.1177/0956797613497969 | s2cid = 16309135 }}</ref>
* Compromise effect, choices affected if presented as extreme or average<ref name="Dimara2020"/>
* [[Denomination effect]], the tendency to spend more money when it is denominated in small amounts (e.g., coins) rather than large amounts (e.g., bills).<ref>[https://www.npr.org/templates/story/story.php?storyId=104063298 Why We Spend Coins Faster Than Bills] by Chana Joffe-Walt. ''All Things Considered'', 12 May 2009.</ref>
* [[Disposition effect]], the tendency to sell an asset that has accumulated in value and resist selling an asset that has declined in value.<ref>Shefrin, H., & Statman, M. (1985). The disposition to sell winners too early and ride losers too long: Theory and evidence. ''Journal of Finance, 40''(3), 777–790. https://doi.org/10.1111/j.1540-6261.1985.tb05002.x</ref>
* [[Distinction bias]], the tendency to view two options as more dissimilar when evaluating them simultaneously than when evaluating them separately.<ref>{{cite journal | vauthors = Hsee CK, Zhang J | title = Distinction bias: misprediction and mischoice due to joint evaluation | journal = Journal of Personality and Social Psychology | volume = 86 | issue = 5 | pages = 680–695 | date = May 2004 | pmid = 15161394 | doi = 10.1037/0022-3514.86.5.680 }}</ref>
* [[Less-is-better effect]], the tendency to prefer a smaller set to a larger set judged separately, but not jointly.
* [[Money illusion]]: The tendency to concentrate on the nominal value (face value) of money rather than its value in terms of purchasing power.<ref>{{cite book | vauthors = Shafir E, Diamond P, Tversky A | veditors = Kahneman D, Tversky A |date=2000 |title=Choices, values, and frames |chapter=Money Illusion |publisher=Cambridge University Press |isbn=978-0-521-62749-8 |pages=335–355}}</ref>
* Phantom effect: choices affected by dominant but unavailable options.<ref name="Dimara2020"/>
* [[Normalcy bias]], a form of cognitive dissonance, is the refusal to plan for, or react to, a disaster which has never happened before.<ref>Omer, H., & Alon, N. (1994). The continuity principle: A unified approach to disaster and trauma. ''American Journal of Community Psychology, 22''(2), 273–287. https://doi.org/10.1007/BF02506823</ref>
* [[Projection bias]]: The tendency to overestimate how much one's future selves will share one's current preferences, thoughts and values, thus leading to sub-optimal choices.<ref>{{cite journal | vauthors = Hsee CK, Hastie R | title = Decision and experience: why don't we choose what makes us happy? | journal = Trends in Cognitive Sciences | volume = 10 | issue = 1 | pages = 31–37 | date = January 2006 | pmid = 16318925 | doi = 10.1016/j.tics.2005.11.007 | url = http://maelko.typepad.com/DecisionAndExperience.pdf | url-status = live | s2cid = 12262319 | archive-url = https://web.archive.org/web/20150420205315/http://maelko.typepad.com/DecisionAndExperience.pdf | archive-date = 2015-04-20 }}</ref>
* [[Scope neglect]] or scope insensitivity, the tendency to be insensitive to the size of a problem when evaluating it. For example, being willing to pay as much to save 2,000 children or 20,000 children.<ref>Kahneman, D., & Knetsch, J. L. (1992). Valuing public goods: The purchase of moral satisfaction. ''Journal of Environmental Economics and Management, 22''(1), 57–70. https://doi.org/10.1016/0095-0696(92)90019-S</ref>
```

### Full section (plain rendering)
===Baseline===
* Action bias: The tendency for someone to act when faced with a problem even when inaction would be more effective, or to act when no evident problem exists. [ref: (2021) "Why do we prefer doing something to doing nothing"] [ref: (2000) "Action Bias and Environmental Decisions" doi:10.1023/A:1026517309871]
* Additive bias: The tendency to solve problems through addition, even when subtraction is a better approach. [ref: (2021) "People add by default even when subtraction makes more sense"] [FOCAL REF: (2021) "People systematically overlook subtractive changes" doi:10.1038/s41586-021-03380-y]
* Decoy effect, where preferences for either option A or B change in favor of option B when option C is presented, which is completely dominated by option B (inferior in all respects) and partially dominated by option A. [ref: "Evolution and cognitive biases: the decoy effect"]
* Ballot order effect, where candidates who are listed first often receive a small but statistically significant increase in votes compared to those listed in lower positions. [ref: Miller, J. M., & Krosnick, J. A. (1998). The impact of candidate name order on election ou]
* Cheerleader effect, the tendency for people to appear more attractive in a group than in isolation. [ref: (2014) "Hierarchical encoding makes individuals in a group seem more attractiv" doi:10.1177/0956797613497969]
* Compromise effect, choices affected if presented as extreme or average [ref: Dimara (2020) "A Task-Based Taxonomy of Cognitive Biases for Information Visualizatio" doi:10.1109/TVCG.2018.2872577]
* Denomination effect, the tendency to spend more money when it is denominated in small amounts (e.g., coins) rather than large amounts (e.g., bills). [ref: https://www.npr.org/templates/story/story.php?storyId=104063298 Why We Spend Coins Faster ]
* Disposition effect, the tendency to sell an asset that has accumulated in value and resist selling an asset that has declined in value. [ref: Shefrin, H., & Statman, M. (1985). The disposition to sell winners too early and ride lose]
* Distinction bias, the tendency to view two options as more dissimilar when evaluating them simultaneously than when evaluating them separately. [ref: (2004) "Distinction bias: misprediction and mischoice due to joint evaluation" doi:10.1037/0022-3514.86.5.680]
* Less-is-better effect, the tendency to prefer a smaller set to a larger set judged separately, but not jointly.
* Money illusion: The tendency to concentrate on the nominal value (face value) of money rather than its value in terms of purchasing power. [ref: (2000) "Choices, values, and frames"]
* Phantom effect: choices affected by dominant but unavailable options. [ref: Dimara (2020) "A Task-Based Taxonomy of Cognitive Biases for Information Visualizatio" doi:10.1109/TVCG.2018.2872577]
* Normalcy bias, a form of cognitive dissonance, is the refusal to plan for, or react to, a disaster which has never happened before. [ref: Omer, H., & Alon, N. (1994). The continuity principle: A unified approach to disaster and ]
* Projection bias: The tendency to overestimate how much one's future selves will share one's current preferences, thoughts and values, thus leading to sub-optimal choices. [ref: (2006) "Decision and experience: why don't we choose what makes us happy?" doi:10.1016/j.tics.2005.11.007]
* Scope neglect or scope insensitivity, the tendency to be insensitive to the size of a problem when evaluating it. For example, being willing to pay as much to save 2,000 children or 20,000 children. [ref: Kahneman, D., & Knetsch, J. L. (1992). Valuing public goods: The purchase of moral satisfa]

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 94da14c2b142265f2ab3/article_plain.txt in the evidence directory.)

- There are also controversies over some of these biases as to whether they count as useless or irrational, or whether they result in useful attitudes or behavior. For example, when getting to know others, people tend to ask leading questions which seem biased towards confirming their assumptions about the person. However, this kind of confirmation bias has also been argued to be an example of social skill; a way to establish a connection with the other person. [ref: (1995) "Confirmation Bias as a Social Skill" doi:10.1177/01461672952111011]
- == Organization of cognitive biases ==
Although the reality of these biases is confirmed by reproducible research, [ref: "Cognitive Bias – Association for Psychological Science"] [ref: (2018) "Two decades of cognitive bias research in entrepreneurship: What do we" doi:10.1007/s11301-018-0135-9] there are often controversies about how to classify these biases or how to explain them. [ref: (1999) "MINERVA-DM: A memory processes model for judgments of likelihood" doi:10.1037/0033-295x.106.1.180] Several theoretical causes are known for some cognitive biases, which provides a classification of biases by their common generative mechanism (such as noisy information-processing [ref: (2012) "Toward a synthesis of cognitive biases: how noisy information processi" doi:10.1037/a0025940]). Gerd Gigerenzer has criticized the framing of cognitive biases as errors in judgment, and favors interpreting them as arising from rational deviations from logical thought. [ref: Gigerenzer G (2006) "Contemporary Debates in Cognitive Science"] This list is organized based on the task-based classification proposed by . This classification defines 6 tasks, namely estimation, decision, hypothesis assessment, causal attribution, recall, and opinion reporting. The biases are further loosely classified into 5 sub-categories or "flavors": [ref: Dimara (2020) "A Task-Based Taxonomy of Cognitive Biases for Information Visualizatio" doi:10.1109/TVCG.2018.2872577]
- ===Outcome===
* Barnum effect or Forer effect, the tendency for individuals to give high accuracy ratings to descriptions of their personality that supposedly are tailored specifically for them, but are in fact vague and general enough to apply to a wide range of people. This effect can provide a partial explanation for the widespread acceptance of some beliefs and practices, such as astrology, fortune telling, graphology, and some types of personality tests. [ref: "The Barnum Demonstration"]
* Belief bias, an effect where someone's evaluation of the logical strength of an argument is biased by the believability of the conclusion. [ref: (2000) "On belief bias in syllogistic reasoning" doi:10.1037/0033-295X.107.4.852]
* Berkson's paradox, the tendency to misinterpret statistical experiments involving conditional probabilities. [ref: "Berkson's Paradox {{!"]
* Clustering illusion, the tendency to overestimate the importance of small runs, streaks, or clusters in large samples of random data (that is, seeing phantom patterns). [ref: (2008) "Neuropsychology in the Courtroom: Expert Analysis of Reports and Testi"]
* Confirmation bias, the tendency to search for, interpret, focus on and remember information in a way that confirms one's preconceptions. [ref: (2004) "Cognitive Illusions: A Handbook on Fallacies and Biases in Thinking, J"]
* Congruence bias, the tendency to test hypotheses exclusively through direct testing, instead of testing possible alternative hypotheses. [ref: (2

## ORIGINAL STUDY: doi:10.1038/s41586-021-03380-y (FLoRA title: People systematically overlook subtractive changes)
Crossref: People systematically overlook subtractive changes | Gabrielle S. Adams, Benjamin A. Converse, Andrew H. Hales, Leidy E. Klotz | Nature | 2021 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W3147377228", "type": "article", "publication_year": 2021, "cited_by_count": 216, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_skill/10_1038_s41586_021_03380_y.txt (PDF via download-paper skill (fetchpdf open-access chain); may be a preprint or author manuscript)
Retrieved: 2026-10-09T12:18:30+00:00
### Abstract (Europe PMC abstract)
Improving objects, ideas or situations-whether a designer seeks to advance technology, a writer seeks to strengthen an argument or a manager seeks to encourage desired behaviour-requires a mental search for possible changes 1-3 . We investigated whether people are as likely to consider changes that subtract components from an object, idea or situation as they are to consider changes that add new components. People typically consider a limited number of promising ideas in order to manage the cognitive burden of searching through all possible ideas, but this can lead them to accept adequate solutions without considering potentially superior alternatives 4-10 . Here we show that people systematically default to searching for additive transformations, and consequently overlook subtractive transformations. Across eight experiments, participants were less likely to identify advantageous subtractive changes when the task did not (versus did) cue them to consider subtraction, when they had only one opportunity (versus several) to recognize the shortcomings of an additive search strategy or when they were under a higher (versus lower) cognitive load. Defaulting to searches for additive changes may be one reason that people struggle to mitigate overburdened schedules 11 , institutional red tape 12  and damaging effects on the planet 13,14 .

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.31234/osf.io/4jkvn_v1 (FLoRA title: People systematically overlook subtractive changes (2021): Replication and extension; FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: People systematically overlook subtractive changes (2021): Replication and extension | Adrien Alejandro Fillon, Fabien Girandola, Nathalie Bonnardel, Lionel Souchet |  | 2022 | type posted-content
Updates/relations (Crossref): [] {"has-version": [{"id-type": "doi", "id": "10.31234/osf.io/4jkvn_v2", "asserted-by": "object"}]}
OpenAlex: {"id": "https://openalex.org/W4411307823", "type": "preprint", "publication_year": 2022, "cited_by_count": 0, "is_retracted": false, "oa_status": "gold", "oa_pdf": "https://osf.io/4jkvn_v1/download", "oa_landing": "https://doi.org/10.31234/osf.io/4jkvn_v1"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_skill/10_31234_osf_io_4jkvn_v1.txt (PDF via download-paper skill (fetchpdf open-access chain); may be a preprint or author manuscript)
Retrieved: 2026-10-09T12:18:31+00:00
### Abstract (Crossref deposited abstract)
People systematically overlook subtractive changes and favor additive ones when generating new ideas. In a preregistered experiment conducted via the Prolific platform among French adults (N = 477), we replicated Experiments 2, 3 and 4 in Adams and colleagues (2021)’s study. We replicated the overlooking of subtraction, as participants generated 1155 additive ideas and only 297 subtractive ideas. Cueing participants (“Remember that you can add things or take them away”) increased the percentage who generated at least one subtractive idea (overall OR = 2.52, improvement condition, ϕ = 0.18, make-it-worse condition, ϕ = 0.24).Results therefore provided empirical support for the overlooking of subtractive changes hypothesis. We also found that norms affected the generation of new ideas (descriptive OR = 7.49, injunctive OR = 6.86). Cues and injunctive (but not descriptive) norms were both related to the asymmetry.

## Other database studies cited on this same page (each has its own packet; drafted together)
- 48c1f5d796ac93a89d7c: Outcome bias in decision evaluation. (doi:10.1037/0022-3514.54.4.569)
- cf499d86909151fbd33a: Behavioral Study of obedience. (doi:10.1037/h0040525)
- 9847f5c8beefaaf3533c: Distinction Bias: Misprediction and Mischoice Due to Joint Evaluation. (doi:10.1037/0022-3514.86.5.680)
- e7a5d2648c80813c8b7e: Hierarchical Encoding Makes Individuals in a Group Seem More Attractive (doi:10.1177/0956797613497969)
- d002c0648f67a08a1429: Lake Wobegon be gone! The "below-average effect" and the egocentric nature of comparative ability judgments. (doi:10.1037/0022-3514.77.2.221)
- cb004d84131f41223d62: The Framing of Decisions and the Psychology of Choice (doi:10.1126/science.7455683)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1016/j.enpol.2024.114149 | Do climate concerns and worries predict energy preferences? A meta-analysis | 2024 | read: abstract | mentions replication: False
- doi:10.1007/s40279-024-02125-x | Changes in Cardiorespiratory Fitness Following Exercise Training Prescribed Relative to Traditional Intensity Anchors and Physiological Thresholds: A Systematic Review with Meta-analysis of Individual Participant Data | 2024 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_1007_s40279_024_02125_x.txt
- doi:10.1016/j.tibtech.2022.02.003 | The LEGO® brick road to open science and biotechnology | 2022 | read: metadata_only | mentions replication: False
- doi:10.1016/j.gde.2025.102384 | Linking phenotype to genotype using comprehensive genomic comparisons | 2025 | read: abstract | mentions replication: False

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1016/j.enpol.2024.114149 | Do climate concerns and worries predict energy preferences? A meta-analysis | 2024 | review | cited_by 24
  Abstract: Public perceptions of energy choices will play a major role in the energy transition. Climate-related emotions, particularly concerns and worries, influence these perceptions, as they signal a heightened awareness of climate risks and greater personal salience of climate change. Here we conduct a series of meta-analyses to estimate whether climate worries and concerns influence energy preferences (k = 233; N = 85,285; 36 countries). Our findings reveal that climate worries and concerns translate into support for renewable energy, particularly solar and wind, and modest opposition to fossil fuels, particularly coal and gas. Climate worries and concerns are not associated with nuclear energy, albeit with a high degree of variance. Socio-demographic moderators, such as gender, education, and political orientation, did not influence these associations, while age and national energy supply attenuated these associations. These results suggest that climate concerns and worries translate into support for renewable energy, but not equal opposition to fossil fuels. More broadly, this meta-analysis underscores the role of climate-related emotions in shaping energy preferences, providing insig
- [review citing original] doi:10.1007/s40279-024-02125-x | Changes in Cardiorespiratory Fitness Following Exercise Training Prescribed Relative to Traditional Intensity Anchors and Physiological Thresholds: A Systematic Review with Meta-analysis of Individual Participant Data | 2024 | review | cited_by 21
  Abstract: (none)
- [review citing original] doi:10.1016/j.tibtech.2022.02.003 | The LEGO® brick road to open science and biotechnology | 2022 | review | cited_by 17
  Abstract: (none)
- [review citing original] doi:10.1016/j.gde.2025.102384 | Linking phenotype to genotype using comprehensive genomic comparisons | 2025 | review | cited_by 10
  Abstract: Comparative genomics is a powerful approach to illuminate the genetic basis of phenotypic diversity across macro-evolutionary timescales. Recent advances in sequencing, genome assembly, annotation, and comparative methods promoted large-scale analyses that unveiled genomic determinants contributing to differences in cognition, metabolism, and body plans as well as phenotypes with biomedical relevance, such as cancer resistance, longevity, and viral tolerance. These studies highlight joint contributions of multiple molecular mechanisms and indicate an underappreciated role for gene and enhancer losses driving phenotypic change. However, challenges remain, including comprehensive phenotype databases and genome annotations, improved approaches for identifying lineage-specific adaptations, and functional tests. Here, we review recent progress, highlight major discoveries, and discuss future directions for linking phenotype to genotype using comparative genomics.
