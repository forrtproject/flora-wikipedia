# Evidence packet 9847f5c8beefaaf3533c: List of cognitive biases

Frozen revision: 1376537524 (2026-09-24T19:42:49Z); https://en.wikipedia.org/w/index.php?oldid=1376537524
Live check: {"frozen_revid": "1376537524", "title": "List of cognitive biases", "live_revid": 1376537524, "live_timestamp": "2026-09-24T19:42:49Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "history_list", "context_kind": "inline", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 7}

## Article lead (plain rendering, approximate)
In psychology and cognitive science, cognitive biases are systematic patterns of deviation from norm and/or rationality in judgment. [ref: (2005) "The Handbook of Evolutionary Psychology"] [ref: (2022) "Cognitive Bias. Philogenesis or Ontogenesis" doi:10.3389/fpsyg.2022.892829] They are often studied in psychology, sociology and behavioral economics. [ref: (2005) "The Handbook of Evolutionary Psychology"]

A memory bias is a cognitive bias that either enhances or impairs the recall of a memory (either the chances that the memory will be recalled at all, or the amount of time it takes for it to be recalled, or both), or that alters the content of a reported memory.

Explanations include information-processing rules (i.e., mental shortcuts), called heuristics, that the brain uses to produce decisions or judgments. Biases have a variety of forms and appear as cognitive ("cold") bias, such as mental noise, [ref: (2012) "Toward a synthesis of cognitive biases: how noisy information processi" doi:10.1037/a0025940] or motivational ("hot") bias, such as when beliefs are distorted by wishful thinking. Both effects can be present at the same time. [ref: MacCoun RJ (1998) "Biases in the interpretation and use of research results" doi:10.1146/annurev.psych.49.1.259] [ref: (1998) "Confirmation Bias: A Ubiquitous Phenomenon in Many Guises" doi:10.1037/1089-2680.2.2.175]

There are also controversies over some of these biases as to whether they count as useless or irrational, or whether they result in useful attitudes or behavior. For example, when getting to know others, people tend to ask leading questions which seem biased towards confirming their assumptions about the person. However, this kind of confirmation bias has also been argued to be an example of social skill; a way to establish a connection with the other person. [ref: (1995) "Confirmation Bias as a Social Skill" doi:10.1177/01461672952111011]

Although this research overwhelmingly involves human subjects, some studies have found bias in non-human animals as well. For example, loss aversion has been shown in monkeys and hyperbolic discounting has been observed in rats, pigeons, and monkeys. [ref: (2010) "Hyperbolically discounted temporal difference learning" doi:10.1162/neco.2010.08-09-1080]

## Article outline
Organization of cognitive biases
Estimation
  Association
  Baseline
  Inertia
  Outcome
  Self-perspective
Decision
  Association
  Baseline
  Inertia
  Outcome
  Self-perspective
Hypothesis assessment
  Association
  Outcome
Causal attribution
  Outcome
  Self-perspective
Recall
  Association
  Baseline
  Inertia
  Outcome
  Self-perspective
Opinion reporting
  Association
  Inertia
  Outcome
  Self-perspective
See also
Footnotes
References
Further reading
External links

## Categories
Cognitive biases; Psychology lists; Behavioral finance; Cognitive science lists

## Occurrence 1: original DOI 10.1037/0022-3514.86.5.680 in section 'Baseline'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
===Baseline===
* Action bias: The tendency for someone to act when faced with a problem even when inaction would be more effective, or to act when no evident problem exists. [ref: (2021) "Why do we prefer doing something to doing nothing"] [ref: (2000) "Action Bias and Environmental Decisions" doi:10.1023/A:1026517309871]
* Additive bias: The tendency to solve problems through addition, even when subtraction is a better approach. [ref: (2021) "People add by default even when subtraction makes more sense"] [ref: (2021) "People systematically overlook subtractive changes" doi:10.1038/s41586-021-03380-y]
* Decoy effect, where preferences for either option A or B change in favor of option B when option C is presented, which is completely dominated by option B (inferior in all respects) and partially dominated by option A. [ref: "Evolution and cognitive biases: the decoy effect"]
* Ballot order effect, where candidates who are listed first often receive a small but statistically significant increase in votes compared to those listed in lower positions. [ref: Miller, J. M., & Krosnick, J. A. (1998). The impact of candidate name order on election ou]
* Cheerleader effect, the tendency for people to appear more attractive in a group than in isolation. [ref: (2014) "Hierarchical encoding makes individuals in a group seem more attractiv" doi:10.1177/0956797613497969]
* Compromise effect, choices affected if presented as extreme or average [ref: Dimara (2020) "A Task-Based Taxonomy of Cognitive Biases for Information Visualizatio" doi:10.1109/TVCG.2018.2872577]
* Denomination effect, the tendency to spend more money when it is denominated in small amounts (e.g., coins) rather than large amounts (e.g., bills). [ref: https://www.npr.org/templates/story/story.php?storyId=104063298 Why We Spend Coins Faster ]
* Disposition effect, the tendency to sell an asset that has accumulated in value and resist selling an asset that has declined in value. [ref: Shefrin, H., & Statman, M. (1985). The disposition to sell winners too early and ride lose]
* Distinction bias, the tendency to view two options as more dissimilar when evaluating them simultaneously than when evaluating them separately. [FOCAL REF: (2004) "Distinction bias: misprediction and mischoice due to joint evaluation" doi:10.1037/0022-3514.86.5.680]
* Less-is-better effect, the tendency to prefer a smaller set to a larger set judged separately, but not jointly.
* Money illusion: The tendency to concentrate on the nominal value (face value) of money rather than its value in terms of purchasing power. [ref: (2000) "Choices, values, and frames"]
* Phantom effect: choices affected by dominant but unavailable options. [ref: Dimara (2020) "A Task-Based Taxonomy of Cognitive Biases for Information Visualizatio" doi:10.1109/TVCG.2018.2872577]
* Normalcy bias, a form of cognitive dissonance, is the refusal to plan for, or react to, a disaster which has never happened before. [ref: Omer, H., & Alon, N. (1994). The continuity principle: A unified approach to disaster and ]
* Projection bias: The tendency to overestimate how much one's future selves will share one's current preferences, thoughts and values, thus leading to sub-optimal choices. [ref: (2006) "Decision and experience: why don't we choose what makes us happy?" doi:10.1016/j.tics.2005.11.007]
* Scope neglect or scope insensitivity, the tendency to be insensitive to the size of a problem when evaluating it. For example, being willing to pay as much to save 2,000 children or 20,000 children. [ref: Kahneman, D., & Knetsch, J. L. (1992). Valuing public goods: The purchase of moral satisfa]

### Paragraph (raw wikitext)
```
===Baseline===
* [[Action bias]]: The tendency for someone to act when faced with a problem even when inaction would be more effective, or to act when no evident problem exists.<ref>{{cite news |title=Why do we prefer doing something to doing nothing |url=https://thedecisionlab.com/biases/action-bias/ |access-date=30 November 2021 |work=The Decision Lab |date=30 September 2021}}</ref><ref>{{cite journal | vauthors = Patt A, Zeckhauser R |date=July 2000 |title=Action Bias and Environmental Decisions |journal=Journal of Risk and Uncertainty |language=en |volume=21 |pages=45–72 |doi=10.1023/A:1026517309871 |s2cid=154662174}}</ref>
* [[Additive bias]]: The tendency to solve problems through addition, even when subtraction is a better approach.<ref>{{cite news | vauthors = Gupta S |date=7 April 2021 |title=People add by default even when subtraction makes more sense |work=Science News |url=https://www.sciencenews.org/article/psychology-numbers-people-add-default-subtract-better |access-date=10 May 2021}}</ref><ref>{{cite journal | vauthors = Adams GS, Converse BA, Hales AH, Klotz LE | title = People systematically overlook subtractive changes | journal = Nature | volume = 592 | issue = 7853 | pages = 258–261 | date = April 2021 | pmid = 33828317 | doi = 10.1038/s41586-021-03380-y | s2cid = 233185662 | bibcode = 2021Natur.592..258A }}</ref>
* [[Decoy effect]], where preferences for either option A or B change in favor of option B when option C is presented, which is completely dominated by option B (inferior in all respects) and partially dominated by option A.<ref>{{Cite web|url=https://www.futurelearn.com/courses/complexity-and-uncertainty/0/steps/1882|title=Evolution and cognitive biases: the decoy effect |website=FutureLearn|language=en-GB|access-date=2018-10-10}}</ref>
* [[Ballot order effect]], where candidates who are listed first often receive a small but statistically significant increase in votes compared to those listed in lower positions.<ref>Miller, J. M., & Krosnick, J. A. (1998). The impact of candidate name order on election outcomes. ''Public Opinion Quarterly, 62''(3), 291–330. https://doi.org/10.1086/297848</ref>
* [[Cheerleader effect]], the tendency for people to appear more attractive in a group than in isolation.<ref>{{cite journal | vauthors = Walker D, Vul E | title = Hierarchical encoding makes individuals in a group seem more attractive | journal = Psychological Science | volume = 25 | issue = 1 | pages = 230–235 | date = January 2014 | pmid = 24163333 | doi = 10.1177/0956797613497969 | s2cid = 16309135 }}</ref>
* Compromise effect, choices affected if presented as extreme or average<ref name="Dimara2020"/>
* [[Denomination effect]], the tendency to spend more money when it is denominated in small amounts (e.g., coins) rather than large amounts (e.g., bills).<ref>[https://www.npr.org/templates/story/story.php?storyId=104063298 Why We Spend Coins Faster Than Bills] by Chana Joffe-Walt. ''All Things Considered'', 12 May 2009.</ref>
* [[Disposition effect]], the tendency to sell an asset that has accumulated in value and resist selling an asset that has declined in value.<ref>Shefrin, H., & Statman, M. (1985). The disposition to sell winners too early and ride losers too long: Theory and evidence. ''Journal of Finance, 40''(3), 777–790. https://doi.org/10.1111/j.1540-6261.1985.tb05002.x</ref>
* [[Distinction bias]], the tendency to view two options as more dissimilar when evaluating them simultaneously than when evaluating them separately.<ref>{{cite journal | vauthors = Hsee CK, Zhang J | title = Distinction bias: misprediction and mischoice due to joint evaluation | journal = Journal of Personality and Social Psychology | volume = 86 | issue = 5 | pages = 680–695 | date = May 2004 | pmid = 15161394 | doi = 10.1037/0022-3514.86.5.680 }}</ref>
* [[Less-is-better effect]], the tendency to prefer a smaller set to a larger set judged separately, but not jointly.
* [[Money illusion]]: The tendency to concentrate on the nominal value (face value) of money rather than its value in terms of purchasing power.<ref>{{cite book | vauthors = Shafir E, Diamond P, Tversky A | veditors = Kahneman D, Tversky A |date=2000 |title=Choices, values, and frames |chapter=Money Illusion |publisher=Cambridge University Press |isbn=978-0-521-62749-8 |pages=335–355}}</ref>
* Phantom effect: choices affected by dominant but unavailable options.<ref name="Dimara2020"/>
* [[Normalcy bias]], a form of cognitive dissonance, is the refusal to plan for, or react to, a disaster which has never happened before.<ref>Omer, H., & Alon, N. (1994). The continuity principle: A unified approach to disaster and trauma. ''American Journal of Community Psychology, 22''(2), 273–287. https://doi.org/10.1007/BF02506823</ref>
* [[Projection bias]]: The tendency to overestimate how much one's future selves will share one's current preferences, thoughts and values, thus leading to sub-optimal choices.<ref>{{cite journal | vauthors = Hsee CK, Hastie R | title = Decision and experience: why don't we choose what makes us happy? | journal = Trends in Cognitive Sciences | volume = 10 | issue = 1 | pages = 31–37 | date = January 2006 | pmid = 16318925 | doi = 10.1016/j.tics.2005.11.007 | url = http://maelko.typepad.com/DecisionAndExperience.pdf | url-status = live | s2cid = 12262319 | archive-url = https://web.archive.org/web/20150420205315/http://maelko.typepad.com/DecisionAndExperience.pdf | archive-date = 2015-04-20 }}</ref>
* [[Scope neglect]] or scope insensitivity, the tendency to be insensitive to the size of a problem when evaluating it. For example, being willing to pay as much to save 2,000 children or 20,000 children.<ref>Kahneman, D., & Knetsch, J. L. (1992). Valuing public goods: The purchase of moral satisfaction. ''Journal of Environmental Economics and Management, 22''(1), 57–70. https://doi.org/10.1016/0095-0696(92)90019-S</ref>
```

### Full section (plain rendering)
===Baseline===
* Action bias: The tendency for someone to act when faced with a problem even when inaction would be more effective, or to act when no evident problem exists. [ref: (2021) "Why do we prefer doing something to doing nothing"] [ref: (2000) "Action Bias and Environmental Decisions" doi:10.1023/A:1026517309871]
* Additive bias: The tendency to solve problems through addition, even when subtraction is a better approach. [ref: (2021) "People add by default even when subtraction makes more sense"] [ref: (2021) "People systematically overlook subtractive changes" doi:10.1038/s41586-021-03380-y]
* Decoy effect, where preferences for either option A or B change in favor of option B when option C is presented, which is completely dominated by option B (inferior in all respects) and partially dominated by option A. [ref: "Evolution and cognitive biases: the decoy effect"]
* Ballot order effect, where candidates who are listed first often receive a small but statistically significant increase in votes compared to those listed in lower positions. [ref: Miller, J. M., & Krosnick, J. A. (1998). The impact of candidate name order on election ou]
* Cheerleader effect, the tendency for people to appear more attractive in a group than in isolation. [ref: (2014) "Hierarchical encoding makes individuals in a group seem more attractiv" doi:10.1177/0956797613497969]
* Compromise effect, choices affected if presented as extreme or average [ref: Dimara (2020) "A Task-Based Taxonomy of Cognitive Biases for Information Visualizatio" doi:10.1109/TVCG.2018.2872577]
* Denomination effect, the tendency to spend more money when it is denominated in small amounts (e.g., coins) rather than large amounts (e.g., bills). [ref: https://www.npr.org/templates/story/story.php?storyId=104063298 Why We Spend Coins Faster ]
* Disposition effect, the tendency to sell an asset that has accumulated in value and resist selling an asset that has declined in value. [ref: Shefrin, H., & Statman, M. (1985). The disposition to sell winners too early and ride lose]
* Distinction bias, the tendency to view two options as more dissimilar when evaluating them simultaneously than when evaluating them separately. [FOCAL REF: (2004) "Distinction bias: misprediction and mischoice due to joint evaluation" doi:10.1037/0022-3514.86.5.680]
* Less-is-better effect, the tendency to prefer a smaller set to a larger set judged separately, but not jointly.
* Money illusion: The tendency to concentrate on the nominal value (face value) of money rather than its value in terms of purchasing power. [ref: (2000) "Choices, values, and frames"]
* Phantom effect: choices affected by dominant but unavailable options. [ref: Dimara (2020) "A Task-Based Taxonomy of Cognitive Biases for Information Visualizatio" doi:10.1109/TVCG.2018.2872577]
* Normalcy bias, a form of cognitive dissonance, is the refusal to plan for, or react to, a disaster which has never happened before. [ref: Omer, H., & Alon, N. (1994). The continuity principle: A unified approach to disaster and ]
* Projection bias: The tendency to overestimate how much one's future selves will share one's current preferences, thoughts and values, thus leading to sub-optimal choices. [ref: (2006) "Decision and experience: why don't we choose what makes us happy?" doi:10.1016/j.tics.2005.11.007]
* Scope neglect or scope insensitivity, the tendency to be insensitive to the size of a problem when evaluating it. For example, being willing to pay as much to save 2,000 children or 20,000 children. [ref: Kahneman, D., & Knetsch, J. L. (1992). Valuing public goods: The purchase of moral satisfa]

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 9847f5c8beefaaf3533c/article_plain.txt in the evidence directory.)

- There are also controversies over some of these biases as to whether they count as useless or irrational, or whether they result in useful attitudes or behavior. For example, when getting to know others, people tend to ask leading questions which seem biased towards confirming their assumptions about the person. However, this kind of confirmation bias has also been argued to be an example of social skill; a way to establish a connection with the other person. [ref: (1995) "Confirmation Bias as a Social Skill" doi:10.1177/01461672952111011]
- == Organization of cognitive biases ==
Although the reality of these biases is confirmed by reproducible research, [ref: "Cognitive Bias – Association for Psychological Science"] [ref: (2018) "Two decades of cognitive bias research in entrepreneurship: What do we" doi:10.1007/s11301-018-0135-9] there are often controversies about how to classify these biases or how to explain them. [ref: (1999) "MINERVA-DM: A memory processes model for judgments of likelihood" doi:10.1037/0033-295x.106.1.180] Several theoretical causes are known for some cognitive biases, which provides a classification of biases by their common generative mechanism (such as noisy information-processing [ref: (2012) "Toward a synthesis of cognitive biases: how noisy information processi" doi:10.1037/a0025940]). Gerd Gigerenzer has criticized the framing of cognitive biases as errors in judgment, and favors interpreting them as arising from rational deviations from logical thought. [ref: Gigerenzer G (2006) "Contemporary Debates in Cognitive Science"] This list is organized based on the task-based classification proposed by . This classification defines 6 tasks, namely estimation, decision, hypothesis assessment, causal attribution, recall, and opinion reporting. The biases are further loosely classified into 5 sub-categories or "flavors": [ref: Dimara (2020) "A Task-Based Taxonomy of Cognitive Biases for Information Visualizatio" doi:10.1109/TVCG.2018.2872577]
- ===Outcome===
* Barnum effect or Forer effect, the tendency for individuals to give high accuracy ratings to descriptions of their personality that supposedly are tailored specifically for them, but are in fact vague and general enough to apply to a wide range of people. This effect can provide a partial explanation for the widespread acceptance of some beliefs and practices, such as astrology, fortune telling, graphology, and some types of personality tests. [ref: "The Barnum Demonstration"]
* Belief bias, an effect where someone's evaluation of the logical strength of an argument is biased by the believability of the conclusion. [ref: (2000) "On belief bias in syllogistic reasoning" doi:10.1037/0033-295X.107.4.852]
* Berkson's paradox, the tendency to misinterpret statistical experiments involving conditional probabilities. [ref: "Berkson's Paradox {{!"]
* Clustering illusion, the tendency to overestimate the importance of small runs, streaks, or clusters in large samples of random data (that is, seeing phantom patterns). [ref: (2008) "Neuropsychology in the Courtroom: Expert Analysis of Reports and Testi"]
* Confirmation bias, the tendency to search for, interpret, focus on and remember information in a way that confirms one's preconceptions. [ref: (2004) "Cognitive Illusions: A Handbook on Fallacies and Biases in Thinking, J"]
* Congruence bias, the tendency to test hypotheses exclusively through direct testing, instead of testing possible alternative hypotheses. [ref: (2

## ORIGINAL STUDY: doi:10.1037/0022-3514.86.5.680 (FLoRA title: Distinction Bias: Misprediction and Mischoice Due to Joint Evaluation.)
Crossref: Distinction Bias: Misprediction and Mischoice Due to Joint Evaluation. | Christopher K. Hsee, Jiao Zhang | Journal of Personality and Social Psychology | 2004 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2139560547", "type": "article", "publication_year": 2004, "cited_by_count": 285, "is_retracted": false, "oa_status": "green", "oa_pdf": null, "oa_landing": "https://autopapers.ssrn.com/sol3/papers.cfm?abstract_id=929932"}
Evidence level available to you: ABSTRACT
Retrieved: 2026-10-09T12:18:22+00:00
### Abstract (Europe PMC abstract)
This research identifies a new source of failure to make accurate affective predictions or to make experientially optimal choices. When people make predictions or choices, they are often in the joint evaluation (JE) mode; when people actually experience an event, they are often in the single evaluation (SE) mode. The "utility function" of an attribute can vary systematically between SE and JE. When people in JE make predictions or choices for events to be experienced in SE, they often resort to their JE preferences rather than their SE preferences and overpredict the difference that different values of an attribute (e.g., different salaries) will make to their happiness in SE. This overprediction is referred to as the distinction bias. The present research also specifies when the distinction bias occurs and when it does not. This research contributes to literatures on experienced utility, affective forecasting, and happiness.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1016/j.jesp.2020.104052 (FLoRA title: Misprediction of affective outcomes due to different evaluation modes: Replication and extension of two distinction bias experiments by Hsee and Zhang (2004); FLoRA outcome code: mixed [screening input only, not citable]; DOI detected on page: False)
Crossref: Misprediction of affective outcomes due to different evaluation modes: Replication and extension of two distinction bias experiments by Hsee and Zhang (2004) | Farid Anvari, Jerome Olsen, Wing Yiu Hung, Gilad Feldman | Journal of Experimental Social Psychology | 2021 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W3093117347", "type": "article", "publication_year": 2020, "cited_by_count": 6, "is_retracted": false, "oa_status": "bronze", "oa_pdf": "https://www.sciencedirect.com/science/article/pii/S0022103120303929", "oa_landing": "https://doi.org/10.1016/j.jesp.2020.104052"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_skill/10_1016_j_jesp_2020_104052.txt (PDF via download-paper skill (fetchpdf open-access chain); may be a preprint or author manuscript)
Retrieved: 2026-10-09T12:18:23+00:00
### Abstract (OpenAlex reconstructed abstract)
Hsee and Zhang (2004) argued that when people face a decision and must predict future affective states , they are often in a joint evaluation (JE) mode where direct comparisons between different choice options are relatively easy. When actually experiencing (or predicting affective states for) only one of these options, people are usually in single evaluation (SE) mode where direct comparisons are more difficult. This situational difference in evaluation mode was observed to lead to overpredictions of positive affect (happiness) when people were in JE in comparison to SE for options that were quantitatively different, but there were no overpredictions for options that were qualitatively different. This effect was coined distinction bias. In the present paper, we replicated (and extended on) Studies 1 and 2 from Hsee and Zhang with 824 MTurk participants. In Study 1 we replicated the original findings: Relative to people in SE, people in JE overpredicted the happiness derived from quantitatively different hypothetical scenarios (i.e., selling 80 vs 160 books, or 160 vs 240 books), but did not overpredict the difference between qualitatively different hypothetical scenarios (i.e., selling 0 books vs 80 books; 0 being the implicit reference point that makes the two scenarios qualitatively different). Study 2 failed to find support for the original findings: People in JE did not consistently overpredict happiness for quantitatively different scenarios (i.e., copy-pasting 25 negative words vs 10 negative words, or 10 positive words vs 25 positive words). Taken together, the present paper provides mixed support for distinction bias.

## Other database studies cited on this same page (each has its own packet; drafted together)
- 48c1f5d796ac93a89d7c: Outcome bias in decision evaluation. (doi:10.1037/0022-3514.54.4.569)
- cf499d86909151fbd33a: Behavioral Study of obedience. (doi:10.1037/h0040525)
- e7a5d2648c80813c8b7e: Hierarchical Encoding Makes Individuals in a Group Seem More Attractive (doi:10.1177/0956797613497969)
- d002c0648f67a08a1429: Lake Wobegon be gone! The "below-average effect" and the egocentric nature of comparative ability judgments. (doi:10.1037/0022-3514.77.2.221)
- 94da14c2b142265f2ab3: People systematically overlook subtractive changes (doi:10.1038/s41586-021-03380-y)
- cb004d84131f41223d62: The Framing of Decisions and the Psychology of Choice (doi:10.1126/science.7455683)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1371/journal.pone.0273971 | Sure-thing vs. probabilistic charitable giving: Experimental evidence on the role of individual differences in risky and ambiguous charitable decision-making | 2022 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_1371_journal_pone_0273971.txt
  Snippet: 125 (5), 576-590. 58. hsee c. k., & zhang j. (2004). distinction bias: misprediction and mischoice due to joint evaluation. journal of personality and social psychology, 86(5), 680-695. https://doi.org/10.1037/0022-3514.86.5. 680 pmid: 15161394 59. anvari f., olsen j., hung w. y., & feldman g. (2021). misprediction of affective outcomes due to different evaluation modes: replication and extension of two distinction bias experiments by hsee and zhang (2004). journal of experimental social psychology,
- doi:10.1007/s11031-021-09885-3 | Affective forecasting and ex-offender hiring decisions | 2021 | read: metadata_only | mentions replication: False
- doi:10.1002/bdm.2361 | Preference for quicker offers: The critical roles of temporal reference points and evaluation mode | 2023 | read: abstract | mentions replication: False
- doi:10.1146/annurev.psych.60.110707.163633 | Mindful Judgment and Decision Making | 2008 | read: abstract | mentions replication: False
- doi:10.1016/j.tics.2005.11.007 | Decision and experience: why don't we choose what makes us happy? | 2005 | read: metadata_only | mentions replication: False

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1146/annurev.psych.60.110707.163633 | Mindful Judgment and Decision Making | 2008 | review | cited_by 755
  Abstract: A full range of psychological processes has been put into play to explain judgment and choice phenomena. Complementing work on attention, information integration, and learning, decision research over the past 10 years has also examined the effects of goals, mental representation, and memory processes. In addition to deliberative processes, automatic processes have gotten closer attention, and the emotions revolution has put affective processes on a footing equal to cognitive ones. Psychological process models provide natural predictions about individual differences and lifespan changes and integrate across judgment and decision making (JDM) phenomena. "Mindful" JDM research leverages our knowledge about psychological processes into causal explanations for important judgment and choice regularities, emphasizing the adaptive use of an abundance of processing alternatives. Such explanations supplement and support existing mathematical descriptions of phenomena such as loss aversion or hyperbolic discounting. Unlike such descriptions, they also provide entry points for interventions designed to help people overcome judgments or choices considered undesirable.
- [review citing original] doi:10.1016/j.tics.2005.11.007 | Decision and experience: why don't we choose what makes us happy? | 2005 | review | cited_by 249
  Abstract: (none)
- [review citing original] doi:10.1146/annurev.psych.59.103006.093726 | Motives of theHumanAnimal: Comprehending, Managing, and Sharing Inner States | 2007 | review | cited_by 105
  Abstract: We propose that four fundamental developments of the human animal together produce distinct human motives: (a) social consciousness or awareness that the outcomes or significance of a person's action (self or other) depend upon how another person (self or other) reacts to it; (b) recognizing that people's inner states can mediate their outward behaviors; (c) relating the present to both the past and the future (mental time travel); and (d) sharing reality with other people. We review a typology of four categories of concern for these motivational developments: thoughts, feelings/attitudes, competencies, and reference values (goals and standards). We then review the recent research on three specific areas related to these motivational concerns: imagining future-self inner states, managing how others comprehend us, and sharing knowledge about the world.
- [cites original and replication 10.1016/j.jesp.2020.104052] doi:10.1371/journal.pone.0273971 | Sure-thing vs. probabilistic charitable giving: Experimental evidence on the role of individual differences in risky and ambiguous charitable decision-making | 2022 | article | cited_by 8
  Abstract: Charities differ, among other things, alongside the likelihood that their interventions succeed and produce the desired outcomes and alongside the extent that such likelihood can even be articulated numerically. In this paper, we investigate what best explains charitable giving behaviour regarding charities that have interventions that will succeed with a quantifiable and high probability (sure-thing charities) and charities that have interventions that only have a small and hard to quantify probability of bringing about the desired end (probabilistic charities). We study individual differences in risk/ambiguity attitudes, empathy, numeracy, optimism, and donor type (warm glow vs. pure altruistic donor type) as potential predictors of this choice. We conduct a money incentivised, pre-registered experiment on Prolific on a representative UK sample (n = 1,506) to investigate participant choices (i) between these two types of charities and (ii) about one randomly selected charity. Overall, we find little to no evidence that individual differences predict choices regarding decisions about sure-thing and probabilistic charities, with the exception that a purely altruistic donor type pre
- [cites original and replication 10.1016/j.jesp.2020.104052] doi:10.1007/s11031-021-09885-3 | Affective forecasting and ex-offender hiring decisions | 2021 | article | cited_by 6
  Abstract: (none)
- [cites original and replication 10.1016/j.jesp.2020.104052] doi:10.1002/bdm.2361 | Preference for quicker offers: The critical roles of temporal reference points and evaluation mode | 2023 | article | cited_by 1
  Abstract: Abstract People may use the amount of time it takes someone else to reach a particular decision as input that informs their thoughts and feelings about that decision. Building on prior work suggesting that people are more inclined to accept offers that are extended more rapidly, the current research shows that this preference for quicker offers depends critically on whether offers are considered simultaneously along with other offers or individually (i.e., joint vs. separate evaluation mode), as well as on the presence and nature of explicit temporal reference points in joint evaluation mode. We theorize that the preference for quicker offers is limited to settings where (1) multiple offers are considered simultaneously and (2) the amount of time it took for these offers to be made exceeds a salient temporal reference point. This implies that the effect should not be observed when multiple offers are considered that were not all generated more slowly than an explicit temporal reference point, or when offers are considered one at a time. Evidence from seven studies provides support for this theorizing. The findings advance our understanding of the nuanced ways in which the amount of
