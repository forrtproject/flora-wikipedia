# Evidence packet d6bc57905df5db6c86f5: Outcome bias

Frozen revision: 1314900231 (2025-10-03T20:19:30Z); https://en.wikipedia.org/w/index.php?oldid=1314900231
Live check: {"frozen_revid": "1314900231", "title": "Outcome bias", "live_revid": 1314900231, "live_timestamp": "2025-10-03T20:19:30Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "central_effect", "context_kind": "inline", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 2}

## Article lead (plain rendering, approximate)
The outcome bias is an error made in evaluating the quality of a decision when the outcome of that decision is already known. Specifically, the outcome effect occurs when the same "behavior produce[s] more ethical condemnation when it happen[s] to produce bad rather than good outcome, even if the outcome is determined by chance". [ref: Gino (2009) "No Harm, No Foul: The Outcome Bias in Ethical Judgments"]

While similar to the hindsight bias, the two phenomena are markedly different. Hindsight bias focuses on memory distortion to favor the actor, while the outcome bias focuses exclusively on weighting the outcome heavier than other pieces of information in deciding if a past decision was correct.

## Article outline
Overview
See also
References

## Categories
Cognitive biases

## Occurrence 1: original DOI 10.1287/mnsc.2014.1966 in section 'Overview'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
Outside of psychological experiments, the outcome bias has been found to be substantially present in real world situations. A study looking at the evaluation of football players' performance by coaches and journalists found that players' performance is judged to be substantially better—over a whole match—if the player had a lucky goal rather than an unlucky miss (after a player's shot hit one of the goal posts). [ref: Gauriot (2019) "Fooled by Performance Randomness: Overrewarding Luck" doi:10.1162/rest_a_00783] Another study found that professional basketball coaches are "more likely to revise their strategy after a loss than a win... even when a loss was expected and even when failure is due to factors beyond the team's control." [FOCAL REF: Lefgren (2015) "Sticking with What (Barely) Worked: A Test of Outcome Bias" doi:10.1287/mnsc.2014.1966]

### Paragraph (raw wikitext)
```
Outside of [[psychological experiment]]s, the outcome bias has been found to be substantially present in real world situations. A study looking at the evaluation of football players' performance by coaches and journalists found that players' performance is judged to be substantially better—over a whole match—if the player had a lucky goal rather than an unlucky miss (after a player's shot hit one of the goal posts).<ref>{{cite journal | doi=10.1162/rest_a_00783 | title=Fooled by Performance Randomness: Overrewarding Luck | year=2019 | last1=Gauriot | first1=Romain | last2=Page | first2=Lionel | journal=The Review of Economics and Statistics | volume=101 | issue=4 | pages=658–666 | s2cid=151803360 | url=http://external-apps.qut.edu.au/business/documents/QuBEWorkingPapers/2017/Fooled%20by%20randomness.pdf }}</ref>  Another study found that professional basketball coaches are "more likely to revise their strategy after a loss than a win... even when a loss was expected and even when failure is due to factors beyond the team's control."<ref>{{cite journal|doi=10.1287/mnsc.2014.1966 |jstor=24550666 |title=Sticking with What (Barely) Worked: A Test of Outcome Bias |year=2015 |last1=Lefgren |first1=Lars |last2=Platt |first2=Brennan |last3=Price |first3=Joseph |journal=Management Science |volume=61 |issue=5 |pages=1121–1136 }}</ref>
```

### Full section (plain rendering)
==Overview==
One will often judge a past decision by its ultimate outcome instead of based on the quality of the decision at the time it was made, given what was known at that time. This is an error because no decision-maker ever knows whether or not a calculated risk will turn out for the best. The actual outcome of the decision will often be determined by chance, with some risks working out and others not. Individuals whose judgments are influenced by outcome bias are seemingly holding decision-makers responsible for events beyond their control.

Baron and Hershey (1988) presented subjects with hypothetical situations in order to test this. [ref: Baron (1988) "Outcome bias in decision evaluation" doi:10.1037/0022-3514.54.4.569]
One such example involved a surgeon deciding whether or not to do a risky surgery on a patient. The surgery had a known probability of success. Subjects were presented with either a good or bad outcome (in this case living or dying), and asked to rate the quality of the surgeon's pre-operation decision. Those presented with bad outcomes rated the decision worse than those who had good outcomes. "The ends justify the means" is an often-used aphorism to express the outcome effect when the outcome is desirable.

This mistake occurs when currently available information is incorporated when evaluating a past decision. To avoid the influence of outcome bias, one would evaluate a decision by ignoring information collected after the fact and focusing on what the right answer is, or was at the time the decision was made.

Outside of psychological experiments, the outcome bias has been found to be substantially present in real world situations. A study looking at the evaluation of football players' performance by coaches and journalists found that players' performance is judged to be substantially better—over a whole match—if the player had a lucky goal rather than an unlucky miss (after a player's shot hit one of the goal posts). [ref: Gauriot (2019) "Fooled by Performance Randomness: Overrewarding Luck" doi:10.1162/rest_a_00783] Another study found that professional basketball coaches are "more likely to revise their strategy after a loss than a win... even when a loss was expected and even when failure is due to factors beyond the team's control." [FOCAL REF: Lefgren (2015) "Sticking with What (Barely) Worked: A Test of Outcome Bias" doi:10.1287/mnsc.2014.1966]

The outcome bias is closely related to the philosophical concept of moral luck as in both concepts, the evaluation of actions is influenced by factors that are not logically justifiable. [ref: Max (2023) "Moral luck in investment contexts: We consciously find unprofitable in" doi:10.1371/journal.pone.0278677]

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: d6bc57905df5db6c86f5/article_plain.txt in the evidence directory.)

- (none found by keyword scan)

## ORIGINAL STUDY: doi:10.1287/mnsc.2014.1966 (FLoRA title: Sticking with What (Barely) Worked: A Test of Outcome Bias)
Crossref: Sticking with What (Barely) Worked: A Test of Outcome Bias | Lars Lefgren, Brennan Platt, Joseph Price | Management Science | 2015 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2088437824", "type": "article", "publication_year": 2014, "cited_by_count": 59, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1287_mnsc_2014_1966.txt (Free copy found by source search (working paper): https://www.nber.org/system/files/working_papers/w17477/w17477.pdf)
Retrieved: 2026-10-09T12:17:45+00:00
### Abstract (Crossref deposited abstract)
Outcome bias occurs when an evaluator considers ex post outcomes when judging whether a choice was correct ex ante. We formalize this cognitive bias in a simple model of distorted Bayesian updating. We then examine strategy changes made by professional basketball coaches. We find that they are more likely to revise their strategy after a loss than a win—even for narrow losses, which are uninformative about team effectiveness. This increased strategy revision following a loss occurs even when a loss was expected and even when failure is due to factors beyond the team's control. These results are consistent with our model's predictions.  Data, as supplemental material, are available at http://dx.doi.org/10.1287/mnsc.2014.1966 .  This paper was accepted by Yuval Rottenstreich, judgment and decision making.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1016/j.joep.2023.102664 (FLoRA title: Replication: Do coaches stick with what barely worked? Evidence of outcome bias in sports; FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: Replication: Do coaches stick with what barely worked? Evidence of outcome bias in sports | Pascal Flurin Meier, Raphael Flepp, Egon Franck | Journal of Economic Psychology | 2023 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W4385612895", "type": "article", "publication_year": 2023, "cited_by_count": 12, "is_retracted": false, "oa_status": "hybrid", "oa_pdf": "https://www.sciencedirect.com/science/article/pii/S016748702300065X", "oa_landing": "https://doi.org/10.1016/j.joep.2023.102664"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1016_j_joep_2023_102664.txt (Free copy found by source search (working paper): http://repec.business.uzh.ch/RePEc/zrh/wpaper/400_IBW_full.pdf)
Retrieved: 2026-10-09T12:17:46+00:00
### Abstract (OpenAlex reconstructed abstract)
We replicate the finding of Lefgren et al. (2015) showing that professional basketball coaches in the NBA discontinuously change their starting lineup more often after narrow losses than after narrow wins. This result is consistent with outcome bias because such narrow outcomes are conditionally uninformative. As our paper shows, this pattern is not restricted to the NBA; we also find evidence of outcome bias in the top women’s professional basketball league and college basketball. Finally, we show that outcome bias in coaching decisions generalizes to the National Football League (NFL). We conclude that outcome bias is credible and robust, although it has weakened over time in some instances.

## Other database studies cited on this same page (each has its own packet; drafted together)
- e83fa0ec47fae9baa987: Outcome bias in decision evaluation. (doi:10.1037/0022-3514.54.4.569)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1016/j.jebo.2025.107086 | Does performance pressure accentuate outcome bias? Evidence from managerial dismissals | 2025 | read: abstract | mentions replication: False
- doi:10.1016/j.jebo.2024.106788 | Expectational reference points and belief formation: Field evidence from financial analysts | 2024 | read: abstract | mentions replication: False
- doi:10.1016/j.joep.2025.102872 | Outcome bias in managerial decisions | 2025 | read: abstract | mentions replication: False
- doi:10.1007/s11293-024-09800-4 | Modelling Strategies in Sports | 2024 | read: abstract | mentions replication: False
- doi:10.2139/ssrn.4290726 | Are Expectations Misled by Chance? Quasi-Experimental Evidence from Financial Analysts | 2022 | read: metadata_only | mentions replication: False

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [cites original and replication 10.1016/j.joep.2023.102664] doi:10.1016/j.jebo.2025.107086 | Does performance pressure accentuate outcome bias? Evidence from managerial dismissals | 2025 | article | cited_by 6
  Abstract: Outcome bias refers to the tendency to consider observed outcomes inappropriately in evaluations, such that the influence of luck is underestimated. However, observed outcomes that fall short of expectations simultaneously trigger performance pressure. We argue that performance pressure reinforces outcome bias in evaluation decisions such as managerial dismissals, particularly after bad luck. Using data from European football and a novel identification strategy, we investigate whether managerial dismissal decisions are influenced by luck operationalized as opponent player injuries and whether this influence is more pronounced under performance pressure. Our findings reveal that luck significantly impacts dismissal decisions, particularly as performance pressure increases. Importantly, this amplified outcome bias under performance pressure predominantly occurs in instances of bad luck. These results suggest that the extent of outcome bias has been underappreciated, especially in situations involving bad luck and performance pressure.
- [cites original and replication 10.1016/j.joep.2023.102664] doi:10.1016/j.jebo.2024.106788 | Expectational reference points and belief formation: Field evidence from financial analysts | 2024 | article | cited_by 3
  Abstract: We test the influence of expectations as reference points in the belief formation of individuals using field data from financial analysts. We explore the premise that deviations from expectations can significantly alter people's perceptions of identical outcomes, thereby affecting their subsequent belief formation. We employ a regression discontinuity design to reveal that analysts whose forecasts were barely exceeded become discontinuously more optimistic than analysts whose forecasts were barely missed, despite having converging prior beliefs and observing the same performance signal about firm earnings. Furthermore, our analyses show that analysts whose forecasts were barely missed update their beliefs more strongly than do analysts whose forecasts were barely exceeded. We contribute to the literature by providing important field evidence indicating that expectations constitute a reference point that influences subsequent belief formation in an environment involving high stakes and expert decision-makers.
- [cites original and replication 10.1016/j.joep.2023.102664] doi:10.1016/j.joep.2025.102872 | Outcome bias in managerial decisions | 2025 | article | cited_by 2
  Abstract: Decisions informed by past events can be distorted when outcomes partially determined by chance are misinterpreted as being purely skill-based. This can lead to outcome bias, where decisions are evaluated based on results rather than on the quality of the performance that produced them. Outcome bias is prevalent across various domains, including managerial decision-making. This paper investigates outcome bias in professional football, a highly competitive industry. The analysis focuses on managers who were replaced mid-season between 2017/18 and 2024/25 in the top divisions of the five major European football leagues. The main finding is that clubs tend to change managers in response to recent match results rather than to underlying performance indicators. This behavior reflects an economically inefficient decision-making process driven by outcome bias.
- [cites original and replication 10.1016/j.joep.2023.102664] doi:10.1007/s11293-024-09800-4 | Modelling Strategies in Sports | 2024 | article | cited_by 2
  Abstract: Abstract This paper presents a model that examines sports teams’ strategic choices about the extent of offense/defense to adopt in competing with other teams. The mathematical formulation adopted permits the derivation of a team’s optimal strategy under different game scenarios (current score and time left to play), and team characteristics (playing at home or away, and each team’s quality). A novel feature of the model is that teams can choose a strategy at several moments in the game, thereby incorporating a comprehensive dynamic element. The National Hockey League is used as an application. Optimal coaching behavior is derived in this setting, and the impact of rule changes is assessed. The study found that removing the overtime period, disproportionally increasing the rewards for a win, or removing the point that is currently awarded to the team that loses the shootout at the end of overtime, would all lead to the adoption of more offensive strategies during the game. That outcome is aligned with higher fan interest and team revenue.
- [cites original and replication 10.1016/j.joep.2023.102664] doi:10.2139/ssrn.4290726 | Are Expectations Misled by Chance? Quasi-Experimental Evidence from Financial Analysts | 2022 | preprint | cited_by 1
  Abstract: (none)
