# Evidence packet c73d5f150dd98277ea38: Naïve cynicism

Frozen revision: 1378323504 (2026-10-04T00:07:02Z); https://en.wikipedia.org/w/index.php?oldid=1378323504
Live check: {"frozen_revid": "1378323504", "title": "Na\u00efve cynicism", "live_revid": 1378323504, "live_timestamp": "2026-10-04T00:07:02Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "broad_topic", "context_kind": "inline", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 1}

## Article lead (plain rendering, approximate)
Naïve cynicism is a philosophy of mind, cognitive bias and form of psychological egoism that occurs when people naïvely expect more egocentric bias in others than actually is the case.

The term was formally proposed by Justin Kruger and Thomas Gilovich and has been studied across a wide range of contexts including: negotiations, [ref: Tsay (2011) "Naïveté and Cynicism in Negotiations and Other Competitive Contexts" doi:10.1080/19416520.2011.587283] group-membership, [ref: Kruger (1999) "'Naive cynicism' in everyday theories of responsibility assessment: On" doi:10.1037/0022-3514.76.5.743] marriage, [ref: Kruger (1999) "'Naive cynicism' in everyday theories of responsibility assessment: On" doi:10.1037/0022-3514.76.5.743] economics, [ref: Heath (2006) "Business ethics without stakeholders" doi:10.5840/beq200616448] government policy [ref: Benforado (2008) "Naïve Cynicism: Maintaining False Perceptions in Policy Debates"] and more.

## Article outline
History
  Early examples from social psychology (1949)
  Formal laboratory experimentation (1999)
Theory
  A counter to naïve realism
  Relating to psychological egoism
Definition
Examples
  Historical examples
    Cold War
  Marketplace
  Politics
  Decision-making behavior
  Other possible real-world examples
Resulting negative outcomes
Reducing
Psychological contexts
  Groups
  Marriage
  Altruism
  Dispositionists vs. situationists
    Examples of differences
Applied contexts
  Negotiations
    Reducing naïve cynicism in negotiations
      Perspective taking
      Communication
      Feedback
  Governmental policy debates
Related biases
See also
References

## Categories
Cognitive biases

## Occurrence 1: original DOI 10.1037/0022-3514.74.1.53 in section 'Other possible real-world examples'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
===Other possible real-world examples===
* Overestimating the influence of financial compensation on people’s willingness to give blood. 
* If another person tends to favor himself when interpreting uncertain information, someone exhibiting naïve cynicism would believe the other person is intentionally misleading them for their own advantage. [ref: Tenbrunsel (1999) "Trust as an Obstacle in Environmental-Economic Disputes" doi:10.1177/00027649921954895]
* Assuming that group membership has a large influence on beliefs and attitudes. [FOCAL REF: Miller (1998) "The disparity between the actual and assumed power of self-interest" doi:10.1037/0022-3514.74.1.53]
** If an individual of one political party makes an interpretation or a statement in favor of his own party and thus in accord with his self-interest, other adults discount his statement (especially if they belong to an opposing party).
*** Likewise, if that individual makes a statement against his own self-interest, adults are more likely to believe him. [ref: Murukutla (2003) "Illusions of objectivity in the dispute between India and Pakistan ove"]

### Paragraph (raw wikitext)
```
===Other possible real-world examples===
* Overestimating the influence of financial compensation on people’s willingness to give blood. 
* If another person tends to favor himself when interpreting uncertain information, someone exhibiting naïve cynicism would believe the other person is intentionally misleading them for their own advantage.<ref name="Tenbrunsel">{{cite journal|last1=Tenbrunsel|first1=Anne|title=Trust as an Obstacle in Environmental-Economic Disputes|journal=American Behavioral Scientist|date=May 1999|volume=42|issue=8|pages=1350–1367|doi=10.1177/00027649921954895|s2cid=144973104}}</ref>
* Assuming that group membership has a large influence on beliefs and attitudes.<ref name="Miller 1998">{{cite journal|last1=Miller|first1=Dale|last2=Ratner|first2=Rebecca|title=The disparity between the actual and assumed power of self-interest|journal=Journal of Personality and Social Psychology|date=1998|volume=74|issue=1|pages=53–62|doi=10.1037/0022-3514.74.1.53|pmid=9457775}}</ref>
** If an individual of one political party makes an interpretation or a statement in favor of his own party and thus in accord with his self-interest, other adults discount his statement (especially if they belong to an opposing party).
*** Likewise, if that individual makes a statement against his own self-interest, adults are more likely to believe him.<ref name="Murukutla">{{cite journal|last1=Murukutla|first1=N|last2=Armor|first2=DA|title=Illusions of objectivity in the dispute between India and Pakistan over Kashmir.|journal=Yale University|date=2003}}</ref>
```

### Full section (plain rendering)
===Other possible real-world examples===
* Overestimating the influence of financial compensation on people’s willingness to give blood. 
* If another person tends to favor himself when interpreting uncertain information, someone exhibiting naïve cynicism would believe the other person is intentionally misleading them for their own advantage. [ref: Tenbrunsel (1999) "Trust as an Obstacle in Environmental-Economic Disputes" doi:10.1177/00027649921954895]
* Assuming that group membership has a large influence on beliefs and attitudes. [FOCAL REF: Miller (1998) "The disparity between the actual and assumed power of self-interest" doi:10.1037/0022-3514.74.1.53]
** If an individual of one political party makes an interpretation or a statement in favor of his own party and thus in accord with his self-interest, other adults discount his statement (especially if they belong to an opposing party).
*** Likewise, if that individual makes a statement against his own self-interest, adults are more likely to believe him. [ref: Murukutla (2003) "Illusions of objectivity in the dispute between India and Pakistan ove"]

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: c73d5f150dd98277ea38/article_plain.txt in the evidence directory.)

- ===Other possible real-world examples===
* Overestimating the influence of financial compensation on people’s willingness to give blood. 
* If another person tends to favor himself when interpreting uncertain information, someone exhibiting naïve cynicism would believe the other person is intentionally misleading them for their own advantage. [ref: Tenbrunsel (1999) "Trust as an Obstacle in Environmental-Economic Disputes" doi:10.1177/00027649921954895]
* Assuming that group membership has a large influence on beliefs and attitudes. [FOCAL REF: Miller (1998) "The disparity between the actual and assumed power of self-interest" doi:10.1037/0022-3514.74.1.53]
** If an individual of one political party makes an interpretation or a statement in favor of his own party and thus in accord with his self-interest, other adults discount his statement (especially if they belong to an opposing party).
*** Likewise, if that individual makes a statement against his own self-interest, adults are more likely to believe him. [ref: Murukutla (2003) "Illusions of objectivity in the dispute between India and Pakistan ove"]

## ORIGINAL STUDY: doi:10.1037/0022-3514.74.1.53 (FLoRA title: The disparity between the actual and assumed power of self-interest.)
Crossref: The disparity between the actual and assumed power of self-interest. | Dale T. Miller, Rebecca K. Ratner | Journal of Personality and Social Psychology | 1998 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W4243720160", "type": "article", "publication_year": 1998, "cited_by_count": 336, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: ABSTRACT
Retrieved: 2026-10-06T16:11:55+00:00
### Abstract (PubMed (PMID 9457775))
Five studies examined the hypothesis that people overestimate the influence of self-interest on attitudes and behaviors. The results strongly supported the hypothesis. In Study 1, participants overestimated the impact that financial reward exerted on their peers' willingness to donate blood. In 4 subsequent studies, participants overestimated the impact that group membership had on their peers' attitudes (Studies 2, 3, and 4) and behaviors (Study 5). The tendency to overestimate the impact of self-interest on others was largely unrelated to the impact that it had on participants' own attitudes and behaviors. Implications of the lay person's belief in the power of self-interest are discussed.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1525/collabra.23443 (FLoRA title: Self-interest Is Overestimated: Two Successful Pre-registered Replications and Extensions of Miller and Ratner (1998); FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: Self-interest Is Overestimated: Two Successful Pre-registered Replications and Extensions of Miller and Ratner (1998) | Cameron Brick, Adrien Fillon, Siu Kit Yeung, Meiying Wang‎, Hongye Lyu‎, Jing Yee Jane Ho‎ et al. | Collabra: Psychology | 2021 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W3160195574", "type": "article", "publication_year": 2021, "cited_by_count": 7, "is_retracted": false, "oa_status": "gold", "oa_pdf": "https://online.ucpress.edu/collabra/article-pdf/7/1/23443/464004/collabra_2021_7_1_23443.pdf", "oa_landing": "https://doi.org/10.1525/collabra.23443"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_skill/10_1525_collabra_23443.txt (PDF via download-paper skill (fetchpdf open-access chain); may be a preprint or author manuscript)
Retrieved: 2026-10-06T16:11:56+00:00
### Abstract (Crossref deposited abstract)
Self-interest is a central driver of attitudes and behaviors, but people also act against their immediate self-interest through prosocial behaviors, voting incongruously with their finances, or punishing others at personal cost. How much people believe that self-interest causes attitudes and behaviors is important, because this belief may shape regulation, shared narratives, and institutional structures. An influential paper claimed that people overestimate the power of self-interest on others’ attitudes and behavioral intentions (Miller & Ratner, 1998). We present two registered, close, and successful replications (U.S. MTurk, N = 800; U.K. Prolific, N = 799) that compared actual to estimated intentions, with open data and code. Consistent with the original article, participants overestimated the impact of payment on blood donation in Study 1, ds = 0.59 [0.51, 0.66], 0.57 [0.49, 0.64], and overestimated the importance of smoking status for smoking policy preferences in Study 4, ds = 0.75 [0.59, 0.90], 0.84 [0.73, 0.96]. These replications included two extensions: 1) communal orientation as a moderator of overestimation and 2) a more detailed measure of self-interest in Study 4 (ordinal smoking status). Communal orientation did not predict overestimation, and the ordinal smoking measure yielded similar results to the main study. Verifying the overestimation error informs behavioral theories across several fields and has practical implications for institutions that require trust and cooperation. All materials, data, and code are available at osf.io/57mdc/

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.31234/osf.io/nm2cz | Beliefs versus Reality: People Overestimate the Actual Dishonesty of Others | 2024 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_31234_osf_io_nm2cz.txt
  Snippet: mason et al., 2018), self-interested motivation (miller & ratner, 1998), extrinsic motivation (heath, 1999), and harmful social media posting (lee et al., 2025), and conversely, underestimate others' helpfulness (flynn & lake, 2008), blood donation (brick et al., 2021), and pro-climate actions (andre et al., 2024). further, people could also overestimate how dishonest others are to justify their own dishonest behavior 3 running head: dishonesty beliefs (markowitz, 2024; ross et al., 1977), and more b
  Snippet: s://doi.org/10.1207/s15327957pspr1003_2 bott, k. m., cappelen, a. w., sørensen, e. ø., & tungodden, b. (2020). you've got mail: a randomized field experiment on tax evasion. management science, 66(7), 28012819. https://doi.org/10.1287/mnsc.2019.3390 brick, c., fillon, a., yeung, s. k., wang, m., lyu, h., ho, j. y. j., wong, s. c., & feldman, g. (2021). self-interest is overestimated: two successful pre-registered replications and extensions of miller and ratner (1998). collabra: psychology, 7(1), 234
- doi:10.1016/j.tics.2006.11.001 | Perception and misperception of bias in human judgment | 2006 | read: metadata_only | mentions replication: False
- doi:10.1016/j.tics.2005.01.012 | Against simulation: the argument from error | 2005 | read: metadata_only | mentions replication: False
- doi:10.1037/0033-2909.132.2.212 | Conceptualizing the influence of social agents of behavior change: A meta-analysis of the effectiveness of HIV-prevention interventionists for different groups. | 2006 | read: abstract | mentions replication: False
- doi:10.1016/j.copsyc.2021.06.021 | Prosocial behavior and reputation: When does doing good lead to looking good? | 2021 | read: metadata_only | mentions replication: False

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1016/j.tics.2006.11.001 | Perception and misperception of bias in human judgment | 2006 | review | cited_by 444
  Abstract: (none)
- [review citing original] doi:10.1016/j.tics.2005.01.012 | Against simulation: the argument from error | 2005 | review | cited_by 316
  Abstract: (none)
- [review citing original] doi:10.1037/0033-2909.132.2.212 | Conceptualizing the influence of social agents of behavior change: A meta-analysis of the effectiveness of HIV-prevention interventionists for different groups. | 2006 | review | cited_by 166
  Abstract: A meta-analysis of 166 HIV-prevention interventions tested theoretical predictions about the effects of experts, lay community members, and similar and dissimilar others, as agents of change. In general, expert interventionists produced greater behavior change than lay community members, and the demographic and behavioral similarity between the interventionist and the recipients facilitated behavioral change. Equally importantly, there were differences across groups in the efficacy of various sources, especially among populations of low status and/or power. These findings support the hypothesis that unempowered populations are more sensitive to characteristics of the interventionists who can facilitate access to various resources. In addition, they suggest the need to ensure the availability of health professionals from diverse demographic and behavioral backgrounds.
- [review citing original] doi:10.1016/j.copsyc.2021.06.021 | Prosocial behavior and reputation: When does doing good lead to looking good? | 2021 | review | cited_by 111
  Abstract: (none)
- [review citing original] doi:10.1016/j.cobeha.2014.12.009 | Social mindfulness and social hostility | 2015 | review | cited_by 109
  Abstract: (none)
- [cites original and replication 10.1525/collabra.23443] doi:10.31234/osf.io/nm2cz | Beliefs versus Reality: People Overestimate the Actual Dishonesty of Others | 2024 | preprint | cited_by 2
  Abstract: Beliefs about the dishonesty of other people can shape our collective behavior. How accurate are these beliefs? And do we believe that other people are similarly, more, or less dishonest than they truly are? In a research program on moral decision-making consisting of 31 different effects from 11 experiments (N = 8,127), initially designed to test a broad collection of different hypotheses, participants were placed in various situations where they could lie for personal gain, without repercussions or detection risk. Crucially, we also asked all participants to estimate what percentage of other people would lie in a similar situation. Conducting an internal meta-analysis across all experiments, including both incentivized choice experiments and hypothetical marketplace scenarios, the results reveal a substantial overestimation of others' dishonesty by an average of 14 percentage points (meta-analytic effect: Hedge’s g = 0.58). That is, people are less dishonest than we tend to think, in which about 70% of our participants told the truth despite having a financial incentive to lie. These findings illustrate a pervasive tendency to overestimate the actual dishonesty of other people, s
