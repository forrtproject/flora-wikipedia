# Evidence packet 48c1f5d796ac93a89d7c: List of cognitive biases

Frozen revision: 1376537524 (2026-09-24T19:42:49Z); https://en.wikipedia.org/w/index.php?oldid=1376537524
Live check: {"frozen_revid": "1376537524", "title": "List of cognitive biases", "live_revid": 1376537524, "live_timestamp": "2026-09-24T19:42:49Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "history_list", "context_kind": "inline", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 7}

## Article lead (plain rendering, approximate)
In psychology and cognitive science, cognitive biases are systematic patterns of deviation from norm and/or rationality in judgment. [ref: (2005) "The Handbook of Evolutionary Psychology"] [ref: (2022) "Cognitive Bias. Philogenesis or Ontogenesis" doi:10.3389/fpsyg.2022.892829] They are often studied in psychology, sociology and behavioral economics. [ref: (2005) "The Handbook of Evolutionary Psychology"]

A memory bias is a cognitive bias that either enhances or impairs the recall of a memory (either the chances that the memory will be recalled at all, or the amount of time it takes for it to be recalled, or both), or that alters the content of a reported memory.

Explanations include information-processing rules (i.e., mental shortcuts), called heuristics, that the brain uses to produce decisions or judgments. Biases have a variety of forms and appear as cognitive ("cold") bias, such as mental noise, [ref: (2012) "Toward a synthesis of cognitive biases: how noisy information processi" doi:10.1037/a0025940] or motivational ("hot") bias, such as when beliefs are distorted by wishful thinking. Both effects can be present at the same time. [ref: MacCoun RJ (1998) "Biases in the interpretation and use of research results" doi:10.1146/annurev.psych.49.1.259] [ref: (1998) "Confirmation Bias: A Ubiquitous Phenomenon in Many Guises" doi:10.1037/1089-2680.2.2.175]

There are also controversies over some of these biases as to whether they count as useless or irrational, or whether they result in useful attitudes or behavior. For example, when getting to know others, people tend to ask leading questions which seem biased towards confirming their assumptions about the person. However, this kind of confirmation bias has also been argued to be an example of social skill; a way to establish a connection with the other person. [ref: (1995) "Confirmation Bias as a Social Skill" doi:10.1177/01461672952111011]

Although this research overwhelmingly involves human subjects, some studies have found bias in non-human animals as well. For example, loss aversion has been shown in monkeys and hyperbolic discounting has been observed in rats, pigeons, and monkeys. [ref: (2010) "Hyperbolically discounted temporal difference learning" doi:10.1162/neco.2010.08-09-1080]

## Article outline
Organization of cognitive biases
Estimation
  Association
  Baseline
  Inertia
  Outcome
  Self-perspective
Decision
  Association
  Baseline
  Inertia
  Outcome
  Self-perspective
Hypothesis assessment
  Association
  Outcome
Causal attribution
  Outcome
  Self-perspective
Recall
  Association
  Baseline
  Inertia
  Outcome
  Self-perspective
Opinion reporting
  Association
  Inertia
  Outcome
  Self-perspective
See also
Footnotes
References
Further reading
External links

## Categories
Cognitive biases; Psychology lists; Behavioral finance; Cognitive science lists

## Occurrence 1: original DOI 10.1037/0022-3514.54.4.569 in section 'Outcome'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
===Outcome===
* : The tendency to expect or predict more extreme outcomes than those outcomes that actually happen. [ref: (2012) "Toward a synthesis of cognitive biases: how noisy information processi" doi:10.1037/a0025940]
* Hedonic recall bias: The tendency for people who are satisfied with their wage to overestimate how much they earn, and conversely, for people who are unsatisfied with their wage to underestimate it. [ref: (2017) "Hedonic recall bias. Why you should not ask people how much they earn" doi:10.1016/j.jebo.2017.09.002]
* Illusion of validity, the tendency to overestimate the accuracy of one's judgments, especially when available information is consistent or inter-correlated. [ref: (2003) "Handbook of Organizational Learning and Knowledge"]
* Impact bias: The tendency to overestimate the length or the intensity of the impact of future feeling states. [ref: (2004) "Integrating temporal biases: the interplay of focal thoughts and acces" doi:10.1111/j.0956-7976.2004.00704.x]
* Outcome bias: The tendency to judge a decision by its eventual outcome instead of the quality of the decision at the time it was made. [FOCAL REF: Baron, J., & Hershey, J. C. (1988). Outcome bias in decision evaluation. Journal of Pers]
* Planning fallacy, the tendency for people to underestimate the time it will take them to complete a given task. [ref: (2004) "Integrating temporal biases: the interplay of focal thoughts and acces" doi:10.1111/j.0956-7976.2004.00704.x]
* Restraint bias, the tendency to overestimate one's ability to show restraint in the face of temptation. [ref: Nordgren, L. F., van Harreveld, F., & van der Pligt, J. (2009). The restraint bias: How th]
* Sexual overperception bias, the tendency to overestimate sexual interest of another person in oneself, and sexual underperception bias, the tendency to underestimate it. [ref: Haselton, M. G. (2003). The sexual overperception bias: Evidence of a systematic bias in m]

### Paragraph (raw wikitext)
```
===Outcome===
* {{vanchor|Exaggerated expectation}}: The tendency to expect or predict more extreme outcomes than those outcomes that actually happen.<ref name="HilbertPsychBul" />
* Hedonic recall bias: The tendency for people who are satisfied with their wage to overestimate how much they earn, and conversely, for people who are unsatisfied with their wage to underestimate it.<ref>{{cite journal | vauthors = Prati A | title = Hedonic recall bias. Why you should not ask people how much they earn | journal = Journal of Economic Behavior & Organization | volume = 143 | pages = 78–97 | doi = 10.1016/j.jebo.2017.09.002 | year = 2017}}</ref>
* [[Illusion of validity]], the tendency to overestimate the accuracy of one's judgments, especially when available information is consistent or inter-correlated.<ref>{{cite book | vauthors = Dierkes M, Antal AB, Child J, Nonaka I |title=Handbook of Organizational Learning and Knowledge |date=2003 |publisher=Oxford University Press |isbn=978-0-19-829582-2 |page=22 |url={{Google books |plainurl=yes |id=JRd7RZzzw_wC |page=22 }} |access-date=9 September 2013}}</ref>
* [[Impact bias]]: The tendency to overestimate the length or the intensity of the impact of future feeling states.<ref name="temporal">{{cite journal | vauthors = Sanna LJ, Schwarz N | title = Integrating temporal biases: the interplay of focal thoughts and accessibility experiences | journal = Psychological Science | volume = 15 | issue = 7 | pages = 474–481 | date = July 2004 | pmid = 15200632 | doi = 10.1111/j.0956-7976.2004.00704.x | s2cid = 10998751 }}</ref>
* [[Outcome bias]]: The tendency to judge a decision by its eventual outcome instead of the quality of the decision at the time it was made.<ref>Baron, J., & Hershey, J. C. (1988). Outcome bias in decision evaluation. ''Journal of Personality and Social Psychology, 54''(4), 569–579. https://doi.org/10.1037/0022-3514.54.4.569</ref>
* [[Planning fallacy]], the tendency for people to underestimate the time it will take them to complete a given task.<ref name="temporal" />
* [[Restraint bias]], the tendency to overestimate one's ability to show restraint in the face of temptation.<ref>Nordgren, L. F., van Harreveld, F., & van der Pligt, J. (2009). The restraint bias: How the illusion of self‑restraint promotes impulsive behavior. ''Psychological Science, 20''(12), 1523–1528. https://doi.org/10.1111/j.1467-9280.2009.02468.x</ref>
* [[Sexual overperception bias]], the tendency to overestimate sexual interest of another person in oneself, and [[sexual underperception bias]], the tendency to underestimate it.<ref>Haselton, M. G. (2003). The sexual overperception bias: Evidence of a systematic bias in men's judgments of women's sexual interest. ''Journal of Research in Personality, 37''(1), 34–47. https://doi.org/10.1016/S0092-6566(02)00510-7</ref>
```

### Full section (plain rendering)
===Outcome===
* : The tendency to expect or predict more extreme outcomes than those outcomes that actually happen. [ref: (2012) "Toward a synthesis of cognitive biases: how noisy information processi" doi:10.1037/a0025940]
* Hedonic recall bias: The tendency for people who are satisfied with their wage to overestimate how much they earn, and conversely, for people who are unsatisfied with their wage to underestimate it. [ref: (2017) "Hedonic recall bias. Why you should not ask people how much they earn" doi:10.1016/j.jebo.2017.09.002]
* Illusion of validity, the tendency to overestimate the accuracy of one's judgments, especially when available information is consistent or inter-correlated. [ref: (2003) "Handbook of Organizational Learning and Knowledge"]
* Impact bias: The tendency to overestimate the length or the intensity of the impact of future feeling states. [ref: (2004) "Integrating temporal biases: the interplay of focal thoughts and acces" doi:10.1111/j.0956-7976.2004.00704.x]
* Outcome bias: The tendency to judge a decision by its eventual outcome instead of the quality of the decision at the time it was made. [FOCAL REF: Baron, J., & Hershey, J. C. (1988). Outcome bias in decision evaluation. Journal of Pers]
* Planning fallacy, the tendency for people to underestimate the time it will take them to complete a given task. [ref: (2004) "Integrating temporal biases: the interplay of focal thoughts and acces" doi:10.1111/j.0956-7976.2004.00704.x]
* Restraint bias, the tendency to overestimate one's ability to show restraint in the face of temptation. [ref: Nordgren, L. F., van Harreveld, F., & van der Pligt, J. (2009). The restraint bias: How th]
* Sexual overperception bias, the tendency to overestimate sexual interest of another person in oneself, and sexual underperception bias, the tendency to underestimate it. [ref: Haselton, M. G. (2003). The sexual overperception bias: Evidence of a systematic bias in m]

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 48c1f5d796ac93a89d7c/article_plain.txt in the evidence directory.)

- There are also controversies over some of these biases as to whether they count as useless or irrational, or whether they result in useful attitudes or behavior. For example, when getting to know others, people tend to ask leading questions which seem biased towards confirming their assumptions about the person. However, this kind of confirmation bias has also been argued to be an example of social skill; a way to establish a connection with the other person. [ref: (1995) "Confirmation Bias as a Social Skill" doi:10.1177/01461672952111011]
- == Organization of cognitive biases ==
Although the reality of these biases is confirmed by reproducible research, [ref: "Cognitive Bias – Association for Psychological Science"] [ref: (2018) "Two decades of cognitive bias research in entrepreneurship: What do we" doi:10.1007/s11301-018-0135-9] there are often controversies about how to classify these biases or how to explain them. [ref: (1999) "MINERVA-DM: A memory processes model for judgments of likelihood" doi:10.1037/0033-295x.106.1.180] Several theoretical causes are known for some cognitive biases, which provides a classification of biases by their common generative mechanism (such as noisy information-processing [ref: (2012) "Toward a synthesis of cognitive biases: how noisy information processi" doi:10.1037/a0025940]). Gerd Gigerenzer has criticized the framing of cognitive biases as errors in judgment, and favors interpreting them as arising from rational deviations from logical thought. [ref: Gigerenzer G (2006) "Contemporary Debates in Cognitive Science"] This list is organized based on the task-based classification proposed by . This classification defines 6 tasks, namely estimation, decision, hypothesis assessment, causal attribution, recall, and opinion reporting. The biases are further loosely classified into 5 sub-categories or "flavors": [ref: Dimara (2020) "A Task-Based Taxonomy of Cognitive Biases for Information Visualizatio" doi:10.1109/TVCG.2018.2872577]
- ===Outcome===
* Barnum effect or Forer effect, the tendency for individuals to give high accuracy ratings to descriptions of their personality that supposedly are tailored specifically for them, but are in fact vague and general enough to apply to a wide range of people. This effect can provide a partial explanation for the widespread acceptance of some beliefs and practices, such as astrology, fortune telling, graphology, and some types of personality tests. [ref: "The Barnum Demonstration"]
* Belief bias, an effect where someone's evaluation of the logical strength of an argument is biased by the believability of the conclusion. [ref: (2000) "On belief bias in syllogistic reasoning" doi:10.1037/0033-295X.107.4.852]
* Berkson's paradox, the tendency to misinterpret statistical experiments involving conditional probabilities. [ref: "Berkson's Paradox {{!"]
* Clustering illusion, the tendency to overestimate the importance of small runs, streaks, or clusters in large samples of random data (that is, seeing phantom patterns). [ref: (2008) "Neuropsychology in the Courtroom: Expert Analysis of Reports and Testi"]
* Confirmation bias, the tendency to search for, interpret, focus on and remember information in a way that confirms one's preconceptions. [ref: (2004) "Cognitive Illusions: A Handbook on Fallacies and Biases in Thinking, J"]
* Congruence bias, the tendency to test hypotheses exclusively through direct testing, instead of testing possible alternative hypotheses. [ref: (2

## ORIGINAL STUDY: doi:10.1037/0022-3514.54.4.569 (FLoRA title: Outcome bias in decision evaluation.)
Crossref: Outcome bias in decision evaluation. | Jonathan Baron, John C. Hershey | Journal of Personality and Social Psychology | 1988 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W4242732483", "type": "article", "publication_year": 1988, "cited_by_count": 689, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1037_0022_3514_54_4_569.txt (Free copy found by source search (accepted manuscript): https://www.sas.upenn.edu/~baron/papers.htm/judg.html)
Retrieved: 2026-10-06T16:10:08+00:00

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.5334/irsp.751 (FLoRA title: Outcomes Affect Evaluations of Decision Quality: Replication and Extensions of Baron and Hershey's (1988) Outcome Bias Experiment 1; FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: Outcomes Affect Evaluations of Decision Quality: Replication and Extensions of Baron and Hershey&amp;rsquo;s (1988) Outcome Bias Experiment 1 | Sriraj Aiyer, Hoi Ching Kam, Ka Yuk Ng, Nathaniel A. Young, Jiaxin Shi, Gilad Feldman | International Review of Social Psychology | 2023 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W4385355091", "type": "article", "publication_year": 2023, "cited_by_count": 3, "is_retracted": false, "oa_status": "diamond", "oa_pdf": "https://storage.googleapis.com/jnl-up-j-irsp-files/journals/1/articles/751/64d085974dca9.pdf", "oa_landing": "https://doi.org/10.5334/irsp.751"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext/10_5334_irsp_751.txt (Europe PMC open-access full text (PMC12372742))
Retrieved: 2026-10-06T16:10:09+00:00
### Abstract (Crossref deposited abstract)
Outcome bias is the phenomenon whereby decisions which resulted in successful outcomes were rated more favorably than when the same decisions resulted in failures. We conducted a pre-registered replication and extension of Experiment 1 (original’s: N = 20) from the classic Baron and Hershey (1988) with an online Amazon Mechanical Turk sample using CloudResearch (N = 692), switching from a within-participants design in the original experiment to a between-participants design. We tested outcome bias by measuring participants’ ratings of the quality of decisions in medical scenarios. For the replication (pre-registered) part of the study, we successfully replicated signal and direction of the outcome bias (original: dpaired = 0.21 – 0.53; replication: dindependent = 0.77 [0.62, 0.93] to 1.1 [0.94, 1.26]), and even for participants who stated that outcomes should not be taken into consideration when evaluating decisions (d = 0.64 [0.21, 1.08]). For the extension part of the study, we found differences, dependent on outcome types, in evaluations of the perceived importance of considering the outcome, the perceived responsibility of decision-makers, and the perception that others would act similarly given the choice by outcome type. Materials, data, and code are available on Open Science Framework (OSF): https://osf.io/knjhu/.

## Other database studies cited on this same page (each has its own packet; drafted together)
- cf499d86909151fbd33a: Behavioral Study of obedience. (doi:10.1037/h0040525)
- 9847f5c8beefaaf3533c: Distinction Bias: Misprediction and Mischoice Due to Joint Evaluation. (doi:10.1037/0022-3514.86.5.680)
- e7a5d2648c80813c8b7e: Hierarchical Encoding Makes Individuals in a Group Seem More Attractive (doi:10.1177/0956797613497969)
- d002c0648f67a08a1429: Lake Wobegon be gone! The "below-average effect" and the egocentric nature of comparative ability judgments. (doi:10.1037/0022-3514.77.2.221)
- 94da14c2b142265f2ab3: People systematically overlook subtractive changes (doi:10.1038/s41586-021-03380-y)
- cb004d84131f41223d62: The Framing of Decisions and the Psychology of Choice (doi:10.1126/science.7455683)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.4103/jacs.jacs_21_26 | Applied Consciousness: Toward a Working Definition | 2026 | read: metadata_only | mentions replication: False
- doi:10.1017/jdm.2025.10011 | On the process and value of direct close replications: A rejoinder to Shafir and Cheek’s (2024) commentary on Chandrashekar et al. (2021) | 2025 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_1017_jdm_2025_10011.txt
  Snippet: e (2025) team suggests that the answer to all of those questions is 'yes'. three of the target articles that we successfully replicated from the 1970s and the 1980s using very similar items with little to no adjustments were about these 3 biases. in aiyer et al. (2023), we successfully replicated outcome bias demonstrated by https://doi.org/10.1017/jdm.2025.10011 published online by cambridge university press 10 subramanya prasad chandrashekar and gilad feldman baron and hershey (1988) showing that a
  Snippet: authorship of this article. competing interests. we are the authors of the target article for the commentary. other than that, we declare no potential competing interests with respect to the authorship and/or publication of this article. references aiyer, s., kam, h. c., ng, k. y., young, n. a., shi, j., & feldman, g. (2023). outcomes affect evaluations of decision quality: replication and extensions of baron and hershey's (1988) outcome bias experiment 1 international review of social psychology, 3
- doi:10.1146/annurev-psych-020821-114157 | Replicability, Robustness, and Reproducibility in Psychological Science | 2021 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_1146_annurev_psych_020821_114157.txt
- doi:10.1016/j.copsyc.2015.07.016 | Moral coherence processes: constructing culpability and consequences | 2015 | read: metadata_only | mentions replication: False
- doi:10.1177/01461672211042315 | Action and Inaction in Moral Judgments and Decisions: Meta-Analysis of Omission Bias Omission-Commission Asymmetries | 2021 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_1177_01461672211042315.txt

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1146/annurev-psych-020821-114157 | Replicability, Robustness, and Reproducibility in Psychological Science | 2021 | review | cited_by 777
  Abstract: Replication-an important, uncommon, and misunderstood practice-is gaining appreciation in psychology. Achieving replicability is important for making research progress. If findings are not replicable, then prediction and theory development are stifled. If findings are replicable, then interrogation of their meaning and validity can advance knowledge. Assessing replicability can be productive for generating and testing hypotheses by actively confronting current understandings to identify weaknesses and spur innovation. For psychology, the 2010s might be characterized as a decade of active confrontation. Systematic and multi-site replication projects assessed current understandings and observed surprising failures to replicate many published findings. Replication efforts highlighted sociocultural challenges such as disincentives to conduct replications and a tendency to frame replication as a personal attack rather than a healthy scientific practice, and they raised awareness that replication contributes to self-correction. Nevertheless, innovation in doing and understanding replication and its cousins, reproducibility and robustness, has positioned psychology to improve research pra
- [review citing original] doi:10.1016/j.copsyc.2015.07.016 | Moral coherence processes: constructing culpability and consequences | 2015 | review | cited_by 53
  Abstract: (none)
- [review citing original] doi:10.1177/01461672211042315 | Action and Inaction in Moral Judgments and Decisions: Meta-Analysis of Omission Bias Omission-Commission Asymmetries | 2021 | review | cited_by 43
  Abstract: Omission bias is people’s tendency to evaluate harm done through omission as less morally wrong and less blameworthy than commission when there is harm. However, findings are inconsistent. We conducted a preregistered meta-analysis, with 21 samples (13 articles, 49 effects) on omission-commission asymmetries in judgments and decisions. We found an overall effect of g = 0.45, 95% confidence interval (CI) = [0.14, 0.77], with stronger effects for morality and blame than for decisions. Publication bias tests produced mixed results with some indication for publication bias, though effects persisted even after most publication bias adjustments. The small sample of studies included limited our ability to draw definite conclusions regarding moderators, with inconclusive findings when applying different models. After compensating for low power, we found indication for moderation by role responsibility, perspective (self vs. others), outcome type, and study design. We hope this meta-analysis will inspire research on this phenomenon and applications to real-life, especially given the raging pandemic. Materials, data, and code are available on https://osf.io/9fcqm/ .
- [review citing original] doi:10.1213/ane.0000000000006666 | Identifying, Understanding, and Minimizing Unconscious Cognitive Biases in Perioperative Crisis Management: A Narrative Review | 2023 | review | cited_by 5
  Abstract: Rapid clinical decision-making behavior is often based on pattern recognition and other mental shortcuts. Although such behavior is often faster than deliberative thinking, it can also lead to errors due to unconscious cognitive biases (UCBs). UCBs may contribute to inaccurate diagnoses, hamper interpersonal communication, trigger inappropriate clinical interventions, or result in management delays. The authors review the literature on UCBs and discuss their potential impact on perioperative crisis management. Using the Scale for the Assessment of Narrative Review Articles (SANRA), publications with the most relevance to UCBs in perioperative crisis management were selected for inclusion. Of the 19 UCBs that have been most investigated in the medical literature, the authors identified 9 that were judged to be clinically relevant or most frequently occurring during perioperative crisis management. Formal didactic training on concepts of deliberative thinking has had limited success in reducing the presence of UCBs during clinical decision-making. The evolution of clinical decision support tools (CDSTs) has demonstrated efficacy in improving deliberative clinical decision-making, pos
- [cites original and replication 10.5334/irsp.751] doi:10.4103/jacs.jacs_21_26 | Applied Consciousness: Toward a Working Definition | 2026 | article | cited_by 0
  Abstract: (none)
- [cites original and replication 10.5334/irsp.751] doi:10.1017/jdm.2025.10011 | On the process and value of direct close replications: A rejoinder to Shafir and Cheek’s (2024) commentary on Chandrashekar et al. (2021) | 2025 | article | cited_by 0
  Abstract: Abstract The studies in Shafir (1993, Memory & Cognition 21, 546–556) examined the impact of decision frames (choosing vs. rejecting) on decision-making. Our replication—Chandrashekar et al. (2021, Judgment and Decision Making 16, 36–56)—revealed mixed results with only partial support for the original findings, concluding a successful replication of only 2 out of 8 scenarios. Our data from an exploratory extension suggested a pattern in support of an alternative theoretical mechanism aligning with Wedell’s (1997, Memory & Cognition 25, 873–887) accentuation hypothesis. Shafir and Cheek’s (2024) commentary criticized our approach to replications, and the value and importance of direct close replications overall, and shared their views regarding the theory and scope of the phenomenon, with new information about what they consider to be needed steps to empirically test the phenomenon. In our response, we clarify misunderstandings and address empirical findings shared in the commentary. We discuss and defend the value and importance of direct replications and the necessity for full transparency regarding the theoretical assumptions and the process of empirical investigations. Finally,
