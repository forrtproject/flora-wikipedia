# Evidence packet 18b1cb4274004eeec969: Romeo and Juliet effect

Frozen revision: 1377085873 (2026-09-27T20:44:59Z); https://en.wikipedia.org/w/index.php?oldid=1377085873
Live check: {"frozen_revid": "1377085873", "title": "Romeo and Juliet effect", "live_revid": 1377085873, "live_timestamp": "2026-09-27T20:44:59Z", "checked_at": "2026-10-06T16:46:56+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "central_effect", "context_kind": "inline", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 1}

## Article lead (plain rendering, approximate)
The Romeo and Juliet effect describes the intensification of romantic feelings in relationship when met by parental opposition referencing the protagonists of the William Shakespeare play Romeo and Juliet, whose families were opposed to their union. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373]

## Article outline
History
Subsequent development
Later research
See also
References
Further reading

## Categories
Intimate relationships; Romeo and Juliet; Parenting; Interpersonal conflict; Romance; Psychological effects

## Occurrence 1: original (named-reference reuse) DOI 10.1037/h0033373 in section '(lead)'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
The Romeo and Juliet effect describes the intensification of romantic feelings in relationship when met by parental opposition referencing the protagonists of the William Shakespeare play Romeo and Juliet, whose families were opposed to their union. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373]

### Paragraph (raw wikitext)
```
{{Short description|Increased romantic feelings due to parental opposition}}
[[File:Frank Bernard Dicksee - Romeo and Juliet, 1884.jpg|thumb|Romeo and Juliet]]
The '''Romeo and Juliet effect''' describes the intensification of romantic feelings in relationship when met by parental opposition referencing the protagonists of the [[William Shakespeare]] play ''[[Romeo and Juliet]],'' whose families were opposed to their union.<ref name="Driscoll" />
```

### Full section (plain rendering)
The Romeo and Juliet effect describes the intensification of romantic feelings in relationship when met by parental opposition referencing the protagonists of the William Shakespeare play Romeo and Juliet, whose families were opposed to their union. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373]

== History ==
An early review of romantic love in the Western world emphasized the persistent association of obstacles or grave difficulties with the intensity of love, as in William Shakespeare's Romeo and Juliet. [ref: Derougemont, D. Love in the Western World. (Trans, by M. Belgion) New York: Harcourt, ] 

In 1972, Richard Driscoll, along with Keith Davis and Milton Lipetz, published results from a longitudinal study on relationships suggesting an underlying truth to such an idea. The results suggest that parental interference in a loving relationship may intensify the feelings of romantic love between members of the couple, at least for a brief span of time. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373] The study interviewed 140 couples, both married and unmarried, via questionnaires and surveys. The researchers measured feelings about the spouse, about their perceived love, spousal trustworthiness, neediness, and parental interference. The couples completed these procedures at a first session and then, around six months to a year later, completed identical surveying sessions to see how their relationships have endured the past months. About 80% of the original participants completed the second session. Only a small portion of the original sample had ended their relationships or gotten divorced. In the results of the overall study, there was found to be an increase in love ratings for one's partner and parental interference. Interference did seem to have other frustrating effects, as it also was associated with decreased trust, increased criticalness, and increased frequency of negative, bothersome behaviors. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373]

== Subsequent development ==
While Driscoll's study has not been replicated, other researchers have continued to discuss parental influence on relationship stability. 

In 1983, Malcolm Parks conducted a study to determine influences of peers and families on relationship involvement, which showed little to no support of Driscoll's previous research. Opposition from the partner's family was not associated with greater emotional attachment. [ref: Parks, M. R., Stan, C. M., Eggert, L. L. (1983). "Romantic involvement and social network ] These findings set the path for many other studies on romantic involvement and support systems involvement and approval.

==Later research==
Additional research has focused upon the topic of a "Romeo and Juliet Effect". In 2001, Diane Felmlee found similar findings to study by Malcolm Parks. For instance, perceptions of approval from an individual's friends and approval from a partner's family members reduce the possibility that a relationship will end. [ref: Felmlee, D. (2001). "No couple is an island: A social stability network perspective on dya] 

A study by Susan Sprecher delved into the subject of the influence of social networks on relationships. It found that individuals from a social network believed that their personal opinions, whether of support or opposition, affected the romantic relationships they had earlier acknowledged as being in their social networks.

H. Colleen Sinclair found that approval or disapproval by friends had a great effect on perceptions of potential dating partners by the participants in her research. Similarly to the previously discussed studies, however, Sinclair and colleagues found no significant support for the "Romeo and Juliet Effect" that parental and familial opinions are the prevailing influences. [ref: Wright, B. L., Sinclair, H. C., Pulling the strings: Effects of friend and parent opinions]

==See also==
* Breadcrumbing
* Fatal attraction (sociology)
* Limerence
* On-again, off-again relationship
* Reactance (psychology)
* Romance

==References==

==Further reading==
*Brehm, J. W. (1999). The intensity of emotion. Personality And Social Psychology Review, 3(1), 2-22. 
*Parks, M. R., Stan, C. M., Eggert, L. L. (1983). Romantic involvement and social network involvement. Social Psychology Quarterly, 46(2), 116-131. 
*Wright, B. L., Sinclair, H. C. (2012a). Pulling the strings: Effects of friend and parent opinions on dating choices. Personal Relationships. .

## Occurrence 2: original DOI 10.1037/h0033373 in section 'History'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
In 1972, Richard Driscoll, along with Keith Davis and Milton Lipetz, published results from a longitudinal study on relationships suggesting an underlying truth to such an idea. The results suggest that parental interference in a loving relationship may intensify the feelings of romantic love between members of the couple, at least for a brief span of time. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373] The study interviewed 140 couples, both married and unmarried, via questionnaires and surveys. The researchers measured feelings about the spouse, about their perceived love, spousal trustworthiness, neediness, and parental interference. The couples completed these procedures at a first session and then, around six months to a year later, completed identical surveying sessions to see how their relationships have endured the past months. About 80% of the original participants completed the second session. Only a small portion of the original sample had ended their relationships or gotten divorced. In the results of the overall study, there was found to be an increase in love ratings for one's partner and parental interference. Interference did seem to have other frustrating effects, as it also was associated with decreased trust, increased criticalness, and increased frequency of negative, bothersome behaviors. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373]

### Paragraph (raw wikitext)
```
In 1972, Richard Driscoll, along with Keith Davis and Milton Lipetz, published results from a [[longitudinal study]] on relationships suggesting an underlying truth to such an idea. The results suggest that parental interference in a loving relationship may intensify the feelings of [[Romance (love)|romantic love]] between members of the couple, at least for a brief span of time.<ref name="Driscoll">{{Cite journal|last1=Driscoll|first1=Richard|last2=Davis|first2=Keith E.|last3=Lipetz|first3=Milton E.|date=1972|title=Parental interference and romantic love: The Romeo and Juliet effect.|journal=Journal of Personality and Social Psychology|language=en|volume=24|issue=1|pages=1–10|doi=10.1037/h0033373|pmid=5079550|issn=1939-1315}}</ref> The study interviewed 140 couples, both married and unmarried, via [[Questionnaire|questionnaires]] and surveys. The researchers measured feelings about the spouse, about their perceived love, spousal trustworthiness, neediness, and parental interference. The couples completed these procedures at a first session and then, around six months to a year later, completed identical surveying sessions to see how their relationships have endured the past months. About 80% of the original participants completed the second session. Only a small portion of the original sample had ended their relationships or gotten [[Divorce|divorced]]. In the results of the overall study, there was found to be an increase in love ratings for one's partner and parental interference. Interference did seem to have other frustrating effects, as it also was associated with decreased trust, increased criticalness, and increased frequency of negative, bothersome behaviors.<ref name="Driscoll" />
```

### Full section (plain rendering)
== History ==
An early review of romantic love in the Western world emphasized the persistent association of obstacles or grave difficulties with the intensity of love, as in William Shakespeare's Romeo and Juliet. [ref: Derougemont, D. Love in the Western World. (Trans, by M. Belgion) New York: Harcourt, ] 

In 1972, Richard Driscoll, along with Keith Davis and Milton Lipetz, published results from a longitudinal study on relationships suggesting an underlying truth to such an idea. The results suggest that parental interference in a loving relationship may intensify the feelings of romantic love between members of the couple, at least for a brief span of time. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373] The study interviewed 140 couples, both married and unmarried, via questionnaires and surveys. The researchers measured feelings about the spouse, about their perceived love, spousal trustworthiness, neediness, and parental interference. The couples completed these procedures at a first session and then, around six months to a year later, completed identical surveying sessions to see how their relationships have endured the past months. About 80% of the original participants completed the second session. Only a small portion of the original sample had ended their relationships or gotten divorced. In the results of the overall study, there was found to be an increase in love ratings for one's partner and parental interference. Interference did seem to have other frustrating effects, as it also was associated with decreased trust, increased criticalness, and increased frequency of negative, bothersome behaviors. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373]

## Occurrence 3: original (named-reference reuse) DOI 10.1037/h0033373 in section 'History'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
In 1972, Richard Driscoll, along with Keith Davis and Milton Lipetz, published results from a longitudinal study on relationships suggesting an underlying truth to such an idea. The results suggest that parental interference in a loving relationship may intensify the feelings of romantic love between members of the couple, at least for a brief span of time. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373] The study interviewed 140 couples, both married and unmarried, via questionnaires and surveys. The researchers measured feelings about the spouse, about their perceived love, spousal trustworthiness, neediness, and parental interference. The couples completed these procedures at a first session and then, around six months to a year later, completed identical surveying sessions to see how their relationships have endured the past months. About 80% of the original participants completed the second session. Only a small portion of the original sample had ended their relationships or gotten divorced. In the results of the overall study, there was found to be an increase in love ratings for one's partner and parental interference. Interference did seem to have other frustrating effects, as it also was associated with decreased trust, increased criticalness, and increased frequency of negative, bothersome behaviors. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373]

### Paragraph (raw wikitext)
```
In 1972, Richard Driscoll, along with Keith Davis and Milton Lipetz, published results from a [[longitudinal study]] on relationships suggesting an underlying truth to such an idea. The results suggest that parental interference in a loving relationship may intensify the feelings of [[Romance (love)|romantic love]] between members of the couple, at least for a brief span of time.<ref name="Driscoll">{{Cite journal|last1=Driscoll|first1=Richard|last2=Davis|first2=Keith E.|last3=Lipetz|first3=Milton E.|date=1972|title=Parental interference and romantic love: The Romeo and Juliet effect.|journal=Journal of Personality and Social Psychology|language=en|volume=24|issue=1|pages=1–10|doi=10.1037/h0033373|pmid=5079550|issn=1939-1315}}</ref> The study interviewed 140 couples, both married and unmarried, via [[Questionnaire|questionnaires]] and surveys. The researchers measured feelings about the spouse, about their perceived love, spousal trustworthiness, neediness, and parental interference. The couples completed these procedures at a first session and then, around six months to a year later, completed identical surveying sessions to see how their relationships have endured the past months. About 80% of the original participants completed the second session. Only a small portion of the original sample had ended their relationships or gotten [[Divorce|divorced]]. In the results of the overall study, there was found to be an increase in love ratings for one's partner and parental interference. Interference did seem to have other frustrating effects, as it also was associated with decreased trust, increased criticalness, and increased frequency of negative, bothersome behaviors.<ref name="Driscoll" />
```

### Full section (plain rendering)
== History ==
An early review of romantic love in the Western world emphasized the persistent association of obstacles or grave difficulties with the intensity of love, as in William Shakespeare's Romeo and Juliet. [ref: Derougemont, D. Love in the Western World. (Trans, by M. Belgion) New York: Harcourt, ] 

In 1972, Richard Driscoll, along with Keith Davis and Milton Lipetz, published results from a longitudinal study on relationships suggesting an underlying truth to such an idea. The results suggest that parental interference in a loving relationship may intensify the feelings of romantic love between members of the couple, at least for a brief span of time. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373] The study interviewed 140 couples, both married and unmarried, via questionnaires and surveys. The researchers measured feelings about the spouse, about their perceived love, spousal trustworthiness, neediness, and parental interference. The couples completed these procedures at a first session and then, around six months to a year later, completed identical surveying sessions to see how their relationships have endured the past months. About 80% of the original participants completed the second session. Only a small portion of the original sample had ended their relationships or gotten divorced. In the results of the overall study, there was found to be an increase in love ratings for one's partner and parental interference. Interference did seem to have other frustrating effects, as it also was associated with decreased trust, increased criticalness, and increased frequency of negative, bothersome behaviors. [FOCAL REF: Driscoll (1972) "Parental interference and romantic love: The Romeo and Juliet effect." doi:10.1037/h0033373]

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 18b1cb4274004eeec969/article_plain.txt in the evidence directory.)

- == Subsequent development ==
While Driscoll's study has not been replicated, other researchers have continued to discuss parental influence on relationship stability.

## ORIGINAL STUDY: doi:10.1037/h0033373 (FLoRA title: Parental interference and romantic love: The Romeo and Juliet effect.)
Crossref: Parental interference and romantic love: The Romeo and Juliet effect. | Richard Driscoll, Keith E. Davis, Milton E. Lipetz | Journal of Personality and Social Psychology | 1972 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2068587563", "type": "article", "publication_year": 1972, "cited_by_count": 203, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: METADATA_ONLY
Retrieved: 2026-10-06T16:10:41+00:00

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1027/1864-9335/a000181 (FLoRA title: Revisiting the Romeo and Juliet Effect (); FLoRA outcome code: failed [screening input only, not citable]; DOI detected on page: False)
Crossref: Revisiting the Romeo and Juliet Effect () | H. Colleen Sinclair, Kristina B. Hood, Brittany L. Wright | Social Psychology | 2014 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W1837390385", "type": "article", "publication_year": 2014, "cited_by_count": 49, "is_retracted": false, "oa_status": "hybrid", "oa_pdf": null, "oa_landing": "https://doi.org/10.1027/1864-9335/a000181"}
Evidence level available to you: ABSTRACT
Retrieved: 2026-10-06T16:10:42+00:00
### Abstract (Crossref deposited abstract)
We conducted a replication and extension of Driscoll, Davis, and Lipetz’s (1972) classic longitudinal survey of the Romeo and Juliet effect, wherein they found that increases in parental interference were linked to increases in love and commitment. Using the original measures, 396 participants were followed over a 3–4 month period wherein they reported love, commitment, trust, and criticism for their partners as well as levels of perceived interference from friends and family. Participants also completed contemporary, validated measures of the same constructs similar to those often implemented in studies of social network opinion. Repeating the analyses employed by Driscoll and colleagues, we could not find evidence for the Romeo and Juliet effect. Rather, consistent with the social network effect ( Felmlee, 2001 ), participants reporting higher levels of interference or lower levels of approval reported poorer relationship quality regardless of outcome measured. This effect was likewise evident in a meta-analysis.

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.3138/cjhs.243-a3 | Family matters, but sometimes chosen family matters more: Perceived social network influence in the dating decisions of same- and mixed-sex couples | 2015 | read: abstract | mentions replication: False
- doi:10.1186/s40359-016-0135-2 | Psychology, replication & beyond | 2016 | read: abstract | mentions replication: False
- doi:10.1177/0190272514565253 | Don’t Tell Me Who I Can’t Love | 2015 | read: abstract | mentions replication: False
- doi:10.1177/1754073916661764 | Transformative Events: Appraisal Bases of Passion and Mixed Emotions | 2017 | read: abstract | mentions replication: False
- doi:10.1007/s11031-017-9650-6 | Relationships at risk: How the perceived risk of ending a romantic relationship influences the intensity of romantic affect and relationship commitment | 2017 | read: metadata_only | mentions replication: False

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [cites original and replication 10.1027/1864-9335/a000181] doi:10.3138/cjhs.243-a3 | Family matters, but sometimes chosen family matters more: Perceived social network influence in the dating decisions of same- and mixed-sex couples | 2015 | article | cited_by 55
  Abstract: Although social support for relationships is a commonly studied topic, the literature is divided upon whether social support from parents versus friends plays a more important role in predicting relational and health outcomes. Using a sample (N=698) of heterosexual and lesbian, gay, bisexual, transgender and queer (LGBTQ) participants, the current study examined differences in past experiences of relationship disapproval from friends and family, as well as self-reported levels of importance assigned to various sources of social approval for relationships. In addition, participants read hypothetical scenarios in which they were told that their parents, heterosexual friends or LGBTQ friends disapproved of their current dating partner and suggested that they end the relationship. Participants responded by indicating whether or not they would end the hypothetical relationship based on the disapproval. Results indicate that individuals in same-sex relationships often perceive less social support for their relationships from parents than friends, that they place more value on relationship approval from friends, or chosen family, and that they are less likely to end a relationship based o
- [cites original and replication 10.1027/1864-9335/a000181] doi:10.1186/s40359-016-0135-2 | Psychology, replication & beyond | 2016 | article | cited_by 48
  Abstract: Modern psychology is apparently in crisis and the prevailing view is that this partly reflects an inability to replicate past findings. If a crisis does exists, then it is some kind of 'chronic' crisis, as psychologists have been censuring themselves over replicability for decades. While the debate in psychology is not new, the lack of progress across the decades is disappointing. Recently though, we have seen a veritable surfeit of debate alongside multiple orchestrated and well-publicised replication initiatives. The spotlight is being shone on certain areas and although not everyone agrees on how we should interpret the outcomes, the debate is happening and impassioned. The issue of reproducibility occupies a central place in our whig history of psychology.
- [cites original and replication 10.1027/1864-9335/a000181] doi:10.1177/0190272514565253 | Don’t Tell Me Who I Can’t Love | 2015 | article | cited_by 41
  Abstract: In three studies, we examined the influence of social network reactions on feelings toward a romantic partner. Study 1 was a large survey (N = 858), Study 2 was a vignette design in which social network reactions were manipulated, and Study 3 was a laboratory-based, dating game experiment. We found extensive support for the social network effect, whereby relationship approval from family and friends leads individuals to feel more love, more committed, and more positive about a partner. We also examined whether psychological reactance moderated social network influence. Analyses revealed two types of reactance: defiant reactance (doing the opposite of that urged by others) and independent reactance (a desire to make free and independent decisions). Independent reactance but not defiant reactance interacted with network effects and buffered the effects of social adversity. Independent individuals appear capable of ignoring disapproving network opinions. Findings demonstrate a noteworthy interaction between individuals and their social environment.
- [cites original and replication 10.1027/1864-9335/a000181] doi:10.1177/1754073916661764 | Transformative Events: Appraisal Bases of Passion and Mixed Emotions | 2017 | article | cited_by 20
  Abstract: Mixed emotions are conceptualized as involving the co-occurrence of states opposite in valence. One might expect that combinations of opposites would show diminished overall emotion intensity. But is this always the case? If not, when will mixed emotions be characterized by high intensity, and when by low intensity? In this article, theories of emotion-eliciting appraisal and emotion intensity are employed to understand mixed emotions and phenomena of passion. It is proposed that intense emotions are produced by transformative events: perceived motive-relevant changes that are important, large, and rapid. Transformative events that can move a person between greatly motive-inconsistent and greatly motive-consistent outcomes constitute one potent path to passion. Illustrative phenomena of passion, mixed emotions, and related research are discussed.
- [cites original and replication 10.1027/1864-9335/a000181] doi:10.1007/s11031-017-9650-6 | Relationships at risk: How the perceived risk of ending a romantic relationship influences the intensity of romantic affect and relationship commitment | 2017 | article | cited_by 17
  Abstract: (none)
