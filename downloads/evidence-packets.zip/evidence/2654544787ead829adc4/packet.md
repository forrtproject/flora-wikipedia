# Evidence packet 2654544787ead829adc4: Default effect

Frozen revision: 1358750759 (2026-06-10T18:27:57Z); https://en.wikipedia.org/w/index.php?oldid=1358750759
Live check: {"frozen_revid": "1358750759", "title": "Default effect", "live_revid": 1358750759, "live_timestamp": "2026-06-10T18:27:57Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "central_effect", "context_kind": "inline", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 2}

## Article lead (plain rendering, approximate)
The default effect, a concept within the study of nudge theory, explains the tendency for an agent to generally accept the default option in a strategic interaction. [ref: Altman (2017) "Aspects of Smart Decision-Making" doi:10.4337/9781782549598] The default option is the course of action that the agent, or chooser, will obtain if he or she does not specify a particular course of action. [ref: Herrmann (2011) "The effect of default options on choice—Evidence from online product c" doi:10.1016/j.jretconser.2011.06.005] The default effect has broad applications for firms attempting to "nudge" their customers in the direction of the firm's optimal outcome. Experiments and observational studies show that making an option a default increases the likelihood that such an option is chosen. [ref: "Do you need a nudge?"] There are two broad classes of defaults: mass defaults and personalised defaults. [ref: (2008) "Nudge Your Customers Toward Better Choices"] Setting or changing defaults has been proposed and applied by firms as an effective way of influencing behaviour—for example, with respect to setting air-conditioner temperature settings, giving consent to receive e-mail marketing, or automatic subscription renewals.

## Article outline
Default effect
  Endogenous default effects
  Exogenous default effects
Types of default options in behavioral economics
  Mass defaults
    Benign defaults
    Random defaults
    Hidden options
  Personalised defaults
    Smart defaults
    Persistent defaults
    Adaptive defaults
Explanations
  Cognitive effort
  Switching costs
  Loss aversion
  Recommendation
  Change of meaning
Default setting as a policy instrument
See also
References

## Categories
Decision theory; Planning; Free will; Nudge theory

## Occurrence 1: original DOI 10.1126/science.1091721 in section 'Endogenous default effects'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
=== Endogenous default effects ===
In a choice context, a default refers to that option which choosers end up with if they do not make an active choice. This notion is similar to the one in computer science where defaults are settings or values that are automatically assigned outside of user intervention. Setting the default affects how likely people end up with an option. This is called the default effect. More precisely, it refers to changes in the probability that an agent chooses a particular option when it is set as a default as opposed to the situation where this option has not been set as a default. For example, different countries have different rules on how to become an organ donor. In countries with the opt-in policy, all citizens are automatically considered as non-donors unless they actively register as donors. In countries with the opt-out policy, all citizens are automatically considered as donors unless they actively seek to be struck from the register. It has been argued that this difference in policy is the main cause of the significant difference in donor rates across the respective countries. [FOCAL REF: Johnson (2003) "MEDICINE: Do Defaults Save Lives?" doi:10.1126/science.1091721]

### Paragraph (raw wikitext)
```
=== Endogenous default effects ===
In a choice context, a default refers to that option which choosers end up with if they do not make an active choice. This notion is similar to the one in [[default (computer science)|computer science]] where defaults are settings or values that are automatically assigned outside of user intervention. Setting the default affects how likely people end up with an option. This is called the default effect. More precisely, it refers to changes in the probability that an agent chooses a particular option when it is set as a default as opposed to the situation where this option has not been set as a default. For example, different countries have different [[Organ Donation#Legislation|rules]] on how to become an organ donor. In countries with the opt-in policy, all citizens are automatically considered as non-donors unless they actively register as donors. In countries with the opt-out policy, all citizens are automatically considered as donors unless they actively seek to be struck from the register. It has been argued that this difference in policy is the main cause of the significant difference in donor rates across the respective countries.<ref name="organ">{{Cite journal | last1 = Johnson | first1 = E. J. | last2 = Goldstein | first2 = D. | title = MEDICINE: Do Defaults Save Lives? | doi = 10.1126/science.1091721 | journal = Science | volume = 302 | issue = 5649 | pages = 1338–1339 | year = 2003 | pmid =  14631022| s2cid = 166476782 }}</ref>
```

### Full section (plain rendering)
=== Endogenous default effects ===
In a choice context, a default refers to that option which choosers end up with if they do not make an active choice. This notion is similar to the one in computer science where defaults are settings or values that are automatically assigned outside of user intervention. Setting the default affects how likely people end up with an option. This is called the default effect. More precisely, it refers to changes in the probability that an agent chooses a particular option when it is set as a default as opposed to the situation where this option has not been set as a default. For example, different countries have different rules on how to become an organ donor. In countries with the opt-in policy, all citizens are automatically considered as non-donors unless they actively register as donors. In countries with the opt-out policy, all citizens are automatically considered as donors unless they actively seek to be struck from the register. It has been argued that this difference in policy is the main cause of the significant difference in donor rates across the respective countries. [FOCAL REF: Johnson (2003) "MEDICINE: Do Defaults Save Lives?" doi:10.1126/science.1091721]

## Occurrence 2: original (named-reference reuse) DOI 10.1126/science.1091721 in section 'Default setting as a policy instrument'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
== Default setting as a policy instrument ==
Setting or changing defaults has been proposed as an effective way of influencing behaviour—for example, with respect to deciding whether to become an organ donor, [FOCAL REF: Johnson (2003) "MEDICINE: Do Defaults Save Lives?" doi:10.1126/science.1091721] giving consent to receive e-mail marketing, [ref: Johnson (2002) "Defaults, Framing and Privacy: Why Opting In-Opting Out" doi:10.1023/A:1015044207315] choosing car insurance plans, [ref: Johnson (1993) "Framing, probability distortions, and insurance decisions" doi:10.1007/BF01065313] choosing which food to eat, [ref: Huh (2014) "Social Defaults: Observed Choices Become Choice Defaults" doi:10.1086/677315] selecting which car options to purchase, [ref: Park (2000) "Choosing What I Want Versus Rejecting What I Do Not Want: An Applicati" doi:10.1509/jmkr.37.2.187.18731] choosing between different energy providers, [ref: Pichert (2008) "Green defaults: Information presentation and pro-environmental behavio" doi:10.1016/j.jenvp.2007.09.004] or choosing the level of one's retirement contributions. [ref: Beshears (2009) "Social Security Policy in a Changing Environment" doi:10.7208/chicago/9780226076508.003.0006] Setting defaults are an important example of nudges or soft paternalist policies.

### Paragraph (raw wikitext)
```
== Default setting as a policy instrument ==
Setting or changing defaults has been proposed as an effective way of influencing behaviour—for example, with respect to deciding whether to become an organ donor,<ref name="organ"/> giving consent to receive e-mail marketing,<ref>{{Cite journal | last1 = Johnson | first1 = E. J. | last2 = Bellman | first2 = S. | last3 = Lohse | first3 = G. L. |title=Defaults, Framing and Privacy: Why Opting In-Opting Out| journal = Marketing Letters | volume = 13 | pages = 5–15 | year = 2002 | doi = 10.1023/A:1015044207315 | s2cid = 11296118 }}</ref> choosing car insurance plans,<ref>{{Cite journal | last1 = Johnson | first1 = E. J. | last2 = Hershey | first2 = J. | last3 = Meszaros | first3 = J. |author-link4=Howard Kunreuther| last4 = Kunreuther | first4 = H. | title = Framing, probability distortions, and insurance decisions | doi = 10.1007/BF01065313 | journal = Journal of Risk and Uncertainty | volume = 7 | pages = 35–51 | year = 1993 | s2cid = 154911666 }}</ref> choosing which food to eat,<ref name=":1" /> selecting which car options to purchase,<ref>{{Cite journal | last1 = Park | first1 = C. W. | last2 = Jun | first2 = S. Y. | last3 = MacInnis | first3 = D. J. | doi = 10.1509/jmkr.37.2.187.18731 | title = Choosing What I Want Versus Rejecting What I Do Not Want: An Application of Decision Framing to Product Option Choice Decisions | journal = Journal of Marketing Research | volume = 37 | issue = 2 | pages = 187 | year = 2000 | s2cid = 18705398 }}</ref> choosing between different energy providers,<ref>{{Cite journal | last1 = Pichert | first1 = D. | last2 = Katsikopoulos | first2 = K. V. | doi = 10.1016/j.jenvp.2007.09.004 | title = Green defaults: Information presentation and pro-environmental behaviour | journal = Journal of Environmental Psychology | volume = 28 | pages = 63–73 | year = 2008 }}</ref> or choosing the level of one's retirement contributions.<ref>{{Cite book | last1 = Beshears | first1 = J. | last2 = Choi | first2 = J. J. | last3 = Laibson | first3 = D. | last4 = Madrian | first4 = B. C. | s2cid = 168537180 | chapter = The Importance of Default Options for Retirement Saving Outcomes | doi = 10.7208/chicago/9780226076508.003.0006 | title = Social Security Policy in a Changing Environment | pages = 167 | year = 2009 | isbn = 978-0-226-07648-5 }}</ref> Setting defaults are an important example of [[nudge theory|nudges]] or [[soft paternalism|soft paternalist]] policies.
```

### Full section (plain rendering)
== Default setting as a policy instrument ==
Setting or changing defaults has been proposed as an effective way of influencing behaviour—for example, with respect to deciding whether to become an organ donor, [FOCAL REF: Johnson (2003) "MEDICINE: Do Defaults Save Lives?" doi:10.1126/science.1091721] giving consent to receive e-mail marketing, [ref: Johnson (2002) "Defaults, Framing and Privacy: Why Opting In-Opting Out" doi:10.1023/A:1015044207315] choosing car insurance plans, [ref: Johnson (1993) "Framing, probability distortions, and insurance decisions" doi:10.1007/BF01065313] choosing which food to eat, [ref: Huh (2014) "Social Defaults: Observed Choices Become Choice Defaults" doi:10.1086/677315] selecting which car options to purchase, [ref: Park (2000) "Choosing What I Want Versus Rejecting What I Do Not Want: An Applicati" doi:10.1509/jmkr.37.2.187.18731] choosing between different energy providers, [ref: Pichert (2008) "Green defaults: Information presentation and pro-environmental behavio" doi:10.1016/j.jenvp.2007.09.004] or choosing the level of one's retirement contributions. [ref: Beshears (2009) "Social Security Policy in a Changing Environment" doi:10.7208/chicago/9780226076508.003.0006] Setting defaults are an important example of nudges or soft paternalist policies.

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 2654544787ead829adc4/article_plain.txt in the evidence directory.)

- (none found by keyword scan)

## ORIGINAL STUDY: doi:10.1126/science.1091721 (FLoRA title: Do Defaults Save Lives?)
Crossref: Do Defaults Save Lives? | Eric J. Johnson, Daniel Goldstein | Science | 2003 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W1933689484", "type": "article", "publication_year": 2003, "cited_by_count": 44, "is_retracted": false, "oa_status": "green", "oa_pdf": null, "oa_landing": "https://papers.ssrn.com/sol3/Delivery.cfm/SSRN_ID1324774_code1144166.pdf?abstractid=1324774&mirid=1"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1126_science_1091721.txt (Free copy found by source search (published): https://www.dangoldstein.com/papers/DefaultsScience.pdf)
Retrieved: 2026-10-06T16:11:04+00:00
### Abstract (OpenAlex reconstructed abstract)
Default options can lead to striking differences in preferences, with significant economic impact. The authors of this Policy Forum use natural and experimental data to examine the impact of simple policy defaults on the decision to become an organ donor, finding large effects that significantly increase donation rates.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.15626/mp.2022.3108 (FLoRA title: Defaults versus framing: Revisiting Default Effect and Framing Effect with replications and extensions of Johnson and Goldstein (2003) and Johnson, Bellman, and Lohse (2002); FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: Defaults versus framing: Revisiting Default Effect and Framing Effect with replications and extensions of Johnson and Goldstein (2003) and Johnson, Bellman, and Lohse (2002) | Subramanya Prasad Chandrashekar, Nadia Adelina, Shiyuan Zeng, Yan Ying Esther Chiu, Grace Yat Sum Leung, Paul Henne et al. | Meta-Psychology | 2023 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W4383908678", "type": "article", "publication_year": 2023, "cited_by_count": 4, "is_retracted": false, "oa_status": "diamond", "oa_pdf": "https://open.lnu.se/index.php/metapsychology/article/download/3108/3438", "oa_landing": "https://doi.org/10.15626/mp.2022.3108"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext/10_15626_mp_2022_3108.txt (open-access PDF via OpenAlex best_oa_location (https://open.lnu.se/index.php/metapsychology/article/download/3108/3438))
Retrieved: 2026-10-06T16:11:06+00:00
### Abstract (Crossref deposited abstract)
People tend to stick with a default option instead of switching to another option. For instance, Johnson and Goldstein (2003) found a default effect in an organ donation scenario: if organ donation is the default option, people are more inclined to consent to it. Johnson et al. (2002) found a similar default effect in health-survey scenarios: if receiving more information about your health is the default, people are more inclined to consent to it. Much of the highly cited, impactful work on these default effects, however, has not been replicated in well-powered samples. In two well-powered samples (N = 1920), we conducted a close replication of the default effect in Johnson and Goldstein (2003) and in Johnson, Bellman, and Lohse (2002). We successfully replicated Johnson and Goldstein (2003). In an extension of the original findings, we also show that default effects are unaffected by the permanence of these selections. We, however, failed to replicate the findings of Johnson, Bellman, and Lohse’s (2002) study; we did not find evidence for a default effect. We did, however, find a framing effect: participants who read a positively-framed scenario consented to receive health-related information at a higher rate than participants who read a negatively framed scenario. We also conducted a conceptual replication of Johnson et al. (2002) that was based on an organ-donation scenario, but this attempt failed to find a default effect. Our results suggest that default effects depend on framing and context. Materials, data, and code are available on: https://osf.io/8wd2b/.

## Other database studies cited on this same page (each has its own packet; drafted together)
- 40fd0f609decd698e343: Defaults, Framing and Privacy: Why Opting In-Opting Out1 (doi:10.1023/a:1015044207315)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1017/bpp.2018.43 | When and why defaults influence decisions: a meta-analysis of default effects | 2019 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_1017_bpp_2018_43.txt

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1017/bpp.2018.43 | When and why defaults influence decisions: a meta-analysis of default effects | 2019 | review | cited_by 491
  Abstract: Abstract When people make decisions with a pre-selected choice option – a ‘default’ – they are more likely to select that option. Because defaults are easy to implement, they constitute one of the most widely employed tools in the choice architecture toolbox. However, to decide when defaults should be used instead of other choice architecture tools, policy-makers must know how effective defaults are and when and why their effectiveness varies. To answer these questions, we conduct a literature search and meta-analysis of the 58 default studies (pooled n = 73,675) that fit our criteria. While our analysis reveals a considerable influence of defaults ( d = 0.68, 95% confidence interval = 0.53–0.83), we also discover substantial variation: the majority of default studies find positive effects, but several do not find a significant effect, and two even demonstrate negative effects. To explain this variability, we draw on existing theoretical frameworks to examine the drivers of disparity in effectiveness. Our analysis reveals two factors that partially account for the variability in defaults’ effectiveness. First, we find that defaults in consumer domains are more effective and in envi
