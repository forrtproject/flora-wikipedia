# Evidence packet e7eabdec11d5a08b42d5: Timeline of psychology

Frozen revision: 1377752059 (2026-09-30T23:58:01Z); https://en.wikipedia.org/w/index.php?oldid=1377752059
Live check: {"frozen_revid": "1377752059", "title": "Timeline of psychology", "live_revid": 1377752059, "live_timestamp": "2026-09-30T23:58:01Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "history_list", "context_kind": "inline", "living_person_category": false, "health_term_flag": true, "co_cited": false, "large_project": true, "flora_originals_on_page": 1}

## Article lead (plain rendering, approximate)
This article is a general timeline of psychology.

## Article outline
Ancient history – BCE
1st–5th century CE
6th–10th century
11th–15th century
16th century
17th century
18th century
19th century
  1800s
  1810s
  1820s
  1840s
  1850s
  1860s
  1870s
  1880s
  1890s
20th century
  1900s
  1910s
  1920s
  1930s
  1940s
  1950s
  1960s
  1970s
  1980s
  1990s
21st century
  2000s
  2010s
  2020s
See also
References
External links

## Categories
History of psychology; Psychology lists; Social science timelines; Cognitive science lists

## Occurrence 1: original DOI 10.1037/h0054651 in section '1930s'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
===1930s===
* 1930 – Edwin Boring discussed the Boring figure.
* 1931 – Gordon Allport et al. published the Allport-Vernon-Lindzey Study of Values, which defines six major value types.
* 1932 – Journal of Personality founded as first personality psychology research periodical originally titled Character and Personality.
*1933 – Pyotr Gannushkin published Manifestations of Psychopathies. [ref: Ганнушкин П. Б. (2000). Клиника психопатий, их статика, динамика, систематика. Издател]
* 1933 – Clark L. Hull published Hypnosis and Suggestibility, proving that hypnosis is not sleep and founding the modern study of hypnosis.
* 1933 – Wilhelm Reich published Character Analysis and The Mass Psychology of Fascism.
* 1934 – Lev Vygotsky published Thought and Language (Thinking and Speech).
* 1934 – Ruth Winifred Howard became the first African American woman to earn a PhD in psychology. [ref: Moore (1999) "Notable Black American Scientistis"]
* 1935 – John Ridley Stroop developed a color-word task to demonstrate the interference of attention, the Stroop effect [FOCAL REF: Stroop (1935) "Studies of interference in serial verbal reaction" doi:10.1037/h0054651]
* 1935 – Helen Flanders Dunbar published Emotions and Bodily Changes: A Survey of Literature on Psychosomatic Interrelationships; [ref: "Emotions and Disease: Psychosomatic Medicine: 'The Puzzling Leap'"] in 1942 she founded the American Psychosomatic Society (American Society for Research in Psychosomatic Problems), [ref: "American Psychosomatic Society"] and was the first editor of the society's journal Psychosomatic Medicine: Experimental and Clinical Studies, founded in 1939. [ref: "Psychosomatic Medicine"]
* 1935 – Henry Murray and Christiana Morgan of Harvard University published the Thematic Apperception Test (TAT).
* 1935 – Theodore Newcomb began the Bennington College Study, [ref: "Newcomb"] which ended in 1939, documenting liberalization of women students' political beliefs, along with the effects of proximity on acquaintance and attraction.
* 1936 – Kurt Lewin published Principles of Topological Psychology, [ref: "Principles of Topological Psychology: Kurt Lewin: Free Download & Stre"] containing Lewin's Equation B = f (P, E), meaning that behavior is a function of a person in their environment.
* 1936 – Wilhelm Reich published The Sexual Revolution.
* 1936 – Kenneth Spence published an analysis of discrimination learning in terms of gradients of excitation and inhibition, showing that mathematical deductions from a quantitative theory could generate interesting and empirically testable predictions.
* 1936 – The Psychometric Society was founded by Louis Leon Thurstone, who proposed dividing general intelligence into seven primary mental abilities (PMAs).
* 1938 – B.F. Skinner published his first major work The Behavior of Organisms: An Experimental Analysis, introducing behavior analysis.
* 1939 – Alan Hodgkin and Andrew Huxley published a classic report in the journal Nature of the first recording of an action potential.
* 1939 – Neal E. Miller et al. published the frustration-aggression theory, which claims that aggression is the result of frustration of efforts to attain a goal.
* 1939 – David Wechsler developed the Wechsler-Bellevue Intelligence Scale.
* 1939 – On 1 September World War II began with the German invasion of Poland; on 20 September Adolf Hitler signed the Euthanasia Decree, [ref: "Hitler's Euthanasia Decree"] written by psychologist Max de Crinis, resulting in the Aktion T4 euthanasia program; on 23 September Sigmund Freud committed physician-assisted suicide in London on the Jewish Day of Atonement; on 31 October his archrival Otto Rank died of a kidney infection in New York City after uttering the word "comical"; Wilhelm Reich fled to New York, coining the word orgone and building "orgone accumulators", which got him in trouble with the psychiatric establishment and the federal government.

### Paragraph (raw wikitext)
```
===1930s===
* 1930 – [[Edwin Boring]] discussed the Boring figure.
* 1931 – [[Gordon Allport]] et al. published the [[Values Scales|Allport-Vernon-Lindzey Study of Values]], which defines six major value types.
* 1932 – [[Journal of Personality]] founded as first personality psychology research periodical originally titled Character and Personality.
*1933 – [[Pyotr Gannushkin]] published ''[[Pyotr Gannushkin#The theory of psychopathies|Manifestations of Psychopathies]]''.<ref name="Gannushkin">Ганнушкин П. Б. (2000). ''Клиника психопатий, их статика, динамика, систематика''. Издательство Нижегородской государственной медицинской академии. {{ISBN|5-86093-015-1}}.</ref>
* 1933 – [[Clark L. Hull]] published ''Hypnosis and Suggestibility'', proving that hypnosis is not sleep and founding the modern study of hypnosis.
* 1933 – [[Wilhelm Reich]] published ''[[Character Analysis]]'' and ''[[The Mass Psychology of Fascism]]''.
* 1934 – [[Lev Vygotsky]] published ''[[Lev Vygotsky#Thinking and Speech|Thought and Language]]'' (''Thinking and Speech'').
* 1934 – [[Ruth Winifred Howard]] became the first African American woman to earn a PhD in psychology.<ref name=Moore>{{cite book|last=Moore|first=Patrick|title=Notable Black American Scientistis|date=1999|publisher=Galel Research|location=Farmington Hills, Michigan|isbn=978-0-7876-2789-8|pages=[https://archive.org/details/notableblackamer0000unse/page/22 22–23]|url=https://archive.org/details/notableblackamer0000unse/page/22}}</ref>
* 1935 – [[John Ridley Stroop]] developed a color-word task to demonstrate the interference of attention, the [[Stroop effect]]<ref>{{cite journal | last1 = Stroop | first1 = J.R. | year = 1935 | title = Studies of interference in serial verbal reaction | journal = Journal of Experimental Psychology | volume = 18 | issue = 6| pages = 643–662 | doi=10.1037/h0054651| hdl = 11858/00-001M-0000-002C-5ADB-7 | hdl-access = free }}</ref>
* 1935 – [[Helen Flanders Dunbar]] published ''[[Emotions and Bodily Changes: A Survey of Literature on Psychosomatic Interrelationships]]'';<ref>{{cite web|url=https://www.nlm.nih.gov/exhibition/emotions/psychosomatic.html|title=Emotions and Disease: Psychosomatic Medicine: 'The Puzzling Leap'|access-date=15 March 2015|archive-date=13 February 2015|archive-url=https://web.archive.org/web/20150213062133/http://www.nlm.nih.gov/exhibition/emotions/psychosomatic.html|url-status=live}}</ref> in 1942 she founded the [[American Psychosomatic Society]] (American Society for Research in Psychosomatic Problems),<ref>{{Cite web |url=http://www.psychosomatic.org/about/index.cfm |title=American Psychosomatic Society<!-- Bot generated title --> |access-date=9 April 2013 |archive-date=21 March 2013 |archive-url=https://web.archive.org/web/20130321220946/http://www.psychosomatic.org/about/index.cfm |url-status=live }}</ref> and was the first editor of the society's journal ''[[Psychosomatic Medicine (journal)|Psychosomatic Medicine: Experimental and Clinical Studies]]'', founded in 1939.<ref>{{cite web|url=http://www.psychosomaticmedicine.org/|title=Psychosomatic Medicine|access-date=15 March 2015|archive-date=14 February 2014|archive-url=https://web.archive.org/web/20140214043220/http://www.psychosomaticmedicine.org/|url-status=live}}</ref>
* 1935 – [[Henry Murray]] and [[Christiana Morgan]] of Harvard University published the [[Thematic Apperception Test]] (TAT).
* 1935 – [[Theodore Newcomb]] began the Bennington College Study,<ref name="lewisu">{{cite web|url=http://www2.lewisu.edu/~gazianjo/newcomb.htm|title=Newcomb|publisher=www2.lewisu.edu|access-date=17 October 2014|archive-date=4 March 2016|archive-url=https://web.archive.org/web/20160304034852/http://www2.lewisu.edu/~gazianjo/newcomb.htm|url-status=live}}</ref> which ended in 1939, documenting liberalization of women students' political beliefs, along with the effects of proximity on acquaintance and attraction.
* 1936 – [[Kurt Lewin]] published ''[[Principles of Topological Psychology]]'',<ref name="archive">{{cite web|url=https://archive.org/details/principlesoftopo011804mbp|title=Principles of Topological Psychology: Kurt Lewin: Free Download & Streaming: Internet Archive|access-date=17 October 2014}}</ref> containing Lewin's Equation B = f (P, E), meaning that behavior is a function of a person in their environment.
* 1936 – [[Wilhelm Reich]] published ''[[The Sexual Revolution]]''.
* 1936 – [[Kenneth Spence]] published an analysis of discrimination learning in terms of gradients of excitation and inhibition, showing that mathematical deductions from a quantitative theory could generate interesting and empirically testable predictions.
* 1936 – The [[Psychometric Society]] was founded by [[Louis Leon Thurstone]], who proposed dividing general intelligence into seven primary mental abilities (PMAs).
* 1938 – [[B.F. Skinner]] published his first major work ''[[The Behavior of Organisms|The Behavior of Organisms: An Experimental Analysis]]'', introducing [[behavior analysis]].
* 1939 – [[Alan Hodgkin]] and [[Andrew Huxley]] published a classic report in the journal ''[[Nature (journal)|Nature]]'' of the first recording of an [[action potential]].
* 1939 – [[Neal E. Miller]] et al. published the [[frustration-aggression theory]], which claims that aggression is the result of frustration of efforts to attain a goal.
* 1939 – [[David Wechsler]] developed the [[Wechsler Intelligence Scale|Wechsler-Bellevue Intelligence Scale]].
* 1939 – On 1 September World War II began with the German invasion of Poland; on 20 September [[Adolf Hitler]] signed the [[Euthanasia Decree]],<ref>{{cite web|url=http://www.euthanasia.com/hitlerletter.html|title=Hitler's Euthanasia Decree|access-date=15 March 2015|archive-date=24 September 2015|archive-url=https://web.archive.org/web/20150924004050/http://www.euthanasia.com/hitlerletter.html|url-status=live}}</ref> written by psychologist [[Max de Crinis]], resulting in the [[Aktion T4]] euthanasia program; on 23 September [[Si
```

### Full section (plain rendering)
===1930s===
* 1930 – Edwin Boring discussed the Boring figure.
* 1931 – Gordon Allport et al. published the Allport-Vernon-Lindzey Study of Values, which defines six major value types.
* 1932 – Journal of Personality founded as first personality psychology research periodical originally titled Character and Personality.
*1933 – Pyotr Gannushkin published Manifestations of Psychopathies. [ref: Ганнушкин П. Б. (2000). Клиника психопатий, их статика, динамика, систематика. Издател]
* 1933 – Clark L. Hull published Hypnosis and Suggestibility, proving that hypnosis is not sleep and founding the modern study of hypnosis.
* 1933 – Wilhelm Reich published Character Analysis and The Mass Psychology of Fascism.
* 1934 – Lev Vygotsky published Thought and Language (Thinking and Speech).
* 1934 – Ruth Winifred Howard became the first African American woman to earn a PhD in psychology. [ref: Moore (1999) "Notable Black American Scientistis"]
* 1935 – John Ridley Stroop developed a color-word task to demonstrate the interference of attention, the Stroop effect [FOCAL REF: Stroop (1935) "Studies of interference in serial verbal reaction" doi:10.1037/h0054651]
* 1935 – Helen Flanders Dunbar published Emotions and Bodily Changes: A Survey of Literature on Psychosomatic Interrelationships; [ref: "Emotions and Disease: Psychosomatic Medicine: 'The Puzzling Leap'"] in 1942 she founded the American Psychosomatic Society (American Society for Research in Psychosomatic Problems), [ref: "American Psychosomatic Society"] and was the first editor of the society's journal Psychosomatic Medicine: Experimental and Clinical Studies, founded in 1939. [ref: "Psychosomatic Medicine"]
* 1935 – Henry Murray and Christiana Morgan of Harvard University published the Thematic Apperception Test (TAT).
* 1935 – Theodore Newcomb began the Bennington College Study, [ref: "Newcomb"] which ended in 1939, documenting liberalization of women students' political beliefs, along with the effects of proximity on acquaintance and attraction.
* 1936 – Kurt Lewin published Principles of Topological Psychology, [ref: "Principles of Topological Psychology: Kurt Lewin: Free Download & Stre"] containing Lewin's Equation B = f (P, E), meaning that behavior is a function of a person in their environment.
* 1936 – Wilhelm Reich published The Sexual Revolution.
* 1936 – Kenneth Spence published an analysis of discrimination learning in terms of gradients of excitation and inhibition, showing that mathematical deductions from a quantitative theory could generate interesting and empirically testable predictions.
* 1936 – The Psychometric Society was founded by Louis Leon Thurstone, who proposed dividing general intelligence into seven primary mental abilities (PMAs).
* 1938 – B.F. Skinner published his first major work The Behavior of Organisms: An Experimental Analysis, introducing behavior analysis.
* 1939 – Alan Hodgkin and Andrew Huxley published a classic report in the journal Nature of the first recording of an action potential.
* 1939 – Neal E. Miller et al. published the frustration-aggression theory, which claims that aggression is the result of frustration of efforts to attain a goal.
* 1939 – David Wechsler developed the Wechsler-Bellevue Intelligence Scale.
* 1939 – On 1 September World War II began with the German invasion of Poland; on 20 September Adolf Hitler signed the Euthanasia Decree, [ref: "Hitler's Euthanasia Decree"] written by psychologist Max de Crinis, resulting in the Aktion T4 euthanasia program; on 23 September Sigmund Freud committed physician-assisted suicide in London on the Jewish Day of Atonement; on 31 October his archrival Otto Rank died of a kidney infection in New York City after uttering the word "comical"; Wilhelm Reich fled to New York, coining the word orgone and building "orgone accumulators", which got him in trouble with the psychiatric establishment and the federal government.

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: e7eabdec11d5a08b42d5/article_plain.txt in the evidence directory.)

- * c. 1600–1625 – Francis Bacon was an English philosopher, statesman, scientist, lawyer, jurist, author, and pioneer of the scientific method. His writings on psychological topics included the nature of knowledge and memory. 
* 1650 – René Descartes died, leaving Treatise of the World, containing his dualistic theory of reality, mind vs. matter.
* 1672 – Thomas Willis published the anatomical treatise De Anima Brutorum, describing psychology in terms of brain function.
* 1677 – Baruch Spinoza died, leaving Ethics, Demonstrated in Geometrical Order, Pt. 2 focusing on the human mind and body, disputing Descartes and arguing that they are one, and Pt. 3 attempting to show that moral concepts such as good and evil, virtue, and perfection have a basis in human psychology.
*1689 – John Locke published An Essay Concerning Human Understanding, which claims that the human mind is a Tabula Rasa at birth.
- ===1970s===
* 1970 – At an APA Town Hall Meeting, with the support of the Association for Women in Psychology, Phyllis Chesler and Nancy Henley prepared a statement on APA's obligations to women and demanded one million dollars in reparation for the damage psychology had perpetrated against women's minds and bodies. [ref: "Timeline"]
* 1970 – APA Division 29 gives its first Distinguished Professional Award in Psychology and Psychotherapy to Eugene Gendlin.
* 1970 – "Critical psychology" became a psychological theoretical field. Klaus Holzkamp, who worked as a professor at the Free University of Berlin, took a central role in defining critical psychology based on the works of Karl Marx and Aleksei N. Leontiev.
* 1970 – Masters and Johnson published Human Sexual Inadequacy.
* 1971 – The Stanford prison experiment, conducted by Philip Zimbardo et al. at Stanford University, studied the human response to captivity; the experiment quickly got out of hand and was ended early.
* 1971 – Martin Shubik performed the dollar auction, illustrating irrational choices.
* 1971 – In Nov. John O'Keefe and Jonathan O. Dostrovsky announced their discovery of place cells in the hippocampus.
* 1971 – The Leibniz Institute for Psychology Information at the University of Trier was founded to publish the PSYNDEX database of references to psychology in the German-speaking world.
* 1972 – The Dunedin Multidisciplinary Health and Development Study commenced, a longitudinal study began, with 96% retentio
- === 2010s ===
* 2010s – As research on the topic accumulates and its usage increases, scientists investigate neuroenhancement – such as nootropics [ref: Schifano (2022) "Benefits and Harms of 'Smart Drugs' (Nootropics) in Healthy Individual" doi:10.1007/s40265-022-01701-7] – regarding psychological mechanisms underlying cognitive functions, neuroethics, effects on moral decision-making, [ref: Ngo (2019) "Moral decision making under modafinil: a randomized placebo-controlled" doi:10.1007/s00213-019-05250-y] public perception, their potential for the treatment of mental diseases, and the potential or ongoing use by professionals or self-administering civilians. [ref: Dresler (2019) "Hacking the Brain: Dimensions of Cognitive Enhancement" doi:10.1021/acschemneuro.8b00571] [ref: Tennison (2012) "Neuroscience, Ethics, and National Security: The State of the Art" doi:10.1371/journal.pbio.1001289] [ref: Lucius (2015) "Pills or Push-Ups? Effectiveness and Public Perception of Pharmacologi" doi:10.3389/fpsyg.2015.01852] [ref: Brunye (2022) "Neuroenhancement in Military Personnel: Conceptual and Methodological "] [ref: Stephan (2018) "How Realistic Are the Scientific Assumptions of the Neuroenhancement D" doi:10.3389/fphar.2018.00003] [ref: J. (2014) "Attitudes toward pharmacological cognitive enhancement—a review" doi:10.3389/fnsys.2014.00053]
* 2010s – With the rise of smartphone gaming and a continued large and nearly entirely commercially-driven gaming industry and Big Tech, mobile
- ;2021
* July – A study reports that adolescent loneliness in contemporary schools and depression increased substantially and consistently worldwide after 2012. [ref: "Teens around the world are lonelier than a decade ago. The reason may "] [ref: Twenge (2021) "Worldwide increases in adolescent loneliness" doi:10.1016/j.adolescence.2021.06.006]
* September – Psychologist and behavior geneticist Kathryn Paige Harden publishes The Genetic Lottery: Why DNA Matters for Social Equality, an argument for using genetics to create a just society – including in terms of psychology-related predispositions, [ref: Cite Q | Q105923407] similar to a bioethical argument made by Papaioannou in 2013. [ref: Papaioannou (2013) "New life sciences innovation and distributive justice: rawlsian goods " doi:10.1186/2195-7819-9-5]
* October – The American Psychological Association releases guidelines for the optimal use of social media in professional psychological practice. [ref: APA Committee on Professional Practice and Standards "APA Guidelines for the Optimal Use of Social Media in Professional Psy"]
* December – In applied behavioural science, "megastudies" as meta-analyses are proposed and demonstrated for investigating the efficacy of many different interventions designed in an interdisciplinary manner by separate teams, e.g. to inform policy.[(2021) "Megastudies improve the impact of applied behavioural science" doi:10.1038/s41586-021-04128-4]
;2022
* July – A deep learning system that learns 

## ORIGINAL STUDY: doi:10.1037/h0054651 (FLoRA title: Studies of interference in serial verbal reactions.)
Crossref: Studies of interference in serial verbal reactions. | J. R. Stroop | Journal of Experimental Psychology | 1935 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2120357670", "type": "article", "publication_year": 1935, "cited_by_count": 18691, "is_retracted": false, "oa_status": "green", "oa_pdf": null, "oa_landing": "http://hdl.handle.net/11858/00-001M-0000-002C-5ADB-7"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1037_h0054651.txt (Free copy found by source search (published): https://pure.mpg.de/rest/items/item_2389918/component/file_2389917/content)
Retrieved: 2026-10-06T16:17:10+00:00

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1016/j.jesp.2015.10.012 (FLoRA title: Many Labs 3: Evaluating participant pool quality across the academic semester via replication; FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: Many Labs 3: Evaluating participant pool quality across the academic semester via replication | Charles R. Ebersole, Olivia E. Atherton, Aimee L. Belanger, Hayley M. Skulborstad, Jill M. Allen, Jonathan B. Banks et al. | Journal of Experimental Social Psychology | 2016 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2520456228", "type": "article", "publication_year": 2016, "cited_by_count": 499, "is_retracted": false, "oa_status": "green", "oa_pdf": null, "oa_landing": "https://escholarship.org/uc/item/2wv9p3b8"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1016_j_jesp_2015_10_012.txt (Free copy found by source search (preprint): https://osf.io/q4emc/download)
Retrieved: 2026-10-06T16:17:11+00:00

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1007/s40806-019-00192-2 | How Diverse Are the Samples Used in the Journals ‘Evolution & Human Behavior’ and ‘Evolutionary Psychology’? | 2019 | read: abstract | mentions replication: False
- doi:10.1037/met0000438 | Deciding what to replicate: A decision model for replication study selection under resource and knowledge constraints. | 2021 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_1037_met0000438.txt
  Snippet: o consider bate about the nature and importance of replication - espewhether the arguments that follow here would make sense cially within the field of psychology (cesario, 2014; earp under other definitions of replication as well. & trafimow, 2015; ebersole et al., 2016; finkel, eastwick, previously, many scientific literatures have favored concep- & reis, 2017; maxwell, lau, & howard, 2015; pashler & tual replication; extending an already-tested claim by testing wagenmakers, 2012; stroebe & strack, 20
  Snippet: j., . . . yurovsky, cial psychology. frontiers in psychology, 6, 621. d. (2017). a collaborative approach to infant https://doi.org/10.3389/fpsyg.2015.00621 research: promoting reproducibility, best practices, and theory-building. infancy, 22(4), 421ebersole, c. r., atherton, o. e., belanger, a. l., 435. https://doi.org/10.1111/infa.12182 skulborstad, h. m., allen, j. m., banks, j. b., . . . nosek, b. a. (2016). many labs 3: eval- garfield, e. (2006). the history and meaning of uating participant pool q
- doi:10.1371/journal.pone.0214998 | Characterizing emotional Stroop interference in posttraumatic stress disorder, major depression and anxiety disorders: A systematic review and meta-analysis | 2019 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_1371_journal_pone_0214998.txt
  Snippet: 97. riley rd, thompson jr, abrams kr. an alternative model for bivariate random-effects meta-analysis when the within-study correlations are unknown. biostatistics. 2008; 9(1):172-86. https://doi.org/10. 1093/biostatistics/kxm023 pmid: 17626226 98. ebersole cr, olivia e. atherton oe, belanger al, skulborstad hm, allend jm et al. labs 3: evaluating participant pool quality across the academic semester via replication. j exp soc psychol. 2016; 67:68-82. 99. ataya af, adams s, mullings e, cooper rm, attwo
- doi:10.1037/bul0000164 | Low and variable correlation between reaction time costs and accuracy costs explained by accumulation models: Meta-analysis and simulations. | 2018 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_1037_bul0000164.txt
  Snippet: 128 .02 .04 task switching (fill/frame) 216 128/128 .07 .05 task mixing (animacy/size) 216 512/128 .15 .20 task mixing (shape/colour) 216 512/128 .08 .15 task mixing (parity/magnitude) 216 512/128 .19 .18 task mixing (fill/frame) 216 512/128 .05 .21 ebersole et al. (2016) stroop 3,305 21/42 .15 .12 elchlepp, best, lavric, and monsell task switching 21 878/438‡ .11 .08 (2017) ferrand et al. (2010) lexical decision task (french) 868 1,000/1,000 .55 .55 gonthier, braver, and bugg (2016) stroop (picture/wor
  Snippet: p between method of accounting for publication bias in meta-analysis. journal of self-report and lab task conceptualizations of impulsivity. journal of the american statistical association, 95, 89 -98. individual differences and decision models 1223 ebersole, c. r., atherton, o. e., belanger, a. l., skulborstad, h. m., trum disorders: two meta-analyses. autism research, 7, 407- 420. allen, j. m., banks, j. b., . . . nosek, b. a. (2016). many labs 3: http://dx.doi.org/10.1002/aur.1369 evaluating particip
- doi:10.1016/j.bpsc.2020.05.004 | Task Reliability Considerations in Computational Psychiatry | 2020 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_1016_j_bpsc_2020_05_004.txt
  Snippet: lation between reaction time costs and accuracy costs explained by accumulation models: meta-analysis and simulations. psychol bull 144: 1200-1227. 4. stroop jr (1935): studies of interference in serial verbal reactions. j exp psychol 18: 643662. 5. ebersole cr, atherton oe, belanger al, skulborstad hm, allen jm, banks jb, et al. (2016): many labs 3: evaluating participant pool quality across the academic semester via replication. j exp soc psychol 67: 68-82. 6. nunnally jc (1978): psychometric theory,

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1146/annurev.neuro.24.1.167 | An Integrative Theory of Prefrontal Cortex Function | 2001 | review | cited_by 13143
  Abstract: The prefrontal cortex has long been suspected to play an important role in cognitive control, in the ability to orchestrate thought and action in accordance with internal goals. Its neural basis, however, has remained a mystery. Here, we propose that cognitive control stems from the active maintenance of patterns of activity in the prefrontal cortex that represent goals and the means to achieve them. They provide bias signals to other brain structures whose net effect is to guide the flow of activity along neural pathways that establish the proper mappings between inputs, internal states, and outputs needed to perform a given task. We review neurophysiological, neurobiological, neuroimaging, and computational studies that support this theory and discuss its implications as well as further issues to be addressed
- [review citing original] doi:10.1038/nrn3119 | Dysfunction of the prefrontal cortex in addiction: neuroimaging findings and clinical implications | 2011 | review | cited_by 2816
  Abstract: (none)
- [review citing original] doi:10.1038/nrn2994 | The integration of negative affect, pain and cognitive control in the cingulate cortex | 2011 | review | cited_by 2159
  Abstract: (none)
- [review citing original] doi:10.1016/j.tics.2004.12.004 | Distracted and confused?: Selective attention under load | 2005 | review | cited_by 2138
  Abstract: (none)
- [review citing original] doi:10.1016/j.tics.2012.01.006 | Executive functions and self-regulation | 2012 | review | cited_by 1988
  Abstract: (none)
- [cites original and replication 10.1016/j.jesp.2015.10.012] doi:10.1007/s40806-019-00192-2 | How Diverse Are the Samples Used in the Journals ‘Evolution & Human Behavior’ and ‘Evolutionary Psychology’? | 2019 | article | cited_by 97
  Abstract: Psychologists regularly draw inferences about populations based on data from small samples of people, and so have long been interested in how well those samples generalise to wider populations. There is a consensus that psychology probably relies too much on samples from Western, Educated, Industrialised, Rich and Democratic (WEIRD) societies and among those from university students. Online surveys might be used to increase sample diversity, although online sampling still reaches only a restricted range of participants. Studies from evolutionary psychology often seek to uncover aspects of evolved universal characteristics, and so might demonstrate a particular interest in the use of diverse samples. Here, we empirically examine the samples used in the 2015–2016 volumes of ‘Evolution & Human Behavior’ (104 articles) and ‘Evolutionary Psychology’ (76 articles). Our database consists of 311 samples of humans (median sample size = 186). The majority of samples were either online or student samples (70% of samples), followed by other adult Western samples (19%). Two hundred fifty-three (81%) of the samples were classified as ‘Western’ (Europe/North America/Australia). The remaining samp
- [cites original and replication 10.1016/j.jesp.2015.10.012] doi:10.1037/met0000438 | Deciding what to replicate: A decision model for replication study selection under resource and knowledge constraints. | 2021 | article | cited_by 77
  Abstract: . Our goal in this article is not to define concrete guidelines for study selection, but to provide the necessary theoretical foundations on which such concrete guidelines could be built. (PsycInfo Database Record (c) 2023 APA, all rights reserved).
- [cites original and replication 10.1016/j.jesp.2015.10.012] doi:10.1371/journal.pone.0214998 | Characterizing emotional Stroop interference in posttraumatic stress disorder, major depression and anxiety disorders: A systematic review and meta-analysis | 2019 | review | cited_by 72
  Abstract: BACKGROUND: Posttraumatic stress disorder is a debilitating psychiatric disorder characterized by symptoms of intrusive re-experiencing of trauma, avoidance and hyper-arousal. Diagnosis and treatment of PTSD is further complicated by concurrently occurring disorders, the most frequent being major depressive disorder and anxiety disorders. Previous research highlights that attentional processing in posttraumatic stress disorder is associated with substantial interference by emotional stimuli, a phenomenon also observed in these concurrently occurring psychiatric disorders. However, the diagnosis-relevance of this interference remains elusive. Here, we investigated the emotional Stroop interference for diagnosis-related stimuli, generally negative stimuli, and generally positive stimuli in posttraumatic stress disorder, major depressive disorder and anxiety disorders. METHODS: We performed a systematic database search in PubMed (Medline), Cochrane Library and PsycINFO on emotional Stroop performance in individuals with a diagnosis of posttraumatic stress disorder, major depressive disorder or anxiety disorders separately. Mean effect sizes, standard errors and confidence intervals we
- [cites original and replication 10.1016/j.jesp.2015.10.012] doi:10.1037/bul0000164 | Low and variable correlation between reaction time costs and accuracy costs explained by accumulation models: Meta-analysis and simulations. | 2018 | article | cited_by 66
  Abstract: = .17, range -.45 to .78). This general problem is accounted for by the theoretical framework of evidence accumulation models, which capture individual differences in (at least) 2 distinct ways. Differences affecting accumulation rate produce positive correlation. But this is cancelled out if individuals also differ in response threshold, which produces negative correlations. In the models, subtractions between conditions do not isolate processing costs from caution. To demonstrate the explanatory power of synthesizing the traditional subtraction method within a broader decision model framework, we confirm 2 predictions with new data. Thus, using error costs or RT costs is more than a pragmatic choice; the decision carries theoretical consequence that can be understood through the accumulation model framework. (PsycINFO Database Record (c) 2018 APA, all rights reserved).
- [cites original and replication 10.1016/j.jesp.2015.10.012] doi:10.1016/j.bpsc.2020.05.004 | Task Reliability Considerations in Computational Psychiatry | 2020 | article | cited_by 41
  Abstract: (none)
