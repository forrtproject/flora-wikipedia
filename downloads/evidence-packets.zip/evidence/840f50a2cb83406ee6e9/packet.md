# Evidence packet 840f50a2cb83406ee6e9: Lara Aknin

Frozen revision: 1357442492 (2026-06-02T17:52:49Z); https://en.wikipedia.org/w/index.php?oldid=1357442492
Live check: {"frozen_revid": "1357442492", "title": "Lara Aknin", "live_revid": 1357442492, "live_timestamp": "2026-06-02T17:52:49Z", "checked_at": "2026-10-06T16:46:56+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "biography", "context_kind": "list", "living_person_category": true, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 1}

## Article lead (plain rendering, approximate)
Lara Beth Aknin is a Canadian professor of social psychology at Simon Fraser University, and associate editor of the World Happiness Report. [ref: (2021) "Report assesses impact of COVID-19 on global happiness"]

## Article outline
Career
Publications
References
External links

## Categories
Living people; Place of birth missing (living people); Year of birth missing (living people); Canadian social psychologists; Canadian women psychologists; Canadian academic journal editors; Canadian women academics; Academic staff of Simon Fraser University; University of British Columbia Faculty of Arts alumni

## Occurrence 1: original DOI 10.1126/science.1150952 in section 'Publications'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
* [Dunn (2008) "Spending Money on Others Promotes Happiness" doi:10.1126/science.1150952]
* [Aknin (2013) "Prosocial spending and well-being: Cross-cultural evidence for a psych" doi:10.1037/a0031578]
* [Aknin (2012) "Happiness Runs in a Circular Motion: Evidence for a Positive Feedback " doi:10.1007/s10902-011-9267-5]
* [Aknin (2012) "Giving Leads to Happiness in Young Children" doi:10.1371/journal.pone.0039211]
* [Dunn (2014) "Prosocial Spending and Happiness" doi:10.1177/0963721413512503]
* [Aknin (2009) "From wealth to well-being? Money matters, but less than people think" doi:10.1080/17439760903271421]
* [Aknin (2013) "Making a difference matters: Impact unlocks the emotional benefits of " doi:10.1016/j.jebo.2013.01.008]
* [Anik (2009) "Feeling Good About Giving: The Benefits (and Costs) of Self-Interested"]
* [Aknin (2015) "Prosocial behavior leads to happiness in a small-scale rural society." doi:10.1037/xge0000082]
* [Aknin (2018) "Positive feelings reward and promote prosocial behavior" doi:10.1016/j.copsyc.2017.08.017]
* [Shariff (2016) "Income Mobility Breeds Tolerance for Income Inequality" doi:10.1177/1745691616635596]
* [Aknin (2011) "It's the Recipient That Counts: Spending Money on Strong Social Ties L" doi:10.1371/journal.pone.0017018]

### Paragraph (raw wikitext)
```
* {{cite journal |last1=Dunn |first1=Elizabeth W. |last2=Aknin |first2=Lara B. |last3=Norton |first3=Michael I. |title=Spending Money on Others Promotes Happiness |journal=Science |date=21 March 2008 |volume=319 |issue=5870 |pages=1687–1688 |doi=10.1126/science.1150952 |pmid=18356530 |bibcode=2008Sci...319.1687D |s2cid=29589887 |url=https://www.science.org/doi/abs/10.1126/science.1150952 |language=EN|url-access=subscription }}
* {{cite journal |last1=Aknin |first1=Lara B. |last2=Barrington-Leigh |first2=Christopher P. |last3=Dunn |first3=Elizabeth W. |last4=Helliwell |first4=John F. |author-link4=John F. Helliwell |last5=Burns |first5=Justine |author-link5=Justine Burns |last6=Biswas-Diener |first6=Robert |author-link6=Robert Biswas-Diener |last7=Kemeza |first7=Imelda |last8=Nyende |first8=Paul |last9=Ashton-James |first9=Claire E. |last10=Norton |first10=Michael I. |title=Prosocial spending and well-being: Cross-cultural evidence for a psychological universal. |journal=Journal of Personality and Social Psychology |date=April 2013 |volume=104 |issue=4 |pages=635–652 |doi=10.1037/a0031578 |pmid=23421360 |s2cid=5403883 |url=https://psycnet.apa.org/doiLanding?doi=10.1037/a0031578 |language=en |issn=1939-1315|hdl=11370/24a6ab33-643b-47af-9e5b-4110f51a55bb |hdl-access=free }}
* {{cite journal |last1=Aknin |first1=Lara B. |last2=Dunn |first2=Elizabeth W. |last3=Norton |first3=Michael I. |title=Happiness Runs in a Circular Motion: Evidence for a Positive Feedback Loop between Prosocial Spending and Happiness |journal=Journal of Happiness Studies |date=1 April 2012 |volume=13 |issue=2 |pages=347–355 |doi=10.1007/s10902-011-9267-5 |s2cid=32032719 |url=https://link.springer.com/article/10.1007/s10902-011-9267-5 |language=en |issn=1573-7780|url-access=subscription }}
* {{cite journal |last1=Aknin |first1=Lara B. |last2=Hamlin |first2=J. Kiley |last3=Dunn |first3=Elizabeth W. |title=Giving Leads to Happiness in Young Children |journal=PLOS ONE |date=14 June 2012 |volume=7 |issue=6 |article-number=e39211 |doi=10.1371/journal.pone.0039211 |pmid=22720078 |pmc=3375233 |bibcode=2012PLoSO...739211A |language=en |issn=1932-6203|doi-access=free }}
* {{cite journal |last1=Dunn |first1=Elizabeth W. |last2=Aknin |first2=Lara B. |last3=Norton |first3=Michael I. |title=Prosocial Spending and Happiness |journal=Current Directions in Psychological Science |date=February 2014 |volume=23 |issue=1 |pages=41–47 |doi=10.1177/0963721413512503 |url=https://journals.sagepub.com/doi/abs/10.1177/0963721413512503 |issn=0963-7214|url-access=subscription }}
* {{cite journal |last1=Aknin |first1=Lara B. |last2=Norton |first2=Michael I. |last3=Dunn |first3=Elizabeth W. |title=From wealth to well-being? Money matters, but less than people think |journal=The Journal of Positive Psychology |date=1 November 2009 |volume=4 |issue=6 |pages=523–527 |doi=10.1080/17439760903271421 |s2cid=9911004 |url=https://www.tandfonline.com/doi/abs/10.1080/17439760903271421 |issn=1743-9760|url-access=subscription }}
* {{cite journal |last1=Aknin |first1=Lara B. |last2=Dunn |first2=Elizabeth W. |last3=Whillans |first3=Ashley V. |last4=Grant |first4=Adam M. |last5=Norton |first5=Michael I. |title=Making a difference matters: Impact unlocks the emotional benefits of prosocial spending |journal=Journal of Economic Behavior & Organization |date=1 April 2013 |volume=88 |pages=90–95 |doi=10.1016/j.jebo.2013.01.008 |s2cid=55775819 |url=https://www.sciencedirect.com/science/article/pii/S0167268113000176 |language=en |issn=0167-2681|url-access=subscription }}
* {{cite journal |last1=Anik |first1=Lalin |last2=Aknin |first2=Lara B. |last3=Norton |first3=Michael I. |last4=Dunn |first4=Elizabeth W. |title=Feeling Good About Giving: The Benefits (and Costs) of Self-Interested Charitable Behavior |date=6 August 2009 |url=https://papers.ssrn.com/sol3/papers.cfm?abstract_id=1444831 |publisher=Social Science Research Network |ssrn=1444831 |language=en}}
* {{cite journal |last1=Aknin |first1=Lara B. |last2=Broesch |first2=Tanya |last3=Hamlin |first3=J. Kiley |last4=Van de Vondervoort |first4=Julia W. |title=Prosocial behavior leads to happiness in a small-scale rural society. |journal=Journal of Experimental Psychology: General |date=August 2015 |volume=144 |issue=4 |pages=788–795 |doi=10.1037/xge0000082 |pmid=26030168 |url=https://psycnet.apa.org/getdoi.cfm?doi=10.1037/xge0000082 |language=en |issn=1939-2222|url-access=subscription }}
* {{cite journal |last1=Aknin |first1=Lara B |last2=Van de Vondervoort |first2=Julia W |last3=Hamlin |first3=J Kiley |title=Positive feelings reward and promote prosocial behavior |journal=Current Opinion in Psychology |date=1 April 2018 |volume=20 |pages=55–59 |doi=10.1016/j.copsyc.2017.08.017 |pmid=28837957 |url=https://www.sciencedirect.com/science/article/pii/S2352250X17301124 |language=en |issn=2352-250X|url-access=subscription }}
* {{cite journal |last1=Shariff |first1=Azim F. |last2=Wiwad |first2=Dylan |last3=Aknin |first3=Lara B. |title=Income Mobility Breeds Tolerance for Income Inequality |journal=Perspectives on Psychological Science |date=May 2016 |volume=11 |issue=3 |pages=373–380 |doi=10.1177/1745691616635596 |pmid=27217250 |s2cid=12557460 |url=https://journals.sagepub.com/doi/abs/10.1177/1745691616635596 |issn=1745-6916|url-access=subscription }}
* {{cite journal |last1=Aknin |first1=Lara B. |last2=Sandstrom |first2=Gillian M. |last3=Dunn |first3=Elizabeth W. |last4=Norton |first4=Michael I. |title=It's the Recipient That Counts: Spending Money on Strong Social Ties Leads to Greater Happiness than Spending on Weak Social Ties |journal=PLOS ONE |date=10 February 2011 |volume=6 |issue=2 |article-number=e17018 |doi=10.1371/journal.pone.0017018 |pmid=21347326 |pmc=3037397 |bibcode=2011PLoSO...617018A |language=en |issn=1932-6203|doi-access=free }}
```

### Full section (plain rendering)
==Publications==

* [Dunn (2008) "Spending Money on Others Promotes Happiness" doi:10.1126/science.1150952]
* [Aknin (2013) "Prosocial spending and well-being: Cross-cultural evidence for a psych" doi:10.1037/a0031578]
* [Aknin (2012) "Happiness Runs in a Circular Motion: Evidence for a Positive Feedback " doi:10.1007/s10902-011-9267-5]
* [Aknin (2012) "Giving Leads to Happiness in Young Children" doi:10.1371/journal.pone.0039211]
* [Dunn (2014) "Prosocial Spending and Happiness" doi:10.1177/0963721413512503]
* [Aknin (2009) "From wealth to well-being? Money matters, but less than people think" doi:10.1080/17439760903271421]
* [Aknin (2013) "Making a difference matters: Impact unlocks the emotional benefits of " doi:10.1016/j.jebo.2013.01.008]
* [Anik (2009) "Feeling Good About Giving: The Benefits (and Costs) of Self-Interested"]
* [Aknin (2015) "Prosocial behavior leads to happiness in a small-scale rural society." doi:10.1037/xge0000082]
* [Aknin (2018) "Positive feelings reward and promote prosocial behavior" doi:10.1016/j.copsyc.2017.08.017]
* [Shariff (2016) "Income Mobility Breeds Tolerance for Income Inequality" doi:10.1177/1745691616635596]
* [Aknin (2011) "It's the Recipient That Counts: Spending Money on Strong Social Ties L" doi:10.1371/journal.pone.0017018]

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 840f50a2cb83406ee6e9/article_plain.txt in the evidence directory.)

- (none found by keyword scan)

## ORIGINAL STUDY: doi:10.1126/science.1150952 (FLoRA title: Spending Money on Others Promotes Happiness)
Crossref: Spending Money on Others Promotes Happiness | Elizabeth W. Dunn, Lara B. Aknin, Michael I. Norton | Science | 2008 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2152035528", "type": "article", "publication_year": 2008, "cited_by_count": 1677, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1126_science_1150952.txt (Free copy found by source search (published): https://dunn.psych.ubc.ca/wp-content/uploads/2010/12/spending-money-on-others-promotes-happiness.pdf)
Retrieved: 2026-10-06T16:09:12+00:00
### Abstract (Crossref deposited abstract)
Although much research has examined the effect of income on happiness, we suggest that how people spend their money may be at least as important as how much money they earn. Specifically, we hypothesized that spending money on other people may have a more positive impact on happiness than spending money on oneself. Providing converging evidence for this hypothesis, we found that spending more of one's income on others predicted greater happiness both cross-sectionally (in a nationally representative survey study) and longitudinally (in a field study of windfall spending). Finally, participants who were randomly assigned to spend money on others experienced greater happiness than those assigned to spend money on themselves.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1037/pspa0000191 (FLoRA title: Does spending money on others promote happiness?: A registered replication report.; FLoRA outcome code: mixed [screening input only, not citable]; DOI detected on page: False)
Crossref: Does spending money on others promote happiness?: A registered replication report. | Lara B. Aknin, Elizabeth W. Dunn, Jason Proulx, Iris Lok, Michael I. Norton | Journal of Personality and Social Psychology | 2020 | type journal-article
Updates/relations (Crossref): [] {"has-preprint": [{"id-type": "doi", "id": "10.31234/osf.io/mye3g", "asserted-by": "object"}]}
OpenAlex: {"id": "https://openalex.org/W3014278856", "type": "article", "publication_year": 2020, "cited_by_count": 149, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1037_pspa0000191.txt (Free copy found by source search (accepted manuscript): https://osf.io/mye3g/download)
Retrieved: 2026-10-06T16:09:13+00:00
### Abstract (Europe PMC abstract)
Research indicates that spending money on others- prosocial spending -leads to greater happiness than spending money on oneself (e.g., Dunn, Aknin, & Norton, 2008, 2014). These findings have received widespread attention because they offer insight into why people engage in costly prosocial behavior, and what constitutes happier spending more broadly. However, most studies on prosocial spending (like most research on the emotional benefits of generosity) utilized small sample sizes ( n   N  = 5,199), participants who recalled a prosocial (vs. personal) spending memory reported greater happiness but differences were small. Taken together, these studies support the hypothesis that spending money on others does promote happiness, but demonstrate that the magnitude of the effect depends on several methodological features. (PsycInfo Database Record (c) 2020 APA, all rights reserved).

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1111/sipr.12069 | Helping and Happiness: A Review and Guide for Public Policy | 2020 | read: abstract | mentions replication: False
- doi:10.1016/j.copsyc.2021.09.017 | Prosocial behavior and well-being: Shifting from the ‘chicken and egg’ to positive feedback loop | 2021 | read: metadata_only | mentions replication: False
- doi:10.1080/10615806.2021.1950695 | Social belonging, compassion, and kindness: Key ingredients for fostering resilience, recovery, and growth from the COVID-19 pandemic | 2021 | read: abstract | mentions replication: False
- doi:10.1016/j.tics.2022.02.007 | Undersociality: miscalibrated social cognition can inhibit social connection | 2022 | read: metadata_only | mentions replication: False
- doi:10.1146/annurev-psych-010213-115043 | Emotion and Decision Making | 2014 | read: abstract | mentions replication: False

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1146/annurev-psych-010213-115043 | Emotion and Decision Making | 2014 | review | cited_by 2897
  Abstract: A revolution in the science of emotion has emerged in recent decades, with the potential to create a paradigm shift in decision theories. The research reveals that emotions constitute potent, pervasive, predictable, sometimes harmful and sometimes beneficial drivers of decision making. Across different domains, important regularities appear in the mechanisms through which emotions influence judgments and choices. We organize and analyze what has been learned from the past 35 years of work on emotion and decision making. In so doing, we propose the emotion-imbued choice model, which accounts for inputs from traditional rational choice theory and from newer emotion research, synthesizing scientific models.
- [review citing original] doi:10.1016/j.jesp.2018.02.014 | Happy to help? A systematic review and meta-analysis of the effects of performing acts of kindness on the well-being of the actor | 2018 | review | cited_by 541
  Abstract: Do acts of kindness improve the well-being of the actor? Recent advances in the behavioural sciences have provided a number of explanations of human social, cooperative and altruistic behaviour. These theories predict that people will be ‘happy to help’ family, friends, community members, spouses, and even strangers under some conditions. Here we conduct a systematic review and meta-analysis of the experimental evidence that kindness interventions (for example, performing ‘random acts of kindness’) boost subjective well-being. Our initial search of the literature identified 489 articles; of which 24 (27 studies) met the inclusion criteria (total N = 4045). These 27 studies, some of which included multiple control conditions and dependent measures, yielded 52 effect sizes. Multi-level modeling revealed that the overall effect of kindness on the well-being of the actor is small-to-medium (δ = 0.28). The effect was not moderated by sex, age, type of participant, intervention, control condition or outcome measure. There was no indication of publication bias. We discuss the limitations of the current literature, and recommend that future research test more specific theories of kindness:
- [review citing original] doi:10.1037/a0037249 | Effect of kindness-based meditation on health and well-being: A systematic review and meta-analysis. | 2014 | review | cited_by 390
  Abstract: OBJECTIVE: Kindness-based meditation (KBM) is a rubric covering meditation techniques developed to elicit kindness in a conscious way. Some techniques, for example, loving-kindness meditation and compassion meditation, have been included in programs aimed at improving health and well-being. Our aim was to systematically review and meta-analyze the evidence available from randomized controlled trials (RCTs) comparing the effects of KBM on health and well-being against passive and active control groups in patients and the general population. METHOD: Searches were completed in March 2013. Two reviewers applied predetermined eligibility criteria (RCTs, peer-reviewed publications, theses or conference proceedings, adult participants, KBM interventions) and extracted the data. Meta-analyses used random-effects models. RESULTS: Twenty-two studies were included. KBM was moderately effective in decreasing self-reported depression (standard mean difference [Hedges's g] = -0.61, 95% confidence interval [CI] [-1.08, -0.14]) and increasing mindfulness (Hedges's g = 0.63, 95% CI [0.22, 1.05]), compassion (Hedges's g = 0.61, 95% CI [0.24, 0.99]) and self-compassion (Hedges's g = 0.45, 95% CI [0.1
- [review citing original] doi:10.1037/bul0000298 | Rewards of kindness? A meta-analysis of the link between prosociality and well-being. | 2020 | review | cited_by 380
  Abstract: = 198,213) between prosociality and well-being, this masked the substantial variability in the effect as a function of numerous moderators. In particular, the effect of prosociality on eudaimonic well-being was stronger than that on hedonic well-being. Prosociality was most strongly related to psychological functioning-showing a more modest relationship with psychological malfunctioning and physical health. Using prosociality scales was more strongly associated with well-being than using measures of volunteering/helping frequency or status. In addition, informal helping (vs. formal helping) was linked to more well-being benefits. Demographically, younger givers exhibited higher levels of well-being other than physical health, while older and retired givers reported better physical health only. Female givers showed stronger relationships between prosociality and eudaimonic well-being, psychological malfunctioning, and physical health. Methodologically, the magnitude of the link was stronger in studies using primary (vs. secondary) data and with higher methodological rigor (i.e., measurement reliability and validity). We discussed all of these results and implications and suggested d
- [review citing original] doi:10.1007/s12671-017-0841-8 | A Systematic Review and Meta-analysis of the Effects of Meditation on Empathy, Compassion, and Prosocial Behaviors | 2017 | review | cited_by 358
  Abstract: (none)
- [cites original and replication 10.1037/pspa0000191] doi:10.1111/sipr.12069 | Helping and Happiness: A Review and Guide for Public Policy | 2020 | article | cited_by 109
  Abstract: Abstract Perhaps one of the most reaffirming findings to emerge over the past several decades is that humans not only engage in generous behavior, they also appear to experience pleasure from doing so. Yet not all acts of helping lead to greater happiness. Here, we review the growing body of evidence showing that people engage in a wide array of prosocial behaviors (e.g., charitable giving, volunteering, blood/organ donation, offering advice, food sharing) which can promote positive emotions. Then, using self‐determination theory, a foundational theory of human motivation, we consider when and how generous actions are most likely to boost the helper's happiness—and when they are not. Finally, we leverage these insights to consider how public policy and organizations can apply this information to make prosocial action more emotionally rewarding for citizens and employees alike.
- [cites original and replication 10.1037/pspa0000191] doi:10.1016/j.copsyc.2021.09.017 | Prosocial behavior and well-being: Shifting from the ‘chicken and egg’ to positive feedback loop | 2021 | review | cited_by 81
  Abstract: (none)
- [cites original and replication 10.1037/pspa0000191] doi:10.1080/10615806.2021.1950695 | Social belonging, compassion, and kindness: Key ingredients for fostering resilience, recovery, and growth from the COVID-19 pandemic | 2021 | article | cited_by 78
  Abstract: BACKGROUND: The coronavirus disease 2019 (COVID-19) pandemic has led to increases in anxiety, depression, posttraumatic stress disorder, burnout, grief, and suicide, particularly for healthcare workers and vulnerable individuals. In some places, due to low vaccination rates and new variants of SARS-CoV-2 emerging, psychosocial strategies for remaining resilient during an ongoing multi-faceted stressor are still needed. Elsewhere, thanks to successful vaccination campaigns, some countries have begun reopening but questions remain regarding how to best recover, adjust, and grow following the collective stress and loss caused by the pandemic. METHOD: Here, we briefly describe three evidence-based strategies that can help foster individual and collective recovery, growth, and resilience: cultivating social belonging, practicing compassion, and engaging in kindness. RESULTS: Social belonging involves a sense of interpersonal connectedness. Practicing compassion involves perceiving suffering as part of a larger shared human experience and directing kindness toward it. Finally, engaging in kindness involves prosocial acts toward others. CONCLUSIONS: Together, these strategies can promote 
- [cites original and replication 10.1037/pspa0000191] doi:10.1016/j.tics.2022.02.007 | Undersociality: miscalibrated social cognition can inhibit social connection | 2022 | review | cited_by 75
  Abstract: (none)
