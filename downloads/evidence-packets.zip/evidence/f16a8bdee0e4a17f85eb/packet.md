# Evidence packet f16a8bdee0e4a17f85eb: Action bias

Frozen revision: 1358491689 (2026-06-09T01:22:48Z); https://en.wikipedia.org/w/index.php?oldid=1358491689
Live check: {"frozen_revid": "1358491689", "title": "Action bias", "live_revid": 1358491689, "live_timestamp": "2026-06-09T01:22:48Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "central_effect", "context_kind": "inline", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 1}

## Article lead (plain rendering, approximate)
Action bias is the psychological phenomenon where people tend to favor action over inaction, even when there is no indication that doing so would point towards a better result. It is an automatic response, similar to a reflex or an impulse and is not based on rational thinking. One of the first appearances of the term "action bias" in scientific journals was in a 2000 paper by Patt and Zeckhauser titled "Action Bias and Environmental Decisions", where its relevance in politics was expounded. [ref: "Action Bias"]

## Article outline
Overview
  Theories
Real-world effects
  <span class="anchor" id="Action bias in politics">In politics</span>
  <span class="anchor" id="Action bias in medicine">In medicine</span>
    Causes
    Impacts
  <span class="anchor" id="Action bias in sports">In sports</span>
  <span class="anchor" id="Action bias in economics and management">In economics and management</span>
  <span class="anchor" id="Action bias in environmental decision-making">In environmental decision-making</span>
<span class="anchor" id="Other types of action bias">Other types</span>
  <span class="anchor" id="Utility-based action bias">Utility-based</span>
  <span class="anchor" id="Single-action bias">Single</span>
<span class="anchor" id="Eliminating action bias">Elimination</span>
See also
References

## Categories
Cognitive biases; Behavioral concepts; Rationalism

## Occurrence 1: original (named-reference reuse) DOI 10.1016/j.joep.2006.12.001 in section '<span class="anchor" id="Action bias in sports">In sports</span>'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
=== In sports ===

According to some psychologists, the goalkeeper shows an action bias in over 90 percent of the penalty kicks in soccer by diving to either the left or the right. These theorists assert that it is more effective to stand still, or to wait and see which direction the ball is kicked before moving, because guessing wrong will almost guarantee giving up a goal. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001] Researchers surmise that goalkeepers take the risk of guessing because "action" is preferred by their teammates, and success will bring social recognition and other rewards. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001]

### Paragraph (raw wikitext)
```
=== <span class="anchor" id="Action bias in sports">In sports</span> ===
[[File:Football goal 20050521.jpg|thumb|A football goal]]
According to some psychologists, the [[Goalkeeper (association football)|goalkeeper]] shows an action bias in over 90 percent of the [[Penalty kick (association football)|penalty kicks]] in [[soccer]] by diving to either the left or the right. These theorists assert that it is more effective to stand still, or to wait and see which direction the ball is kicked before moving, because guessing wrong will almost guarantee giving up a goal.<ref name=":6" /> Researchers surmise that goalkeepers take the risk of guessing because "action" is preferred by their teammates, and success will bring social recognition and other rewards.<ref name=":6">{{Cite journal |last1=Bar-Eli |first1=Michael |last2=Azar |first2=Ofer H. |last3=Ritov |first3=Ilana |last4=Keidar-Levin |first4=Yael |last5=Schein |first5=Galit |date=2007-10-01 |title=Action bias among elite soccer goalkeepers: The case of penalty kicks |url=https://www.sciencedirect.com/science/article/pii/S0167487006001048 |journal=Journal of Economic Psychology |language=en |volume=28 |issue=5 |pages=606–621 |doi=10.1016/j.joep.2006.12.001 |s2cid=1188584 |issn=0167-4870|url-access=subscription }}</ref>
```

### Full section (plain rendering)
=== In sports ===

According to some psychologists, the goalkeeper shows an action bias in over 90 percent of the penalty kicks in soccer by diving to either the left or the right. These theorists assert that it is more effective to stand still, or to wait and see which direction the ball is kicked before moving, because guessing wrong will almost guarantee giving up a goal. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001] Researchers surmise that goalkeepers take the risk of guessing because "action" is preferred by their teammates, and success will bring social recognition and other rewards. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001]

However, this analysis ignores game theory and the dynamics of the sport. Because the penalty spot is only 12 yards away, the goalposts are 24 feet apart, the crossbar is 8 feet high, and the ball will be struck with great force, the goalkeeper cannot stand still and wait for the ball to be struck, because they will not have time to reach it. The ball could go to any of the four corners. To have a chance to make a save, the optimum strategy is to guess the target location and begin moving before the opponent's foot touches the ball. This context negates the claim of bias, because the goalkeeper is expected to put in the visible effort to make a save and actively prevent a goal, rather than arrive too late by waiting for directional certainty. Some penalty takers counter this strategy by rolling or chipping the ball down the middle, which is called a Panenka penalty, after a Czech player who made it famous at the UEFA Euro 1976 final.

Action bias is also influenced by previous outcomes. If a team loses a match, the coach is more likely to choose action by changing some of the players, than inaction, even though this might not necessarily lead to a better performance. [ref: Zeelenberg (2002) "The inaction effect in the psychology of regret." doi:10.1037/0022-3514.82.3.314] As expressed by one coach, "Just because I can do something doesn't mean that I should, or that that activity is relevant." [ref: (2021) "Full Episode – The Hoops Forum – Ep. 23 – Action Bias in Coaching"]

## Occurrence 2: original DOI 10.1016/j.joep.2006.12.001 in section '<span class="anchor" id="Action bias in sports">In sports</span>'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
=== In sports ===

According to some psychologists, the goalkeeper shows an action bias in over 90 percent of the penalty kicks in soccer by diving to either the left or the right. These theorists assert that it is more effective to stand still, or to wait and see which direction the ball is kicked before moving, because guessing wrong will almost guarantee giving up a goal. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001] Researchers surmise that goalkeepers take the risk of guessing because "action" is preferred by their teammates, and success will bring social recognition and other rewards. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001]

### Paragraph (raw wikitext)
```
=== <span class="anchor" id="Action bias in sports">In sports</span> ===
[[File:Football goal 20050521.jpg|thumb|A football goal]]
According to some psychologists, the [[Goalkeeper (association football)|goalkeeper]] shows an action bias in over 90 percent of the [[Penalty kick (association football)|penalty kicks]] in [[soccer]] by diving to either the left or the right. These theorists assert that it is more effective to stand still, or to wait and see which direction the ball is kicked before moving, because guessing wrong will almost guarantee giving up a goal.<ref name=":6" /> Researchers surmise that goalkeepers take the risk of guessing because "action" is preferred by their teammates, and success will bring social recognition and other rewards.<ref name=":6">{{Cite journal |last1=Bar-Eli |first1=Michael |last2=Azar |first2=Ofer H. |last3=Ritov |first3=Ilana |last4=Keidar-Levin |first4=Yael |last5=Schein |first5=Galit |date=2007-10-01 |title=Action bias among elite soccer goalkeepers: The case of penalty kicks |url=https://www.sciencedirect.com/science/article/pii/S0167487006001048 |journal=Journal of Economic Psychology |language=en |volume=28 |issue=5 |pages=606–621 |doi=10.1016/j.joep.2006.12.001 |s2cid=1188584 |issn=0167-4870|url-access=subscription }}</ref>
```

### Full section (plain rendering)
=== In sports ===

According to some psychologists, the goalkeeper shows an action bias in over 90 percent of the penalty kicks in soccer by diving to either the left or the right. These theorists assert that it is more effective to stand still, or to wait and see which direction the ball is kicked before moving, because guessing wrong will almost guarantee giving up a goal. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001] Researchers surmise that goalkeepers take the risk of guessing because "action" is preferred by their teammates, and success will bring social recognition and other rewards. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001]

However, this analysis ignores game theory and the dynamics of the sport. Because the penalty spot is only 12 yards away, the goalposts are 24 feet apart, the crossbar is 8 feet high, and the ball will be struck with great force, the goalkeeper cannot stand still and wait for the ball to be struck, because they will not have time to reach it. The ball could go to any of the four corners. To have a chance to make a save, the optimum strategy is to guess the target location and begin moving before the opponent's foot touches the ball. This context negates the claim of bias, because the goalkeeper is expected to put in the visible effort to make a save and actively prevent a goal, rather than arrive too late by waiting for directional certainty. Some penalty takers counter this strategy by rolling or chipping the ball down the middle, which is called a Panenka penalty, after a Czech player who made it famous at the UEFA Euro 1976 final.

Action bias is also influenced by previous outcomes. If a team loses a match, the coach is more likely to choose action by changing some of the players, than inaction, even though this might not necessarily lead to a better performance. [ref: Zeelenberg (2002) "The inaction effect in the psychology of regret." doi:10.1037/0022-3514.82.3.314] As expressed by one coach, "Just because I can do something doesn't mean that I should, or that that activity is relevant." [ref: (2021) "Full Episode – The Hoops Forum – Ep. 23 – Action Bias in Coaching"]

## Occurrence 3: original (named-reference reuse) DOI 10.1016/j.joep.2006.12.001 in section '<span class="anchor" id="Action bias in economics and management">In economics and management</span>'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
=== In economics and management ===
Action bias also influences decision-making in the field of economics and management. In the situations where there is an economic downfall, the central banks and governments experience the pressure to take action, as they feel increased scrutiny from the public. As they are expected to fix the situation, action is seen as more appropriate than inaction. Even if the outcome is not successful, by taking action public figures can avoid criticism more easily. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001] In the cases of good economic performance, the authorities are more inclined towards an omission bias as they do not wish to be accused of making the wrong choices that might destroy the current equilibrium. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001] The action/omission bias can be seen in other similar scenarios such as: investors changing their portfolio, switching a company's strategy, applying for a different job, moving to a different city. At the macro-economic level, the action/omission bias comes into play when discussing changes of politics-related variables, such as interest rates, tax rates and various types of expenditures. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001]

### Paragraph (raw wikitext)
```
=== <span class="anchor" id="Action bias in economics and management">In economics and management</span> ===
Action bias also influences decision-making in the field of [[economics]] and [[management]]. In the situations where there is an economic downfall, the [[central bank]]s and [[government]]s experience the pressure to take action, as they feel increased scrutiny from the public. As they are expected to fix the situation, action is seen as more appropriate than inaction. Even if the outcome is not successful, by taking action public figures can avoid criticism more easily.<ref name=":6" /> In the cases of good economic performance, the authorities are more inclined towards an [[omission bias]] as they do not wish to be accused of making the wrong choices that might destroy the current equilibrium.<ref name=":6" /> The action/omission bias can be seen in other similar scenarios such as: [[investor]]s changing their portfolio, switching a company's strategy, applying for a different job, moving to a different city. At the macro-economic level, the action/omission bias comes into play when discussing changes of politics-related variables, such as [[interest rate]]s, [[tax rate]]s and various types of [[expenditures]].<ref name=":6" />
```

### Full section (plain rendering)
=== In economics and management ===
Action bias also influences decision-making in the field of economics and management. In the situations where there is an economic downfall, the central banks and governments experience the pressure to take action, as they feel increased scrutiny from the public. As they are expected to fix the situation, action is seen as more appropriate than inaction. Even if the outcome is not successful, by taking action public figures can avoid criticism more easily. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001] In the cases of good economic performance, the authorities are more inclined towards an omission bias as they do not wish to be accused of making the wrong choices that might destroy the current equilibrium. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001] The action/omission bias can be seen in other similar scenarios such as: investors changing their portfolio, switching a company's strategy, applying for a different job, moving to a different city. At the macro-economic level, the action/omission bias comes into play when discussing changes of politics-related variables, such as interest rates, tax rates and various types of expenditures. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001]

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: f16a8bdee0e4a17f85eb/article_plain.txt in the evidence directory.)

- === In economics and management ===
Action bias also influences decision-making in the field of economics and management. In the situations where there is an economic downfall, the central banks and governments experience the pressure to take action, as they feel increased scrutiny from the public. As they are expected to fix the situation, action is seen as more appropriate than inaction. Even if the outcome is not successful, by taking action public figures can avoid criticism more easily. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001] In the cases of good economic performance, the authorities are more inclined towards an omission bias as they do not wish to be accused of making the wrong choices that might destroy the current equilibrium. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001] The action/omission bias can be seen in other similar scenarios such as: investors changing their portfolio, switching a company's strategy, applying for a different job, moving to a different city. At the macro-economic level, the action/omission bias comes into play when discussing changes of politics-related variables, such as interest rates, tax rates and various types of expenditures. [FOCAL REF: Bar-Eli (2007) "Action bias among elite soccer goalkeepers: The case of penalty kicks" doi:10.1016/j.joep.2006.12.001]

## ORIGINAL STUDY: doi:10.1016/j.joep.2006.12.001 (FLoRA title: Action bias among elite soccer goalkeepers: The case of penalty kicks)
Crossref: Action bias among elite soccer goalkeepers: The case of penalty kicks | Michael Bar-Eli, Ofer H. Azar, Ilana Ritov, Yael Keidar-Levin, Galit Schein | Journal of Economic Psychology | 2007 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W1561286305", "type": "article", "publication_year": 2007, "cited_by_count": 214, "is_retracted": false, "oa_status": "green", "oa_pdf": null, "oa_landing": "https://papers.ssrn.com/sol3/Delivery.cfm/SSRN_ID1091662_code337316.pdf?abstractid=1091662&mirid=1"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1016_j_joep_2006_12_001.txt (Free copy found by source search (published): https://pluto.huji.ac.il/~msiritov/BarEliAzarRitovKeidarSchein.pdf)
Retrieved: 2026-10-06T16:10:55+00:00

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1016/j.joep.2026.102886 (FLoRA title: Replication: No action ‘Bias’ among elite soccer goalkeepers during penalty kicks; FLoRA outcome code: statistically successful but flawed [screening input only, not citable]; DOI detected on page: False)
Crossref: Replication: No action ‘Bias’ among elite soccer goalkeepers during penalty kicks | Rishav Singh, Sumitava Mukherjee | Journal of Economic Psychology | 2026 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W7119964961", "type": "article", "publication_year": 2026, "cited_by_count": 2, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1016_j_joep_2026_102886.txt (PDF supplied by the project lead on 10 October 2026 (published version))
Retrieved: 2026-10-06T16:10:56+00:00

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1016/j.joep.2026.102940 | Do professionals choke in the face of pressure and distraction? | 2026 | read: abstract | mentions replication: False
- doi:10.1177/01461672211042315 | Action and Inaction in Moral Judgments and Decisions: Meta-Analysis of Omission Bias Omission-Commission Asymmetries | 2021 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_1177_01461672211042315.txt
- doi:10.1371/journal.pone.0292857 | Decision avoidance and post-decision regret: A systematic review and meta-analysis | 2023 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_1371_journal_pone_0292857.txt

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1177/01461672211042315 | Action and Inaction in Moral Judgments and Decisions: Meta-Analysis of Omission Bias Omission-Commission Asymmetries | 2021 | review | cited_by 43
  Abstract: Omission bias is people’s tendency to evaluate harm done through omission as less morally wrong and less blameworthy than commission when there is harm. However, findings are inconsistent. We conducted a preregistered meta-analysis, with 21 samples (13 articles, 49 effects) on omission-commission asymmetries in judgments and decisions. We found an overall effect of g = 0.45, 95% confidence interval (CI) = [0.14, 0.77], with stronger effects for morality and blame than for decisions. Publication bias tests produced mixed results with some indication for publication bias, though effects persisted even after most publication bias adjustments. The small sample of studies included limited our ability to draw definite conclusions regarding moderators, with inconclusive findings when applying different models. After compensating for low power, we found indication for moderation by role responsibility, perspective (self vs. others), outcome type, and study design. We hope this meta-analysis will inspire research on this phenomenon and applications to real-life, especially given the raging pandemic. Materials, data, and code are available on https://osf.io/9fcqm/ .
- [review citing original] doi:10.1371/journal.pone.0292857 | Decision avoidance and post-decision regret: A systematic review and meta-analysis | 2023 | review | cited_by 14
  Abstract: Decision Avoidance (DA) strategies allow people to forego or abandon effortful deliberation by postponing, bypassing, or delegating a decision. DA is thought to reduce regret, primarily by allowing decision makers to evade personal responsibility for potential negative outcomes. We tested this relation between DA and post-decision regret in a multilevel meta-analysis of 59 effect estimates coming from 13 papers. Five DA strategies were considered: status quo preservation, action omission, inaction inertia, choice delegation and choice deferral. Across all effects and DA strategies, there was a non-significant trend toward DA reducing regret (Hedges' g = -0.23, p = 0.063). When assessing individual strategies, we found that only status quo preservation reduced regret reliably (Hedges' g = -0.45, p = 0.006). The relationship between DA and regret was unclear for the other DA strategies. We tested a number of moderators for the effect. Only 'previous experience' (i.e., the outcome of a previous decision) influenced the relation between DA and regret reliably. That is, if participants choose the DA option when the same choice previously led to a negative outcome, regret is actually enh
- [cites original and replication 10.1016/j.joep.2026.102886] doi:10.1016/j.joep.2026.102940 | Do professionals choke in the face of pressure and distraction? | 2026 | article | cited_by 0
  Abstract: We ask whether facing partisan audiences affects the execution of a skilled task. Our setting is penalty shootouts in the high-stakes environment of elite professional football (soccer). In this context, performers take penalties under intense pressure, while facing a subset of the crowd behind the goal who attempt to distract them through visual and auditory tactics. Using data on 1,322 penalties taken in the later rounds of major English cup competitions from 1992 to 2026, we find no evidence that having supportive allied spectators behind the goal provides a strategic advantage. This implies that elite professionals in this domain can effectively screen out crowd-induced distractions when performing under extreme stress.
