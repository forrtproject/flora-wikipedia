# Evidence packet 8ae7ecd1c42737d7869c: Positive illusions

Frozen revision: 1309404794 (2025-09-03T21:57:48Z); https://en.wikipedia.org/w/index.php?oldid=1309404794
Live check: {"frozen_revid": "1309404794", "title": "Positive illusions", "live_revid": 1309404794, "live_timestamp": "2025-09-03T21:57:48Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "broad_topic", "context_kind": "list", "living_person_category": false, "health_term_flag": true, "co_cited": false, "large_project": false, "flora_originals_on_page": 3}

## Article lead (plain rendering, approximate)
Positive illusions are unrealistically favorable attitudes that people have towards themselves or to people that are close to them. Positive illusions are a form of self-deception or self-enhancement that feel good, maintain self-esteem, or avoid discomfort, at least in the short term. There are three general forms: inflated assessment of one's own abilities, unrealistic optimism about the future, and an illusion of control. [ref: harvnb|Kruger|Chan|Roese|2009.] The term "positive illusions" originates in a 1988 paper by Shelley E. Taylor and Jonathon D. Brown. [ref: harvnb|Kruger|Chan|Roese|2009.] Taylor and Brown's model of mental health maintains that certain positive illusions are highly prevalent in normal thought and predictive of criteria traditionally associated with mental health.

There are controversies about the extent to which people reliably demonstrate positive illusions, as well as whether these illusions are beneficial to the people who have them. [ref: harvnb|Kruger|Chan|Roese|2009.] [ref: harvnb|McKay|Dennett|2009.] [ref: harvnb|Colvin|Block|1994.] [ref: harvnb|Birinci|Dirik|2010.]

## Article outline
Types
Origins
Benefits and liabilities
  Mental health
  Physical health
  Potential liabilities
Negative counterparts
Mitigation
See also
Notes
References
External links

## Categories
Cognitive biases; Illusions; Perception

## Occurrence 1: original DOI 10.1002/ejsp.2420170402 in section 'References'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
==References==

* [Adelson (2005) "Probing the puzzling workings of 'depressive realism'"]
* [Alicke (1985) "Global self-evaluation as determined by the desirability and controlla" doi:10.1037/0022-3514.49.6.1621]
* Alicke, M.D., & Govorun, O. (2005). "The better-than-average effect." In M.D. Alicke, D.A. Dunning, & J.I. Krueger (Eds.), The self in social judgment (pp.&nbsp;85 –108). Hove: Psychology.
* [Allan (2007) "The sad truth about depressive realism" doi:10.1080/17470210601002686]
* [Armor (1998) "Advances in Experimental Social Psychology" doi:10.1016/S0065-2601(08)60386-X]
* [Armor (2002) "Heuristics and Biases: The Psychology of Intuitive Judgment" doi:10.1017/CBO9780511808098.021]
* [Baumeister (1989) "The optimal margin of illusion" doi:10.1521/jscp.1989.8.2.176]
* [Biglan (2012) "The Critical Role of Nurturing Environments for Promoting Human Wellbe" doi:10.1037/a0026796]
* [Birinci (2010) "Depressive Realism: Happiness or Objectivity"]
* [Bonanno (2005) "Self-enhancement among high-exposure survivors of the September 11th t" doi:10.1037/0022-3514.88.6.984]
* [Bower (1998) "Cognitive processing, discovery of meaning, CD 4 decline, and AIDS-rel" doi:10.1037/0022-006X.66.6.979]
* [Boyd-Wilson (2000) "Do we need positive illusions to carry out plans? Illusion: and instru" doi:10.1016/S0191-8869(99)00261-5]
* [Brown (1986) "Evaluations of self and others: Self-enhancement biases in social judg" doi:10.1521/soco.1986.4.4.353]
*[Buehler (1994) "Exploring the "planning fallacy": Why people underestimate their task " doi:10.1037/0022-3514.67.3.366]
* [Campbell (1986) "Similarity and uniqueness: The effects of attribute type, relevance, a" doi:10.1037/0022-3514.50.2.281]
* [Carson (2010) "Depressive realism and clinical depression" doi:10.1016/j.brat.2009.11.011]
* [Colvin (1994) "Do positive illusions foster mental health? An Examination of the Tayl" doi:10.1037/0033-2909.116.1.3]
* [Compton (1992) "Are positive illusions necessary for self-esteem: a research note" doi:10.1016/0191-8869(92)90177-Q]
* [Coyne (1983) "The role of cognition in depression: A critical appraisal" doi:10.1037/0033-2909.94.3.472]
*[Crary (1966) "Reactions to incongruent self-experiences" doi:10.1037/h0023347]
* [Dufner (2018) "Self-Enhancement and Psychological Adjustment: A Meta-Analytic Review" doi:10.1177/1088868318756467]
* [Dunning (1989) "Heuristics and Biases: The Psychology of Intuitive Judgment"]
* [Dunning (2004) "Flawed Self-Assessment. Implications for Health, Education, and the Wo" doi:10.1111/j.1529-1006.2004.00018.x]
* [Dykman (1989) "Processing of ambiguous and unambiguous feedback by depressed and nond" doi:10.1037/0022-3514.56.3.431]
* [Eiser (2001) "Optimism, pessimism, and the direction of self-other comparisons" doi:10.1006/jesp.2000.1438]
* Fiske, S.T., & Taylor, S.E. (in press). Social cognition (3rd ed.). New York: Random House.
* [Fleming (1989) "Perceiving choice and constraint: The effects of contextual and behavi" doi:10.1037/0022-3514.56.1.27]
* [Fu (2003) "Depression, Confidence, and Decision: Evidence Against Depressive Real" doi:10.1007/s10862-005-2404-x]
* [Golin (1979) "The illusion of control among depressed patients" doi:10.1037/h0077992]
* [Gollwitzer (1989) "Effects of deliberative and implemental mind-sets on illusion of contr" doi:10.1037/0022-3514.56.4.531]
* [Greenwald (1980) "The totalitarian ego: Fabrication and revision of personal history" doi:10.1037/0003-066X.35.7.603]
* [Heine (2007) "In Search of East Asian Self-Enhancement" doi:10.1177/1088868306294587]
* [Janoff-Bulman (1982) "Expectations and action: Expectancy-value models in psychology"]
*[John (1994) "Accuracy and bias in self-perception: Individual differences in self-e" doi:10.1037/0022-3514.66.1.206]
* [Joiner (2006) "On Seeing Clearly and Thriving: Interpersonal Perspicacity as Adaptive" doi:10.1521/jscp.2006.25.5.542]
* [Kruger (1999) "Lake Wobegon be gone! The below-average effect and the egocentric natu" doi:10.1037/0022-3514.77.2.221]
* [Kruger (2009) "(Not so) positive illusions" doi:10.1017/S0140525X09991270]
* [Kuiper (1982) "Depressed and nondepressed content self-reference in mild depression" doi:10.1111/j.1467-6494.1982.tb00746.x]
* [Leary (2007) "Motivational and emotional aspects of the self" doi:10.1146/annurev.psych.58.110405.085658]
* [Lewinsohn (1980) "Social competence and depression: The role of illusory self-perception" doi:10.1037/0021-843X.89.2.203]
*[McFarland (1982) "Impact of causal attributions on affective reactions to success and fa" doi:10.1037/0022-3514.43.5.937]
* [McKay (2009) "The evolution of misbelief" doi:10.1017/S0140525X09990975]
* [Moore (2007) "Not so above average after all: When people believe they are worse tha" doi:10.1016/j.obhdp.2006.09.005]
* [Moore (2007) "Depressive Realism and Attributional Style: Implications for Individua" doi:10.1016/j.beth.2006.06.003]
* [Moore (2012) "Depressive realism: A meta-analytic review" doi:10.1016/j.cpr.2012.05.004] 
* [Msetfi (2005) "Depressive realism and outcome density bias in contingency judgments: " doi:10.1037/0096-3445.134.1.10]
* [Msetfi (2007) "Depressive realism and the effect of intertrial interval on judgements" doi:10.1080/17470210601002595]
* [Nuttin (1987) "Affective consequences of mere ownership: The name letter effect in tw" doi:10.1002/ejsp.2420170402]
* [Owens (2007) "A critical review of self-perception and the positive illusory bias I " doi:10.1007/s10567-007-0027-3]
*[Robins (2001) "Positive illusions about the self: Short-term benefits and long-term c" doi:10.1037/0022-3514.80.2.340]
* [Ruehlman (1985) "Depression and evaluative schemata" doi:10.1111/j.1467-6494.1985.tb00888.x]
* [Sedikides (2008) "Self-enhancement: Food for thought" doi:10.1111/j.1745-6916.2008.00068.x]
* [Segerstrom (1998) "Optimism is associated with mood, coping, and immune change in respons" doi:10.1037/0022-3514.74.6.1646]
* [Svenson (1981) "Are we less risky and more skillful than our fellow drivers?" doi:10.1016/0001-6918(81)90005-6]
* [Swann (1987) "The cognitive-affective crossfire: When self-consistency confronts sel" doi:10.1037/0022-3514.52.5.881]
* [Taylor (1983) "Adjustment to threatening events: A theory of cognitive adaptation" doi:10.1037/0003-066X.38.11.1161]
* [Taylor (1988) "Illusion and well-being: A social psychological perspective on mental " doi:10.1037/0033-2909.103.2.193]
* [Taylor (1992) "Optimism, coping, psychological distress, and high-risk sexual behavio" doi:10.1037/0022-3514.63.3.460]
* [Taylor (1994) "Positive illusions and well-being revisited: Separating fact from fict" doi:10.1037/0033-2909.116.1.21]
* [Taylor (1995) "Effects of mindset on positive illusions" doi:10.1037/0022-3514.69.2.213]
* [Taylor (1996) "Positive illusions and coping with adversity" doi:10.1111/j.1467-6494.1996.tb00947.x]
* [Taylor (2000) "Psychological resources, positive illusions, and health" doi:10.1037/0003-066X.55.1.99]
* [Wenger (2008) "Positive Illusions in Parenting: Every Child Is Above Average" doi:10.1111/j.1559-1816.2007.00319.x]
*[Yang (2009) "Long-Term Costs of Inflated Self-Estimate on Academic Performance Amon" doi:10.2466/PR0.105.3.727-737]

### Paragraph (raw wikitext)
```
==References==
{{refbegin|32em}}
* {{cite journal|last1=Adelson|first1=Rachel|title=Probing the puzzling workings of 'depressive realism'|journal=Monitor on Psychology|date=2005|volume=36|issue=4|page=30|url=http://www.apa.org/monitor/apr05/realism.aspx}}
* {{cite journal | last1 = Alicke | first1 = M.D. | year = 1985 | title = Global self-evaluation as determined by the desirability and controllability of trait adjectives | journal = Journal of Personality and Social Psychology | volume = 49 | issue = 6| pages = 1621–1630 | doi = 10.1037/0022-3514.49.6.1621  }}
* Alicke, M.D., & Govorun, O. (2005). "The better-than-average effect." In M.D. Alicke, D.A. Dunning, & J.I. Krueger (Eds.), ''The self in social judgment'' (pp.&nbsp;85 –108). Hove: Psychology.
* {{cite journal |last1=Allan |first1=LG |last2= Siegel|first2=S |last3=Hannah |first3=S |year=2007 |title= The sad truth about depressive realism |journal=The Quarterly Journal of Experimental Psychology |volume=60|issue=3 |pages=482–495 |url=http://psych.mcmaster.ca/hannahsd/pubs/AllanSiegelHannah%2707.pdf |ref={{harvid|Allan et al.|2007}} |doi=10.1080/17470210601002686 |pmid=17366313|s2cid=17018149 }}
* {{cite book|doi=10.1016/S0065-2601(08)60386-X|chapter=Situated Optimism: Specific Outcome Expectancies and Self-Regulation|title=Advances in Experimental Social Psychology|volume=30|pages=309–379|year=1998|last1=Armor|first1=David A.|last2=Taylor|first2=Shelley E.|isbn=9780120152308|chapter-url=http://behaviorchangeresearchnetwork.pbworks.com/w/file/fetch/48703842/Armor%20Taylor%201998.pdf|publisher=Elsevier}}
* {{cite book|doi=10.1017/CBO9780511808098.021|chapter=When Predictions Fail: The Dilemma of Unrealistic Optimism|title=Heuristics and Biases: The Psychology of Intuitive Judgment|pages=334–347|year=2002|last1=Armor|first1=David A.|last2=Taylor|first2=Shelley E.|isbn=9780511808098|editor1=T. Gilovich |editor2=D. Griffin |editor3=D. Kahneman|publisher=Cambridge University Press}}
* {{cite journal| last=Baumeister |first= R.F. |year=1989 |title= The optimal margin of illusion |journal=Journal of Social and Clinical Psychology |volume=8 |issue= 2 |pages= 176–189 |doi=10.1521/jscp.1989.8.2.176}}
* {{Cite journal|last1=Biglan|first1=Anthony|last2=Flay|first2=Brian R.|last3=Embry|first3=Dennis D.|last4=Sandler|first4=Irwin N.|date=2012|title=The Critical Role of Nurturing Environments for Promoting Human Wellbeing|journal=The American Psychologist|volume=67|issue=4|pages=257–271|doi=10.1037/a0026796|pmc=3621015|pmid=22583340}}
* {{cite journal |title=Depressive Realism: Happiness or Objectivity |journal=Turkish Journal of Psychiatry |year=2010 |volume=21 |issue=1 |pages=60–67 |url=http://www.turkpsikiyatri.com/PDF/C21S1/en/06.pdf |archive-url=https://web.archive.org/web/20120316133440/http://www.turkpsikiyatri.com/PDF/C21S1/en/06.pdf |url-status=dead |archive-date=2012-03-16 |pmid=20204905|last1=Birinci |first1=F |last2=Dirik |first2=G }}
* {{cite journal|pmid=15982117|year=2005|last1=Bonanno|first1=G. A.|title=Self-enhancement among high-exposure survivors of the September 11th terrorist attack: Resilience or social maladjustment?|journal=Journal of Personality and Social Psychology|volume=88|issue=6|pages=984–98|last2=Rennicke|first2=C|last3=Dekel|first3=S|doi=10.1037/0022-3514.88.6.984}}
* {{cite journal | last1 = Bower | first1 = J.E. | year = 1998 | title = Cognitive processing, discovery of meaning, CD 4 decline, and AIDS-related mortality among bereaved HIV-seropositive men | journal = Journal of Consulting and Clinical Psychology | volume = 66 | issue = 6| pages = 979–986  | doi = 10.1037/0022-006X.66.6.979 | pmid = 9874911 | last2 = Kemeny | first2 = ME | last3 = Taylor | first3 = SE | last4 = Fahey | first4 = JL  }}
* {{cite journal| first1=Belinda M. |last1=Boyd-Wilson |first2=Frank H. |last2=Walkey |first3= John|last3=McClure |first4= Dianne E. |last4=Green |date=December 2000 |title= Do we need positive illusions to carry out plans? Illusion: and instrumental coping |journal=Personality and Individual Differences| volume=29|issue= 6|pages= 1141–1152| doi=10.1016/S0191-8869(99)00261-5 |ref={{harvid|Boyd-Wilson et al.|2000}}}}
* {{cite journal | last1 = Brown | first1 = J.D. | year = 1986 | title = Evaluations of self and others: Self-enhancement biases in social judgements | journal = Social Cognition | volume = 4 | issue = 4| pages = 353–376 | doi = 10.1521/soco.1986.4.4.353  }}
*{{cite journal|doi=10.1037/0022-3514.67.3.366|title=Exploring the "planning fallacy": Why people underestimate their task completion times|journal=Journal of Personality and Social Psychology|volume=67|issue=3|pages=366–381|year=1994|last1=Buehler|first1=Roger|last2=Griffin|first2=Dale|last3=Ross|first3=Michael|s2cid=4222578}}
* {{cite journal | last1 = Campbell | first1 = J.D. | year = 1986 | title = Similarity and uniqueness: The effects of attribute type, relevance, and individual differences in self-esteem and depression | journal = Journal of Personality and Social Psychology | volume = 50 | issue = 2| pages = 281–294 | doi = 10.1037/0022-3514.50.2.281 | pmid = 3701578 }}
* {{cite journal|last1=Carson |first1=Richard C. |first2= Steven D. |last2=Hollon |first3= Richard C. |last3=Shelton |date=April 2010 |title= Depressive realism and clinical depression |journal=Behaviour Research and Therapy |volume=48 | issue=4  |pages=257–265 |ref={{harvid|Carson et al.|2010}} |doi=10.1016/j.brat.2009.11.011 |pmid=19963207}}
* {{cite journal |title=Do positive illusions foster mental health? An Examination of the Taylor and Brown Formulation |journal=Psychological Bulletin |year=1994 |volume=116 |issue=1 |pages=3–20 |url=http://www.radford.edu/~jaspelme/_private/gradsoc_articles/Depressive%20Realism/Covin%20n%20Block%20review.pdf |doi=10.1037/0033-2909.116.1.3 |pmid=8078973 |last1=Colvin |first1=C. R. |last2=Block |first2=J |access-date=2010-12-28 |archive-url=https://web.archive.org/web/20120304035204/http://www.radford.edu/~jaspelme/_private/gradsoc_artic
```

### Full section (plain rendering)
baum}}
*[John (1994) "Accuracy and bias in self-perception: Individual differences in self-e" doi:10.1037/0022-3514.66.1.206]
* [Joiner (2006) "On Seeing Clearly and Thriving: Interpersonal Perspicacity as Adaptive" doi:10.1521/jscp.2006.25.5.542]
* [Kruger (1999) "Lake Wobegon be gone! The below-average effect and the egocentric natu" doi:10.1037/0022-3514.77.2.221]
* [Kruger (2009) "(Not so) positive illusions" doi:10.1017/S0140525X09991270]
* [Kuiper (1982) "Depressed and nondepressed content self-reference in mild depression" doi:10.1111/j.1467-6494.1982.tb00746.x]
* [Leary (2007) "Motivational and emotional aspects of the self" doi:10.1146/annurev.psych.58.110405.085658]
* [Lewinsohn (1980) "Social competence and depression: The role of illusory self-perception" doi:10.1037/0021-843X.89.2.203]
*[McFarland (1982) "Impact of causal attributions on affective reactions to success and fa" doi:10.1037/0022-3514.43.5.937]
* [McKay (2009) "The evolution of misbelief" doi:10.1017/S0140525X09990975]
* [Moore (2007) "Not so above average after all: When people believe they are worse tha" doi:10.1016/j.obhdp.2006.09.005]
* [Moore (2007) "Depressive Realism and Attributional Style: Implications for Individua" doi:10.1016/j.beth.2006.06.003]
* [Moore (2012) "Depressive realism: A meta-analytic review" doi:10.1016/j.cpr.2012.05.004] 
* [Msetfi (2005) "Depressive realism and outcome density bias in contingency judgments: " doi:10.1037/0096-3445.134.1.10]
* [Msetfi (2007) "Depressive realism and the effect of intertrial interval on judgements" doi:10.1080/17470210601002595]
* [Nuttin (1987) "Affective consequences of mere ownership: The name letter effect in tw" doi:10.1002/ejsp.2420170402]
* [Owens (2007) "A critical review of self-perception and the positive illusory bias I " doi:10.1007/s10567-007-0027-3]
*[Robins (2001) "Positive illusions about the self: Short-term benefits and long-term c" doi:10.1037/0022-3514.80.2.340]
* [Ruehlman (1985) "Depression and evaluative schemata" doi:10.1111/j.1467-6494.1985.tb00888.x]
* [Sedikides (2008) "Self-enhancement: Food for thought" doi:10.1111/j.1745-6916.2008.00068.x]
* [Segerstrom (1998) "Optimism is associated with mood, coping, and immune change in respons" doi:10.1037/0022-3514.74.6.1646]
* [Svenson (1981) "Are we less risky and more skillful than our fellow drivers?" doi:10.1016/0001-6918(81)90005-6]
* [Swann (1987) "The cognitive-affective crossfire: When self-consistency confronts sel" doi:10.1037/0022-3514.52.5.881]
* [Taylor (1983) "Adjustment to threatening events: A theory of cognitive adaptation" doi:10.1037/0003-066X.38.11.1161]
* [Taylor (1988) "Illusion and well-being: A social psychological perspective on mental " doi:10.1037/0033-2909.103.2.193]
* [Taylor (1992) "Optimism, coping, psychological distress, and high-risk sexual behavio" doi:10.1037/0022-3514.63.3.460]
* [Taylor (1994) "Positive illusions and well-being revisited: Separating fact from fict" doi:10.1037/0033-2909.116.1.21]
* [Taylor (1995) "Effects of mindset on positive illusions" doi:10.1037/0022-3514.69.2.213]
* [Taylor (1996) "Positive illusions and coping with adversity" doi:10.1111/j.1467-6494.1996.tb00947.x]
* [Taylor (2000) "Psychological resources, positive illusions, and health" doi:10.1037/0003-066X.55.1.99]
* [Wenger (2008) "Positive Illusions in Parenting: Every Child Is Above Average" doi:10.1111/j.1559-1816.2007.00319.x]
*{{cite journal|doi=10.2466/PR0.105.3.727-737|pmid=20099534|title=Long-Term Costs of Inflated Self-Estimate on Academic Performance Among Adolescent Students: A Case of Second-Language Achievements1|journal=Psycho

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 8ae7ecd1c42737d7869c/article_plain.txt in the evidence directory.)

- There are controversies about the extent to which people reliably demonstrate positive illusions, as well as whether these illusions are beneficial to the people who have them. [ref: harvnb|Kruger|Chan|Roese|2009.] [ref: harvnb|McKay|Dennett|2009.] [ref: harvnb|Colvin|Block|1994.] [ref: harvnb|Birinci|Dirik|2010.]
- ==Benefits and liabilities==
Positive illusions can have advantages and disadvantages for the individual, and there is a controversy over whether they are evolutionarily adaptive. [ref: harvnb|McKay|Dennett|2009.] The illusions may have direct health benefits by helping the person cope with stress, or by promoting work towards success. [ref: harvnb|McKay|Dennett|2009.] On the other hand, unrealistically positive expectations may prevent people from taking sensible preventive action for medical risks. [ref: harvnb|Dunning|Heath|Suls|2004.] Research in 2001 provided evidence that people who have positive illusions may have both short term benefits and long term costs. Specifically, self-enhancement is not correlated with academic success or graduation rates in college. [ref: harvnb|Robins|Beer|2001.]
- When studying the link between self-esteem and positive illusions, identified a group which possessed high self-esteem without positive illusions, and that these individuals weren't depressed, neurotic, psychotic, maladjusted nor personality disordered, thus concluding that positive illusions aren't necessary for high self-esteem. Compared to the group with positive illusions and high self-esteem, the nonillusional group with high self-esteem was higher on self-criticism and personality integration and lower on psychoticism. [ref: Harvnb|Compton|1992.]
- A meta-analysis of 118 studies including 7013 subjects found that slightly more studies supported the idea of depressive realism, but these studies were poorer in quality, used non-clinical samples, were more readily generalized, used self-reports instead of interviews and used attentional bias or judgment of contingency as a method of measuring depressive realism, as methods such as recall of feedback and evaluation of performance showed results counter to depressive realism.
- Another recent meta-analysis supports Taylor and Browns central claim. Its results indicate that different forms of self-enhancement are positively linked to personal adjustment (high subjective well-being and low depressiveness). Self-enhancement was not only linked to self-ratings of personal adjustment, but also to adjustment ratings made by informants (including clinical experts). Furthermore, self-enhancement was also a longitudinal predictor of personal adjustment.
- However, these findings may not be because depressed people have fewer illusions than people who are not depressed. Studies such as show that depressed people believe they have no control in situations where they actually do, so their perspection is not more accurate overall. It might also be that the pessimistic bias of depressives results in "depressive realism" when, for example, measuring estimation of control when there is none, as proposed by . Also, and found that when replicating Alloy and Abramson's findings the overestimation of control in nondepressed people only showed up when the interval was long enough, implying that this is because they take more aspects of a situation into account than their depressed counterparts.
- * [Adelson (2005) "Probing the puzzling workings of 'depressive realism'"]
* [Alicke (1985) "Global self-evaluation as determined by the desirability and controlla" doi:10.1037/0022-3514.49.6.1621]
* Alicke, M.D., & Govorun, O. (2005). "The better-than-average effect." In M.D. Alicke, D.A. Dunning, & J.I. Krueger (Eds.), The self in social judgment (pp.&nbsp;85 –108). Hove: Psychology.
* [Allan (2007) "The sad truth about depressive realism" doi:10.1080/17470210601002686]
* [Armor (1998) "Advances in Experimental Social Psychology" doi:10.1016/S0065-2601(08)60386-X]
* [Armor (2002) "Heuristics and Biases: The Psychology of Intuitive Judgment" doi:10.1017/CBO9780511808098.021]
* [Baumeister (1989) "The optimal margin of illusion" doi:10.1521/jscp.1989.8.2.176]
* [Biglan (2012) "The Critical Role of Nurturing Environments for Promoting Human Wellbe" doi:10.1037/a0026796]
* [Birinci (2010) "Depressive Realism: Happiness or Objectivity"]
* [Bonanno (2005) "Self-enhancement among high-exposure survivors of the September 11th t" doi:10.1037/0022-3514.88.6.984]
* [Bower (1998) "Cognitive processing, discovery of meaning, CD 4 decline, and AIDS-rel" doi:10.1037/0022-006X.66.6.979]
* [Boyd-Wilson (2000) "Do we need positive illusions to carry out plans? Illusion: and instru" doi:10.1016/S0191-8869(99)00261-5]
* [Brown (1986) "Evaluations of self and others: Self-enhancement biases in social judg" doi:10.1521/soco.1986.4.4.353]
*[Buehler (1994) "Exploring the "planning fallacy": Why pe

## ORIGINAL STUDY: doi:10.1002/ejsp.2420170402 (FLoRA title: Affective consequences of mere ownership: The name letter effect in twelve European languages)
Crossref: Affective consequences of mere ownership: The name letter effect in twelve European languages | Jozef M. Nuttin | European Journal of Social Psychology | 1987 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W1972704792", "type": "article", "publication_year": 1987, "cited_by_count": 391, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: ABSTRACT
Retrieved: 2026-10-09T12:18:57+00:00
### Abstract (Crossref deposited abstract)
The hypothesis is tested that mere ownership of an object is a sufficient condition to enhance its likelihood to become one of the most attractive items of the entire set of similar objects. Evidence is presented that isolated visual letter stimuli belonging to one's own name are more often ranked among the six most preferred letters of the entire alphabet than identical not‐own name letters. Across 12 different European languages, an (own) name letter effect was found for (initial and/or not‐initial) letters belonging to own first and/or family name. The fundamental theoretical relevance of the effect is outlined as well as its heuristic value for research on individual versus collective ownership and on affective asymmetry. A cross‐lingual analysis of the six least preferred letters‐while also confirming the mere ownership hypothesis‐calls for a critical reformulation of Zajonc's mere exposure theory.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1016/j.jesp.2020.103972 (FLoRA title: Impact of ownership on liking and value: Replications and extensions of three ownership effect experiments; FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: Impact of ownership on liking and value: Replications and extensions of three ownership effect experiments | Ignazio Ziano, Jing Dan Yao, Yajing Gao, Gilad Feldman | Journal of Experimental Social Psychology | 2020 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W3028176939", "type": "article", "publication_year": 2020, "cited_by_count": 14, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1016_j_jesp_2020_103972.txt (Free copy found by source search (accepted manuscript): https://mgto.org/wp-content/uploads/2021/04/Ziano-Yao-Gao-Feldman-2020-JESP-Ownership-effect-replications-extensions-preprint-final.pdf)
Retrieved: 2026-10-09T12:18:58+00:00

## Other database studies cited on this same page (each has its own packet; drafted together)
- 56cb2612b28eac4d7fb7: Lake Wobegon be gone! The "below-average effect" and the egocentric nature of comparative ability judgments. (doi:10.1037/0022-3514.77.2.221)
- 098f4d519687b4aed607: Global self-evaluation as determined by the desirability and controllability of trait adjectives. (doi:10.1037/0022-3514.49.6.1621)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1002/ejsp.2889 | Owning leads to valuing: Meta‐analysis of the mere ownership effect | 2022 | read: abstract | mentions replication: False
- doi:10.1016/j.socec.2023.102058 | The effect of name letter on market prices: Field experiments on seller behavior | 2023 | read: metadata_only | mentions replication: False
- doi:10.1016/j.cpr.2010.05.002 | Implicit cognition and depression: A meta-analysis | 2010 | read: metadata_only | mentions replication: False
- doi:10.1371/journal.pone.0202873 | Indirect (implicit) and direct (explicit) self-esteem measures are virtually unrelated: A meta-analysis of the initial preference task | 2018 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_1371_journal_pone_0202873.txt
- doi:10.1007/s12144-022-03926-x | Names and individual differences: a systematic review | 2022 | read: metadata_only | mentions replication: False

## Other papers relevant to this page that the pipeline looked up
- doi:10.1111/j.1745-6916.2008.00068.x | Self-Enhancement: Food for Thought | paper cited in the article (not a database study) | read: abstract
  Abstract (Crossref): Self-enhancement denotes a class of psychological phenomena that involve taking a tendentiously positive view of oneself. We distinguish between four levels of self-enhancement—an observed effect, an ongoing process, a personality trait, and an underlying motive—and then use these distinctions to organize the wealth of relevant research. Furthermore, to render these distinctions intuitive, we draw an extended analogy between self-enhancement and the phenomenon of eating. Among the topics we address are (a) manifestations of self-enhancement, both obvious and subtle, and rival interpretations; (b) experimentally documented dynamics of affirming and threatening the ego; and (c) primacy of self-enhancement, considered alongside other intrapsychic phenomena, and across different cultures. Self-enhancement, like eating, is a fundamental part of human nature.

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1016/j.cpr.2010.05.002 | Implicit cognition and depression: A meta-analysis | 2010 | review | cited_by 183
  Abstract: (none)
- [review citing original] doi:10.1371/journal.pone.0202873 | Indirect (implicit) and direct (explicit) self-esteem measures are virtually unrelated: A meta-analysis of the initial preference task | 2018 | review | cited_by 16
  Abstract: BACKGROUND: The initial preference task (IPT) is an implicit measure that has featured prominently in the literature and enjoys high popularity because it offers to provide an unobtrusive and objective assessment of self-esteem that is easy to administer. However, its use for self-esteem assessment may be limited because of weak associations with direct personality measures. Moreover, moderator effects of sample- and study-related variables need investigation to determine the value of IPT-based assessments of self-esteem. METHODS: Conventional and grey-literature database searches, as well as screening of reference lists of obtained articles, yielded a total of 105 independent healthy adult samples (N = 17,777) originating from 60 studies. Summary effect estimates and subgroup analyses for potential effect moderators (e.g., administration order, algorithm, rating type) were calculated by means of meta-analytic random- and mixed-effects models. Moreover, we accounted for potential influences of publication year, publication status (published vs. not), and participant sex in a weighted stepwise hierarchical multiple meta-regression. We tested for dissemination bias through six method
- [review citing original] doi:10.1007/s12144-022-03926-x | Names and individual differences: a systematic review | 2022 | review | cited_by 3
  Abstract: (none)
- [cites original and replication 10.1016/j.jesp.2020.103972] doi:10.1002/ejsp.2889 | Owning leads to valuing: Meta‐analysis of the mere ownership effect | 2022 | article | cited_by 10
  Abstract: Abstract Mere ownership effect is the phenomenon that people tend to value what they own more than what they do not own. This classic effect is considered robust, yet effect sizes vary across studies, and the effect is often confused for or confounded with other classic phenomena, such as endowment or mere exposure effects. We conducted a pre‐registered meta‐analysis of 26 samples published before 2019 (N = 3024), which resulted in psychological ownership on valuing effect of g ∼ 0.57 [0.46, 0.69]. Suggestive moderator analyses supported the use of replica as the strongest moderators. Mere ownership effects were different from the null across all moderator categories and in most publication bias adjustments. We consider this as suggestive evidence that psychological owning leads to valuing, yet caution that much more research is needed. All materials, data, and codes are available on https://osf.io/fdyqw/ .
- [cites original and replication 10.1016/j.jesp.2020.103972] doi:10.1016/j.socec.2023.102058 | The effect of name letter on market prices: Field experiments on seller behavior | 2023 | article | cited_by 4
  Abstract: (none)
