# Evidence packet 7b3d33cc48f39207c3b6: List of Ig Nobel Prize winners

Frozen revision: 1376076686 (2026-09-21T22:53:52Z); https://en.wikipedia.org/w/index.php?oldid=1376076686
Live check: {"frozen_revid": "1376076686", "title": "List of Ig Nobel Prize winners", "live_revid": 1376076686, "live_timestamp": "2026-09-21T22:53:52Z", "checked_at": "2026-10-06T16:46:56+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "history_list", "context_kind": "inline", "living_person_category": false, "health_term_flag": true, "co_cited": false, "large_project": false, "flora_originals_on_page": 4}

## Article lead (plain rendering, approximate)
A parody of the Nobel Prizes, the Ig Nobel Prizes are awarded each year in mid-September, around the time the recipients of the genuine Nobel Prizes are announced, for ten achievements that "first make people laugh, and then make them think". Commenting on the 2006 awards, Marc Abrahams, editor of Annals of Improbable Research and co-sponsor of the awards, said that "[t]he prizes are intended to celebrate the unusual, honor the imaginative, and spur people's interest in science, medicine, and technology". [ref: (2006) "Teen repellent is Ig Nobel winner"] All prizes are awarded for real achievements, except for three in 1991 and one in 1994, due to an erroneous press release.

## Article outline
1991
  Apocryphal achievements
1992
1993
1994
  No longer officially listed
1995
1996
1997
1998
1999
2000
2001
2002
2003
2004
2005
2006
2007
2008
2009
2010
2011
2012
2013
2014
2015
2016
2017
2018
2019
2020
2021
2022
2023
2024
2025
2026
2027
People who received multiple Ig Nobel Prizes
Ig Nobel Prize winners who also received the Nobel Prize
Notes
References
External links

## Categories
Humor-related lists; Ig Nobel laureates; Ig Nobel Prize; Lists of award winners; Science and technology award winners

## Occurrence 1: original DOI 10.1038/oby.2005.12 in section '2007'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
{| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|-
| Aviation
| Patricia V. Agostino, Santiago A. Plano and Diego A. Golombek
| "for their discovery that Viagra aids jetlag recovery in hamsters"
| [ref: Agostino (2007) "Sildenafil accelerates reentrainment of circadian rhythms after advanc" doi:10.1073/pnas.0703388104]
|-
| Biology
| Johanna E.M.H. van Bronswijk
| "for doing a census of all the mites, insects, spiders, pseudoscorpions, crustaceans, bacteria, algae, ferns and fungi with whom we share our beds each night"
| [ref: van Bronswijk (1972) "Huis, bed en beestjes"] [ref: van Bronswijk (1973) "Het stof, de mijten en het bed"] [ref: Van De Lustgraaf (1978) "Autotrophic Organisms in Mattress Dust in the Netherlands" doi:10.1111/j.1438-8677.1978.tb00267.x]
|-
| Chemistry
| Mayu Yamamoto
| "for developing a way to extract vanillin – vanilla fragrance and flavoring – from cow dung"
| [ref: Yamamoto (2008) "Novel Production Method for Plant Polyphenol from Livestock Excrement " doi:10.1155/2008/603957]
|-
| Economics
| Kuo Cheng Hsieh
| "for patenting a device, in the year 2001, that catches bank robbers by dropping a net over them"
| [ref: (1999) "Net trapping system for capturing a robber immediately"]
|-
| Linguistics
| Juan Manuel Toro, Josep B. Trobalon and Núria Sebastián-Gallés
| "for showing that rats sometimes cannot tell the difference between a person speaking Japanese backwards and a person speaking Dutch backwards"
| [ref: Toro (2005) "Effects of backward speech and speaker variability in language discrim" doi:10.1037/0097-7403.31.1.95]
|-
| Literature
| Glenda Browne
| "for her study of the word the – and of the many ways it causes problems for anyone who tries to put things into alphabetical order"
| [ref: Browne (2001) "The definite article: acknowledging 'The' in index entries" doi:10.3828/indexer.2001.22.3.4]
|-
| Medicine
| Brian Witcombe and Dan Meyer
| "for their penetrating medical report Sword Swallowing and Its Side Effects"
| [ref: Witcombe (2006) "Sword swallowing and its side effects" doi:10.1136/bmj.39027.676690.55]
|-
| Nutrition
| Brian Wansink
| "for exploring the seemingly boundless appetites of human beings, by feeding them with a self-refilling, bottomless bowl of soup"
| [FOCAL REF: Wansink (2005) "Bottomless Bowls: Why Visual Cues of Portion Size May Influence Intake" doi:10.1038/oby.2005.12]
|-
| Peace
| Wright Laboratory in Dayton, Ohio
| "for instigating research & development on a chemical weapon – the so-called gay bomb – that will make enemy soldiers become sexually irresistible to each other"
| [ref: (1994) "Harassing, Annoying, and 'Bad Guy' Identifying Chemicals"]
|-
| Physics
| L. Mahadevan, and Enrique Cerda Villablanca
| "for studying how sheets become wrinkled"
| [ref: Cerda (2002) "Wrinkling of an elastic sheet under tension" doi:10.1038/419579b] [ref: Cerda (2003) "Geometry and Physics of Wrinkling" doi:10.1103/PhysRevLett.90.074302] [ref: Cerda (2004) "The elements of draping" doi:10.1073/pnas.0307160101]
|}

### Paragraph (raw wikitext)
```
{| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|-
| Aviation
| Patricia V. Agostino, Santiago A. Plano and [[Diego Golombek|Diego A. Golombek]]
| "for their discovery that [[Viagra]] aids [[jetlag]] recovery in hamsters"
| <ref>{{cite journal | last1=Agostino | first1=Patricia V. | last2=Plano | first2=Santiago A. | last3=Golombek | first3=Diego A. | title=Sildenafil accelerates reentrainment of circadian rhythms after advancing light schedules | journal=Proceedings of the National Academy of Sciences | volume=104 | issue=23 | date=2007-06-05 | pmid=17519328 | pmc=1887561 | doi=10.1073/pnas.0703388104 | doi-access=free | pages=9834–9839 | bibcode=2007PNAS..104.9834A }}</ref>
|-
| Biology
| Johanna E.M.H. van Bronswijk
| "for doing a census of all the mites, insects, spiders, pseudoscorpions, crustaceans, bacteria, algae, ferns and fungi with whom we share our beds each night"
| <ref>{{cite journal | last1=van Bronswijk |first1=J. E. M. H. |title=Huis, bed en beestjes |journal=Nederlands Tijdschrift voor Geneeskunde |volume=116 |issue=20 |pages=825–831 |year=1972 |url=https://repository.ubn.ru.nl/bitstream/handle/2066/148638/mmubn000001_153940972.pdf}}</ref><ref>{{cite journal | last1=van Bronswijk |first1=J. E. M. H. |title=Het stof, de mijten en het bed |journal=Vakblad voor Biologen |volume=53 |issue=2 |pages=22–25 |year=1973 }}</ref><ref>{{cite journal |last1=Van De Lustgraaf |first1=B. |last2=Klerkx |first2=J. H. H. M. |last3=Van Bronswijk |first3=J. E. M. H. |title=Autotrophic Organisms in Mattress Dust in the Netherlands |journal=Acta Botanica Neerlandica |date=April 1978 |volume=27 |issue=2 |pages=125–128 |doi=10.1111/j.1438-8677.1978.tb00267.x }}</ref>
|-
| Chemistry
| Mayu Yamamoto
| "for developing a way to extract [[vanillin]] – vanilla fragrance and flavoring – from cow dung"
| <ref>{{cite journal | last1=Yamamoto | first1=Mayu | last2=Futamura | first2=Yasuhiro | last3=Fujioka | first3=Kouki | last4=Yamamoto | first4=Kenji | title=Novel Production Method for Plant Polyphenol from Livestock Excrement Using Subcritical Water Reaction | journal=International Journal of Chemical Engineering | volume=2008 |year=2008 | doi=10.1155/2008/603957 | doi-access=free | pages=1–5}}</ref>{{efn|[[Toscanini's]], a well-known ice cream parlour based in [[Cambridge, Massachusetts]], introduced a new ice cream flavour at the Ig Nobel Ceremony in honour of Mayu Yamamoto's work, called "Yum-a-Moto Vanilla Twist".<ref>{{cite web | last=Moeliker | first=Kees | title=Salute the simple sword of truth | website=The Guardian | date=2007-10-09 | url=https://www.theguardian.com/education/2007/oct/09/research.highereducation | access-date=2025-12-21}}</ref>}}
|-
| Economics
| Kuo Cheng Hsieh
| "for patenting a device, in the year 2001, that catches [[bank robber]]s by dropping a net over them"
| <ref>{{cite web | title=Net trapping system for capturing a robber immediately | website=Google Patents | date=1999-11-04 | url=https://patents.google.com/patent/US6219959B1 | access-date=2025-12-21}}</ref>{{efn|name="ZoltanEgeresi"|Zoltan Egeresi, a Californian inventor, filed a similar patent for a net-trapping device in 2003, taking inspiration from Kuo Cheng Hsieh's 2001 anti-bank-robbing device (winner of the 2007 Ig Nobel Economics Prize) and simplifying Gustano Pizzo's anti-hijacking device from early 1970s (winner of the 2013 Ig Nobel Safety Engineering Prize).<ref>{{cite web | last=Abrahams | first=Marc | title=Caught in a trap | website=The Guardian | date=2008-01-15 | url=https://www.theguardian.com/education/2008/jan/15/highereducation.research1 | access-date=2025-12-21}}</ref>}}
|-
| Linguistics
| Juan Manuel Toro, Josep B. Trobalon and Núria Sebastián-Gallés
| "for showing that rats sometimes cannot tell the difference between a person speaking Japanese backwards and a person speaking Dutch backwards"
| <ref>{{cite journal | last1=Toro | first1=Juan M. | last2=Trobalon | first2=Josep B. | last3=Sebastián-Gallés | first3=Núria | title=Effects of backward speech and speaker variability in language discrimination by rats | journal=Journal of Experimental Psychology. Animal Behavior Processes | volume=31 | issue=1 |year=2005 | pmid=15656730 | doi=10.1037/0097-7403.31.1.95 | pages=95–100 }}</ref>
|-
| Literature
| Glenda Browne
| "for her study of the word ''the'' – and of the many ways it causes problems for anyone who tries to put things into alphabetical order"
| <ref>{{cite journal |last1=Browne |first1=Glenda |title=The definite article: acknowledging 'The' in index entries |journal=The Indexer |date=April 2001 |volume=22 |issue=3 |pages=119–122 |doi=10.3828/indexer.2001.22.3.4 }}</ref>
|-
| Medicine
| Brian Witcombe and Dan Meyer
| "for their penetrating medical report ''Sword Swallowing and Its Side Effects''"
| <ref>{{cite journal |last1=Witcombe |first1=Brian |last2=Meyer |first2=Dan |title=Sword swallowing and its side effects |journal=BMJ |date=23 December 2006 |volume=333 |issue=7582 |pages=1285–1287 |doi=10.1136/bmj.39027.676690.55 |pmid=17185708 |pmc=1761150 }}</ref>
|-
| Nutrition
| [[Brian Wansink]]
| "for exploring the seemingly [[mindless eating|boundless appetites]] of human beings, by feeding them with a self-refilling, bottomless bowl of soup"
| <ref>{{cite journal | last1=Wansink | first1=Brian | last2=Painter | first2=James E. | last3=North | first3=Jill | title=Bottomless Bowls: Why Visual Cues of Portion Size May Influence Intake | journal=Obesity Research | volume=13 | issue=1 |year=2005 | pmid=15761167 | doi=10.1038/oby.2005.12 | doi-access=free | pages=93–100 }}</ref>
|-
| Peace
| [[United States Air Force Research Laboratory|Wright Laboratory]] in [[Wright-Patterson Air Force Base|Dayton, Ohio]]
| "for instigating research & development on a chemical weapon – the so-called ''[[gay bomb]]'' – that will make enemy soldiers become sexually irresistible to each other"
```

### Full section (plain rendering)
==2007==
The ceremony took place on 4 October 2007.

{| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|-
| Aviation
| Patricia V. Agostino, Santiago A. Plano and Diego A. Golombek
| "for their discovery that Viagra aids jetlag recovery in hamsters"
| [ref: Agostino (2007) "Sildenafil accelerates reentrainment of circadian rhythms after advanc" doi:10.1073/pnas.0703388104]
|-
| Biology
| Johanna E.M.H. van Bronswijk
| "for doing a census of all the mites, insects, spiders, pseudoscorpions, crustaceans, bacteria, algae, ferns and fungi with whom we share our beds each night"
| [ref: van Bronswijk (1972) "Huis, bed en beestjes"] [ref: van Bronswijk (1973) "Het stof, de mijten en het bed"] [ref: Van De Lustgraaf (1978) "Autotrophic Organisms in Mattress Dust in the Netherlands" doi:10.1111/j.1438-8677.1978.tb00267.x]
|-
| Chemistry
| Mayu Yamamoto
| "for developing a way to extract vanillin – vanilla fragrance and flavoring – from cow dung"
| [ref: Yamamoto (2008) "Novel Production Method for Plant Polyphenol from Livestock Excrement " doi:10.1155/2008/603957]
|-
| Economics
| Kuo Cheng Hsieh
| "for patenting a device, in the year 2001, that catches bank robbers by dropping a net over them"
| [ref: (1999) "Net trapping system for capturing a robber immediately"]
|-
| Linguistics
| Juan Manuel Toro, Josep B. Trobalon and Núria Sebastián-Gallés
| "for showing that rats sometimes cannot tell the difference between a person speaking Japanese backwards and a person speaking Dutch backwards"
| [ref: Toro (2005) "Effects of backward speech and speaker variability in language discrim" doi:10.1037/0097-7403.31.1.95]
|-
| Literature
| Glenda Browne
| "for her study of the word the – and of the many ways it causes problems for anyone who tries to put things into alphabetical order"
| [ref: Browne (2001) "The definite article: acknowledging 'The' in index entries" doi:10.3828/indexer.2001.22.3.4]
|-
| Medicine
| Brian Witcombe and Dan Meyer
| "for their penetrating medical report Sword Swallowing and Its Side Effects"
| [ref: Witcombe (2006) "Sword swallowing and its side effects" doi:10.1136/bmj.39027.676690.55]
|-
| Nutrition
| Brian Wansink
| "for exploring the seemingly boundless appetites of human beings, by feeding them with a self-refilling, bottomless bowl of soup"
| [FOCAL REF: Wansink (2005) "Bottomless Bowls: Why Visual Cues of Portion Size May Influence Intake" doi:10.1038/oby.2005.12]
|-
| Peace
| Wright Laboratory in Dayton, Ohio
| "for instigating research & development on a chemical weapon – the so-called gay bomb – that will make enemy soldiers become sexually irresistible to each other"
| [ref: (1994) "Harassing, Annoying, and 'Bad Guy' Identifying Chemicals"]
|-
| Physics
| L. Mahadevan, and Enrique Cerda Villablanca
| "for studying how sheets become wrinkled"
| [ref: Cerda (2002) "Wrinkling of an elastic sheet under tension" doi:10.1038/419579b] [ref: Cerda (2003) "Geometry and Physics of Wrinkling" doi:10.1103/PhysRevLett.90.074302] [ref: Cerda (2004) "The elements of draping" doi:10.1073/pnas.0307160101]
|}

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 7b3d33cc48f39207c3b6/article_plain.txt in the evidence directory.)

- {| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Reproduction
| Ahmed Shafik 
| "for studying the effects of wearing polyester, cotton, or wool trousers on the sex life of rats, and for conducting similar tests with human males"
| [ref: Shafik (1993) "Effect of Different Types of Textiles on Sexual Activity" doi:10.1159/000474332] [ref: Shafik (1992) "Contraceptive efficacy of polyester-induced azoospermia in normal men" doi:10.1016/0010-7824(92)90157-O]
|-
| Economics
| Mark Avis, Sarah Forbes, and Shelagh Ferguson
| "for assessing the perceived personalities of rocks, from a sales and marketing perspective"
| [ref: Avis (2014) "The brand personality of rocks: A critical evaluation of a brand perso" doi:10.1177/1470593113512323]
|-
| Physics
| Gábor Horváth, Miklós Blahó, György Kriska, Ramón Hegedüs, Balázs Gerics, Róbert Farkas, Susanne Åkesson, Péter Malik, and Hansruedi Wildermuth
| "for discovering why white-haired horses are the most horsefly-proof horses, and for discovering why dragonflies are fatally attracted to black tombstones"
| [ref: Horváth (2010) "An unexpected advantage of whiteness in horses: the most horsefly-proo" doi:10.1098/rspb.2009.2202] [ref: Horváth (2007) "Ecological traps for dragonflies in a cemetery: the attraction of Symp" doi:10.1111/j.1365-2427.2007.01798.x]
|-
| Chemistry
| Volkswagen
| "for solving the problem of excessive 
- {| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Medicine
| Marc Mitchell and David Wartinger
| "for using roller coaster rides to try to hasten the passage of kidney stones"
| [ref: Mitchell (2016) "Validation of a Functional Pyelocalyceal Renal Model for the Evaluatio" doi:10.7556/jaoa.2016.128]
|-
| Anthropology
| Tomas Persson, Gabriela-Alina Sauciuc, and Elainie Madsen
| "for collecting evidence, in a zoo, that chimpanzees imitate humans about as often, and about as well, as humans imitate chimpanzees"
| [ref: Persson (2018) "Spontaneous cross-species imitation in interactions between chimpanzee" doi:10.1007/s10329-017-0624-9]
|-
| Biology
| Paul Becher, Sebastien Lebreton, Erika Wallin, Erik Hedenstrom, Felipe Borrero-Echeverry, Marie Bengtsson, Volker Jorger, and Peter Witzgall
| "for demonstrating that wine experts can reliably identify, by smell, the presence of a single fly in a glass of wine"
| [ref: Becher (2018) "The Scent of the Fly" doi:10.1007/s10886-018-0950-4] 
|-
| Chemistry
| Paula Romão, Adília Alarcão and the late César Viana
| "for measuring the degree to which human saliva is a good cleaning agent for dirty surfaces"
| [ref: Romão (1990) "Human saliva as a cleaning agent for dirty surfaces" doi:10.1179/sic.1990.35.3.153]
|-
| Medical Education
| Akira Horiuchi
| "for the medical report Colonoscopy in the Sitting Position: Lessons Learn
- {| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Acoustics
| Stephan Reber, Takeshi Nishimura, Judith Janisch, Mark Robertson, and Tecumseh Fitch,
| "for inducing a female Chinese alligator to bellow in an airtight chamber filled with helium-enriched air"
| [ref: Reber (2015) "A Chinese alligator in heliox: formant frequencies in a crocodilian" doi:10.1242/jeb.119552]
|-
| Economics
| Christopher Watkins, Juan David Leongómez, Jeanne Bovet, Agnieszka Żelaźniewicz, Max Korbmacher, Marco Antônio Corrêa Varella, Ana Maria Fernandez, Danielle Wagstaff, and Samuela Bolgan
| "for trying to quantify the relationship between different countries' national income inequality and the average amount of mouth-to-mouth kissing"
| [ref: Watkins (2019) "National income inequality predicts cultural variation in mouth to mou" doi:10.1038/s41598-019-43267-7]
|-
| Entomology
| Richard Vetter
| "for collecting evidence that many entomologists (scientists who study insects) are afraid of spiders, which are not insects"
| [ref: Vetter (2013) "Arachnophobic Entomologists: When Two More Legs Makes a Big Difference" doi:10.1093/ae/59.3.168]
|-
| Management
| Xi Guang-An, Mo Tian-Xiang, Yang Kang-Sheng, Yang Guang-Sheng, and Ling Xian Si
| "five professional hitmen in Guangxi, China, who managed a contract for a hit job (a murder performed for money) in the following way: After acceptin

## ORIGINAL STUDY: doi:10.1038/oby.2005.12 (FLoRA title: Bottomless Bowls: Why Visual Cues of Portion Size May Influence Intake**)
Crossref: Bottomless Bowls: Why Visual Cues of Portion Size May Influence Intake
                    <sup>**</sup> | Brian Wansink, James E. Painter, Jill North | Obesity Research | 2005 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2140614509", "type": "article", "publication_year": 2005, "cited_by_count": 507, "is_retracted": false, "oa_status": "bronze", "oa_pdf": "https://onlinelibrary.wiley.com/doi/pdfdirect/10.1038/oby.2005.12", "oa_landing": "https://doi.org/10.1038/oby.2005.12"}
Evidence level available to you: ABSTRACT
Retrieved: 2026-10-06T16:17:14+00:00
### Abstract (Crossref deposited abstract)
Objective: 
                    Using self‐refilling soup bowls, this study examined whether visual cues related to portion size can influence intake volume without altering either estimated intake or satiation.
                   
                   
                     Research Methods and Procedures: 
                    Fifty‐four participants (BMI, 17.3 to 36.0 kg/m
                     2 
                    ; 18 to 46 years of age) were recruited to participate in a study involving soup. The experiment was a between‐subject design with two visibility levels: 1) an
                     accurate 
                    visual cue of a food portion (normal bowl) vs. 2) a
                     biased 
                    visual cue (self‐refilling bowl). The soup apparatus was housed in a modified restaurant‐style table in which two of four bowls slowly and imperceptibly refilled as their contents were consumed. Outcomes included intake volume, intake estimation, consumption monitoring, and satiety.
                   
                   
                     Results: 
                    Participants who were unknowingly eating from self‐refilling bowls ate more soup [14.7 ± 8.4 vs. 8.5 ± 6.1 oz;
                     F 
                    (1,52) = 8.99;
                     p 
                    < 0.01] than those eating from normal soup bowls. However, despite consuming 73% more, they did not believe they had consumed more, nor did they perceive themselves as more sated than those eating from normal bowls. This was unaffected by BMI.
                   
                   
                     Discussion: 
                    These findings are consistent with the notion that the amount of food on a plate or bowl increases intake because it influences consumption norms and expectations and it lessens one's reliance on self‐monitoring. It seems that people use their eyes to count calories and not their stomachs. The importance of having salient, accurate visual cues can play an important role in the prevention of unintentional overeating.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1037/xge0001503 (FLoRA title: Visual cues and food intake: A preregistered replication of Wansink et al. (2005).; FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: Visual cues and food intake: A preregistered replication of Wansink et al. (2005). | Alejandra Lopez, Alyssa K. Choi, Nadia C. Dellawar, Brooke C. Cullen, Sonia Avila Contreras, Daniel L. Rosenfeld et al. | Journal of Experimental Psychology: General | 2024 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W4388281251", "type": "article", "publication_year": 2023, "cited_by_count": 3, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: ABSTRACT
Retrieved: 2026-10-06T16:17:15+00:00
### Abstract (Europe PMC abstract)
Imagine a bowl of soup that never emptied, no matter how many spoonfuls you ate-when and how would you know to stop eating? Satiation can play a role in regulating eating behavior, but research suggests visual cues may be just as important. In a seminal study by Wansink et al. (2005), researchers used self-refilling bowls to assess how visual cues of portion size would influence intake. The study found that participants who unknowingly ate from self-refilling bowls ate more soup than did participants eating from normal (not self-refilling) bowls. Despite consuming 73% more soup, however, participants in the self-refilling condition did not believe they had consumed more soup, nor did they perceive themselves as more satiated than did participants eating from normal bowls. Given recent concerns regarding the validity of research from the Wansink lab, we conducted a preregistered direct replication study of Wansink et al. (2005) with a more highly powered sample ( N  = 464 vs. 54 in the original study). We found that most results replicated, albeit with half the effect size ( d  = 0.45 instead of 0.84), with participants in the self-refilling bowl condition eating significantly more soup than those in the control condition. Like the original study, participants in the self-refilling condition did not believe they had consumed any more soup than participants in the control condition. These results suggest that eating can be strongly controlled by visual cues, which can even override satiation. (PsycInfo Database Record (c) 2024 APA, all rights reserved).

## Other database studies cited on this same page (each has its own packet; drafted together)
- 2fd9886968cf6c26751b: Higher social class predicts increased unethical behavior (doi:10.1073/pnas.1118373109)
- f84ff1fe303855ec730c: Inhibiting and facilitating conditions of the human smile: A nonobtrusive test of the facial feedback hypothesis. (doi:10.1037/0022-3514.54.5.768)
- 7d53a3ae7f8f425cfab6: On the reception and detection of pseudo-profound bullshit (doi:10.1017/s1930297500006999)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1016/j.cub.2025.05.067 | A simple action reduces high-fat diet intake and obesity in mice | 2025 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_1016_j_cub_2025_05_067.txt
  Snippet: davis, j.d. (1977). set points, settling points, and the and interventions. curr. obes. rep. 6, 10-17. https://doi.org/10.1007/ control of body weight. physiol. behav. 19, 75-78. https://doi.org/10. s13679-017-0239-x. 1016/0031-9384(77)90162-7. 35. lopez, a., choi, a.k., dellawar, n.c., cullen, b.c., avila contreras, s., rosenfeld, d.l., and tomiyama, a.j. (2024). visual cues and food intake: 54. speakman, j.r., levitsky, d.a., allison, d.b., bray, m.s., de castro, j.m., a preregistered replication
- doi:10.1146/annurev.nutr.24.012003.132140 | ENVIRONMENTAL FACTORS THAT INCREASE THE FOOD INTAKE AND CONSUMPTION VOLUME OF UNKNOWING CONSUMERS | 2004 | read: abstract | mentions replication: False
- doi:10.1186/s12889-016-3272-x | The efficacy of nudge theory strategies in influencing adult dietary behaviour: a systematic review and meta-analysis | 2016 | read: abstract | mentions replication: False
- doi:10.3945/ajcn.112.045245 | Eating attentively: a systematic review and meta-analysis of the effect of food intake memory and awareness on eating | 2013 | read: metadata_only | mentions replication: False
- doi:10.1021/cr900105w | Molecular Gastronomy: A New Emerging Scientific Discipline | 2010 | read: abstract | mentions replication: False

## Other papers relevant to this page that the pipeline looked up
- doi:10.3389/fpsyg.2017.00702 | From Data to Truth in Psychological Science. A Personal Perspective. | paper cited in the article (not a database study) | read: abstract
  Abstract (Semantic Scholar): Over 30 years ago, Leonard Martin, Sabine Stepper, and I (Strack et al., 1988) conducted two studies to test the “facial feedback” hypothesis (Darwin, 1872). At the time, the hypothesis itself, namely that facial expressionsmay affect emotional experiences, was well established and frequently tested (e.g., Leventhal andMace, 1970; Laird, 1974). However, the underlying mechanism remained largely unexplored. On the one hand, the feedback could have been mediated by an inference from the emotional meaning of the expression to the underlying emotional state. On the other hand it could have been a more direct mechanism that does not involve any inferences. To resolve this ambiguity, we attempted to eliminate the inferential route by preventing participants from interpreting their facial action as “a smile.” This was accomplished by having participants holding a pen either between their protruded lips, which prevents smiling, or between their teeth, which facilitates it. Holding the pen in either of these positions, participants had to perform a series of tasks, among them a rating of the funniness of cartoons. As predicted, the cartoons were rated to be funnier if the pen was held between the teeth than between the lips. The effect was not strong but met the standard criteria of significance. The resulting “pen study” was meant neither to demonstrate a cute phenomenon nor to identify a powerful intervention to improve people’s feelings. Instead, it was intended to be one piece in the theoretical puzzle. This was underscored in the last sentence of the original article: “Obviously, more research is needed to understand the exact mechanisms that are responsible for facial feedback. In this endeavor, an alternative methodology that eliminates possible confounds may be helpful (p. 776).” Since 1988, more research on facial feedback has been conducted (Laird and Lacasse, 2014) and even a new methodology was introduced that was robust enough to even afford therapeutic interventions, namely the suppression (injecting Botox) of the corrugator muscle, which contracts the eyebrows and is implied in negative emotions (Finzi and Rosenthal, 2016). In 2013, I volunteered to be part of a Registered Replication Report project and submitted the experimental materials. In September 2016, the results came out (Wagenmakers et al., 2016). Seventeen replication groups had tested 1,894 participants. For nine groups, the result was in the predicted direction, for eight groups in the opposite direction. Overall, there was no significant effect.

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1146/annurev.nutr.24.012003.132140 | ENVIRONMENTAL FACTORS THAT INCREASE THE FOOD INTAKE AND CONSUMPTION VOLUME OF UNKNOWING CONSUMERS | 2004 | review | cited_by 1046
  Abstract: Package size, plate shape, lighting, socializing, and variety are only a few of the environmental factors that can influence the consumption volume of food far more than most people realize. Although such environmental factors appear unrelated, they generally influence consumption volume by inhibiting consumption monitoring and by suggesting alternative consumption norms. For researchers, this review suggests that redirecting the focus of investigations to the psychological mechanisms behind consumption will raise the profile and impact of research. For health professionals, this review underscores how small structural changes in personal environments can reduce the unknowing overconsumption of food.
- [review citing original] doi:10.1186/s12889-016-3272-x | The efficacy of nudge theory strategies in influencing adult dietary behaviour: a systematic review and meta-analysis | 2016 | review | cited_by 525
  Abstract: BACKGROUND: Obesity has become a world-wide epidemic and is spreading to countries with emerging economies. Previously tested interventions are often too costly to maintain in the long term. This leaves a need for improved strategies for management of the epidemic. Nudge Theory presents a new collection of methods, deemed "nudges", which have the potential for low-cost and broad application to guide healthier lifestyle choices without the need for restrictive regulation. There has not yet been a large-scale examination of the effectiveness of nudges, despite several policy making bodies now considering their use. METHODS: To address this gap in knowledge, an adapted systematic review methodology was used to collect and consolidate results from current Nudge papers and to determine whether Nudge strategies are successful in changing adults' dietary choices for healthier ones. RESULTS: It was found that nudges resulted in an average 15.3 % increase in healthier dietary or nutritional choices, as measured by a change in frequency of healthy choices or a change in overall caloric consumption. All of the included studies were from wealthy nations, with a particular emphasis on the Unite
- [review citing original] doi:10.3945/ajcn.112.045245 | Eating attentively: a systematic review and meta-analysis of the effect of food intake memory and awareness on eating | 2013 | review | cited_by 264
  Abstract: (none)
- [review citing original] doi:10.1021/cr900105w | Molecular Gastronomy: A New Emerging Scientific Discipline | 2010 | review | cited_by 230
  Abstract: ADVERTISEMENT RETURN TO ISSUEPREVReviewNEXTMolecular Gastronomy: A New Emerging Scientific DisciplinePeter Barham†‡, Leif H. Skibsted‡, Wender L. P. Bredie‡, Michael Bom Frøst‡, Per Møller‡, Jens Risbo‡, Pia Snitkjær‡, and Louise Mørch Mortensen‡View Author Information Department of Physics, University of Bristol, H. H. Wills Physics Laboratory, Tyndall Avenue, Bristol, United Kingdom BS8 1TL and Department of Zoology, University of Cape Town, Rondebosch, 7701 Cape Town, South Africa and Department of Food Science, University of Copenhagen, Rolighedsvej 30, DK-1958, Frederiksberg, Denmark* To whom correspondence should be addressed. E-mail: [email protected]†University of Bristol and University of Cape Town.‡University of Copenhagen.Cite this: Chem. Rev. 2010, 110, 4, 2313–2365Publication Date (Web):February 19, 2010Publication History Received18 March 2009Published online19 February 2010Published inissue 14 April 2010https://doi.org/10.1021/cr900105wCopyright © 2010 American Chemical SocietyRIGHTS & PERMISSIONSACS AuthorChoiceArticle Views53501Altmetric-Citations129LEARN ABOUT THESE METRICSArticle Views are the COUNTER-compliant sum of full text article downloads since November 20
- [review citing original] doi:10.1038/nrendo.2010.41 | Slow food, fast food and the control of food intake | 2010 | review | cited_by 159
  Abstract: (none)
- [cites original and replication 10.1037/xge0001503] doi:10.1016/j.cub.2025.05.067 | A simple action reduces high-fat diet intake and obesity in mice | 2025 | article | cited_by 14
  Abstract: Diets that are high in fat cause overeating and weight gain in multiple species of animals, suggesting that high dietary fat is sufficient to cause obesity. However, high-fat diets are typically provided freely to animals in obesity experiments, so it remains unclear whether high-fat diets would still cause obesity if these diets required more effort to obtain. We hypothesized that unrestricted access to high-fat diets is important for these diets to induce overeating and that requiring mice to perform small amounts of work to obtain a high-fat diet would reduce calorie intake and associated weight gain. To test this hypothesis, we developed a novel home-cage-based feeding device that provided the high-fat diet in two conditions: either freely or after mice poked their noses into a port one time-a simple action that is easy for them to do. Consistent with our hypothesis, requiring mice to nose-poke reduced high-fat diet intake and nearly completely prevented weight gain. Requiring mice to nose-poke also reduced low-fat grain-based pellet intake, confirming that this is a general mechanism governing food choice and not something specific to a high-fat diet. We conclude that unrestri
