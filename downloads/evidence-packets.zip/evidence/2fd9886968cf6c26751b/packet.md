# Evidence packet 2fd9886968cf6c26751b: List of Ig Nobel Prize winners

Frozen revision: 1376076686 (2026-09-21T22:53:52Z); https://en.wikipedia.org/w/index.php?oldid=1376076686
Live check: {"frozen_revid": "1376076686", "title": "List of Ig Nobel Prize winners", "live_revid": 1376076686, "live_timestamp": "2026-09-21T22:53:52Z", "checked_at": "2026-10-06T16:46:56+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "history_list", "context_kind": "inline", "living_person_category": false, "health_term_flag": true, "co_cited": false, "large_project": false, "flora_originals_on_page": 4}

## Article lead (plain rendering, approximate)
A parody of the Nobel Prizes, the Ig Nobel Prizes are awarded each year in mid-September, around the time the recipients of the genuine Nobel Prizes are announced, for ten achievements that "first make people laugh, and then make them think". Commenting on the 2006 awards, Marc Abrahams, editor of Annals of Improbable Research and co-sponsor of the awards, said that "[t]he prizes are intended to celebrate the unusual, honor the imaginative, and spur people's interest in science, medicine, and technology". [ref: (2006) "Teen repellent is Ig Nobel winner"] All prizes are awarded for real achievements, except for three in 1991 and one in 1994, due to an erroneous press release.

## Article outline
1991
  Apocryphal achievements
1992
1993
1994
  No longer officially listed
1995
1996
1997
1998
1999
2000
2001
2002
2003
2004
2005
2006
2007
2008
2009
2010
2011
2012
2013
2014
2015
2016
2017
2018
2019
2020
2021
2022
2023
2024
2025
2026
2027
People who received multiple Ig Nobel Prizes
Ig Nobel Prize winners who also received the Nobel Prize
Notes
References
External links

## Categories
Humor-related lists; Ig Nobel laureates; Ig Nobel Prize; Lists of award winners; Science and technology award winners

## Occurrence 1: original DOI 10.1073/pnas.1118373109 in section '2026'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
{| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Research
! scope="col"| Refs
|- 
| Biomechanics
| Matilda Brindle, Catherine Talbot, Stuart West (UK, USA)
| "Devising a more precise definition of kissing – non-agonistic interactions involving directed, intraspecific, oral-oral contact with some movement of the lips/mouthparts and no food transfer" – in ants, polar bears, and humans.
| A comparative approach to the evolution of kissing
| [ref: Brindle (2026) "A comparative approach to the evolution of kissing" doi:10.1016/j.evolhumbehav.2025.106788]
|-
| Economics
| Paul Piff, Daniel Stancato, Stephane Cote, Rodolfo Mendoza-Denton, Dacher Keltner (USA, Mexico, Canada)
| "Amassing evidence that upper-class people are more likely to snatch from a children's candy, and engage in other kinds of unethical behavior."
| Higher social class predicts increased unethical behavior
| [FOCAL REF: Piff (2012) "Higher social class predicts increased unethical behavior" doi:10.1073/pnas.1118373109]
|-
| Chemistry
| Sanchari Banerjee, Nathan Coussens, Francois-Xavier Gallat, Nitish Sathyanarayanan, Jandhyam Srikanth, Koichiro Yagi, James Gray, Steven Tobe, Barbara Stay, Leonard Chavas, Sumabramanian Ramaswamy (India, France, Japan, USA)
| "Discovering that milk proteins from viviparous cockroaches contains 3 times as much energy as milk proteins than from cows."
| Structure of heterogeneous, glycosylated, lipid-bound, in vivo-grown protein crystal at atomic resolution from the viviparous cockroach Diploptera punctata.
| 
|-
| Medicine
| Tokuji Unno, accepted by Dr. Miki Takahara (Japan)
| "How to Blow the Nose – An Aerodynamic Study of the Nose-Blowing"
|
| [ref: Unno (1977) "How to Blow the Nose" doi:10.3950/jibiinkoka.80.11]
|-
| Biology
| Joao Miguel Alvez-Nunes, Adriano Fellone, Selma Maria Almeida-Santos, Carlos Roberto de Medeiros, Ivan Sazima, Otávio Augusto Vuolo Marques (Brazil, Australia)
| "Gently stepping on various parts of various venomous snakes repeatedly, at various temperatures, at various times of day – to try to learn what does and what does not induce a venomous snake to bite a human."
| Study of defensive behavior of a venomous snake as a new approach to understand snakebite
| [ref: Jones (2024) "Snakebite researcher steps on vipers 40,000 times"]
|-
| Physics
| Randy Hurd, Zhao Pan, Tadd Truscott, Kaveeshan Thurairajah (Canada, USA, China, Saudi Arabia)
| "Theoretical and experimental attempts to design a splash-free urinal."
| Splash-free urinals for global sustainability and accessibility: Design through physics and differential equations
| [ref: Ouellette (2022) "What's the best design for splash-free urinal? Physics now has the ans"]
|-
| Technology
| Justin Puma, Zhen Yang, Evan Johnston, Zixin Zhang, Xiaoyi Lan, Lingzhi Zhang, Hongyu Hou, Zixin He, Ali Afify, Megan Creighton, Jianyu Li, and Changhong Cao (China, Canada, USA, Egypt)
| "Pioneering the use of mosquito proboscises as high-resolution 3D printing nozzles, a process called Necroprinting."
| 3D necroprinting: Leveraging biotic material as the nozzle for 3D printing
| 
|-
| Olfaction
| Ilona Croy, Tomasz Frackowiak, Thomas Hummel, and Agnieszka Sorokowska (Poland, Germany, Sweden)
| "Collecting evidence that babies smell wonderful to their parents but teenagers do not."
| Babies Smell Wonderful to Their Parents, Teenagers Do Not: an Exploratory Questionnaire Study on Children’s Age and Personal Odor Ratings in a Polish Sample
| 
|-
| Peace
| Jaimie Arona Krems, Rebecka Hahnel-Peeters, Laureon Merrie, Keelah Williams, and Daniel Sznycer (USA, Argentina, Australia)
| "We value friends who are vicious to people we dislike"
| Sometimes we want vicious friends: People have nuanced preferences for how they want their friends to behave toward them versus others
| 
|-
| Soil Science
| Franz Bender, Marcel van der Heijden, Atlant Bieri, and Pia Viviani (Switzerland, The Netherlands, Germany)
| "Burying 1,000 identical pairs of underpants in more than 25 countries then digging them up after 2 months"
| Soil health assessment using buried cotton underpants with the help of 1000 citizen scientists
| 
|-
|}

### Paragraph (raw wikitext)
```
<!-- The table below was populated during the ceremony livestream and has errors + missing data. Please correct as appropriate -->
{| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Research
! scope="col"| Refs
|- 
| Biomechanics
| Matilda Brindle, Catherine Talbot, [[Stuart West]] (UK, USA)
| "Devising a more precise definition of kissing – non-agonistic interactions involving directed, intraspecific, oral-oral contact with some movement of the lips/mouthparts and no food transfer" – in ants, polar bears, and humans.
| A comparative approach to the evolution of kissing
| <ref>{{cite journal |last1=Brindle |first1=Matilda |last2=Talbot |first2=Catherine F. |last3=West |first3=Stuart |title=A comparative approach to the evolution of kissing |journal=Evolution and Human Behavior |date=January 2026 |volume=47 |issue=1 |article-number=106788 |doi=10.1016/j.evolhumbehav.2025.106788 |pmid=42306775 |pmc=7619187 |bibcode=2026EHumB..4706788B }}</ref>
|-
| Economics
| [[Paul Piff]], Daniel Stancato, Stephane Cote, Rodolfo Mendoza-Denton, Dacher Keltner (USA, Mexico, Canada)
| "Amassing evidence that upper-class people are more likely to snatch from a children's candy, and engage in other kinds of unethical behavior."
| Higher social class predicts increased unethical behavior
| <ref>{{cite journal |last1=Piff |first1=Paul K. |last2=Stancato |first2=Daniel M. |last3=Côté |first3=Stéphane |last4=Mendoza-Denton |first4=Rodolfo |last5=Keltner |first5=Dacher |title=Higher social class predicts increased unethical behavior |journal=Proceedings of the National Academy of Sciences |date=13 March 2012 |volume=109 |issue=11 |pages=4086–4091 |doi=10.1073/pnas.1118373109 |doi-access=free |pmid=22371585 |pmc=3306667 |bibcode=2012PNAS..109.4086P }}</ref>
|-
| Chemistry
| Sanchari Banerjee, Nathan Coussens, Francois-Xavier Gallat, Nitish Sathyanarayanan, Jandhyam Srikanth, Koichiro Yagi, James Gray, Steven Tobe, Barbara Stay, Leonard Chavas, Sumabramanian Ramaswamy (India, France, Japan, USA)
| "Discovering that milk proteins from viviparous cockroaches contains 3 times as much energy as milk proteins than from cows."
| Structure of heterogeneous, glycosylated, lipid-bound, in vivo-grown protein crystal at atomic resolution from the viviparous cockroach Diploptera punctata.
| 
|-
| Medicine
| Tokuji Unno, accepted by Dr. Miki Takahara (Japan)
| "How to Blow the Nose – An Aerodynamic Study of the Nose-Blowing"
|
| <ref>{{Cite journal |last=Unno |first=Tokuji |last2=Yajima |first2=Hiroshi |date=1977 |title=How to Blow the Nose |url=https://www.jstage.jst.go.jp/article/jibiinkoka1947/80/1/80_1_11/_article |journal=Nippon Jibiinkoka Gakkai Kaiho |volume=80 |issue=1 |pages=11–17 |doi=10.3950/jibiinkoka.80.11}}</ref>
|-
| Biology
| Joao Miguel Alvez-Nunes, Adriano Fellone, [[Selma Maria Almeida-Santos]], Carlos Roberto de Medeiros, [[Ivan Sazima]], [[Otávio Augusto Vuolo Marques]] (Brazil, Australia)
| "Gently stepping on various parts of various venomous snakes repeatedly, at various temperatures, at various times of day – to try to learn what does and what does not induce a venomous snake to bite a human."
| Study of defensive behavior of a venomous snake as a new approach to understand snakebite
| <ref>{{cite news |last1=Jones |first1=Timothy |title=Snakebite researcher steps on vipers 40,000 times |url=https://www.dw.com/en/snakebite-researcher-steps-on-vipers-40000-times/a-69124376 |work=dw.com |date=19 May 2024 }}</ref>
|-
| Physics
| Randy Hurd, Zhao Pan, Tadd Truscott, Kaveeshan Thurairajah (Canada, USA, China, Saudi Arabia)
| "Theoretical and experimental attempts to design a splash-free urinal."
| Splash-free urinals for global sustainability and accessibility: Design through physics and differential equations
| <ref>{{cite news |last1=Ouellette |first1=Jennifer |title=What's the best design for splash-free urinal? Physics now has the answer |url=https://arstechnica.com/science/2022/11/the-angle-at-which-dogs-pee-inspired-optimal-design-for-splash-free-urinal/ |work=Ars Technica |date=28 November 2022 }}</ref>
|-
| Technology
| Justin Puma, Zhen Yang, Evan Johnston, Zixin Zhang, Xiaoyi Lan, Lingzhi Zhang, Hongyu Hou, Zixin He, Ali Afify, Megan Creighton, Jianyu Li, and Changhong Cao (China, Canada, USA, Egypt)
| "Pioneering the use of mosquito proboscises as high-resolution 3D printing nozzles, a process called Necroprinting."
| 3D necroprinting: Leveraging biotic material as the nozzle for 3D printing
| 
|-
| Olfaction
| Ilona Croy, Tomasz Frackowiak, Thomas Hummel, and Agnieszka Sorokowska (Poland, Germany, Sweden)
| "Collecting evidence that babies smell wonderful to their parents but teenagers do not."
| Babies Smell Wonderful to Their Parents, Teenagers Do Not: an Exploratory Questionnaire Study on Children’s Age and Personal Odor Ratings in a Polish Sample
| 
|-
| Peace
| Jaimie Arona Krems, Rebecka Hahnel-Peeters, Laureon Merrie, Keelah Williams, and Daniel Sznycer (USA, Argentina, Australia)
| "We value friends who are vicious to people we dislike"
| Sometimes we want vicious friends: People have nuanced preferences for how they want their friends to behave toward them versus others
| 
|-
| Soil Science
| Franz Bender, Marcel van der Heijden, Atlant Bieri, and Pia Viviani (Switzerland, The Netherlands, Germany)
| "Burying 1,000 identical pairs of underpants in more than 25 countries then digging them up after 2 months"
| Soil health assessment using buried cotton underpants with the help of 1000 citizen scientists
| 
|-
|}
```

### Full section (plain rendering)
==2026==

The 36th First Annual Ig Nobel Prize ceremony took place on Thursday, September 3, 2026 at 7:00 pm CET and was held at Kongresshaus Zürich, Claridenstrasse 5, Zürich, Switzerland. [ref: (2026) "The 36th First Annual Ig Nobel Prize Ceremony"] [ref: Ouelette (2026) "Meet the 2026 Ig Nobel Prize winners"]

{| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Research
! scope="col"| Refs
|- 
| Biomechanics
| Matilda Brindle, Catherine Talbot, Stuart West (UK, USA)
| "Devising a more precise definition of kissing – non-agonistic interactions involving directed, intraspecific, oral-oral contact with some movement of the lips/mouthparts and no food transfer" – in ants, polar bears, and humans.
| A comparative approach to the evolution of kissing
| [ref: Brindle (2026) "A comparative approach to the evolution of kissing" doi:10.1016/j.evolhumbehav.2025.106788]
|-
| Economics
| Paul Piff, Daniel Stancato, Stephane Cote, Rodolfo Mendoza-Denton, Dacher Keltner (USA, Mexico, Canada)
| "Amassing evidence that upper-class people are more likely to snatch from a children's candy, and engage in other kinds of unethical behavior."
| Higher social class predicts increased unethical behavior
| [FOCAL REF: Piff (2012) "Higher social class predicts increased unethical behavior" doi:10.1073/pnas.1118373109]
|-
| Chemistry
| Sanchari Banerjee, Nathan Coussens, Francois-Xavier Gallat, Nitish Sathyanarayanan, Jandhyam Srikanth, Koichiro Yagi, James Gray, Steven Tobe, Barbara Stay, Leonard Chavas, Sumabramanian Ramaswamy (India, France, Japan, USA)
| "Discovering that milk proteins from viviparous cockroaches contains 3 times as much energy as milk proteins than from cows."
| Structure of heterogeneous, glycosylated, lipid-bound, in vivo-grown protein crystal at atomic resolution from the viviparous cockroach Diploptera punctata.
| 
|-
| Medicine
| Tokuji Unno, accepted by Dr. Miki Takahara (Japan)
| "How to Blow the Nose – An Aerodynamic Study of the Nose-Blowing"
|
| [ref: Unno (1977) "How to Blow the Nose" doi:10.3950/jibiinkoka.80.11]
|-
| Biology
| Joao Miguel Alvez-Nunes, Adriano Fellone, Selma Maria Almeida-Santos, Carlos Roberto de Medeiros, Ivan Sazima, Otávio Augusto Vuolo Marques (Brazil, Australia)
| "Gently stepping on various parts of various venomous snakes repeatedly, at various temperatures, at various times of day – to try to learn what does and what does not induce a venomous snake to bite a human."
| Study of defensive behavior of a venomous snake as a new approach to understand snakebite
| [ref: Jones (2024) "Snakebite researcher steps on vipers 40,000 times"]
|-
| Physics
| Randy Hurd, Zhao Pan, Tadd Truscott, Kaveeshan Thurairajah (Canada, USA, China, Saudi Arabia)
| "Theoretical and experimental attempts to design a splash-free urinal."
| Splash-free urinals for global sustainability and accessibility: Design through physics and differential equations
| [ref: Ouellette (2022) "What's the best design for splash-free urinal? Physics now has the ans"]
|-
| Technology
| Justin Puma, Zhen Yang, Evan Johnston, Zixin Zhang, Xiaoyi Lan, Lingzhi Zhang, Hongyu Hou, Zixin He, Ali Afify, Megan Creighton, Jianyu Li, and Changhong Cao (China, Canada, USA, Egypt)
| "Pioneering the use of mosquito proboscises as high-resolution 3D printing nozzles, a process called Necroprinting."
| 3D necroprinting: Leveraging biotic material as the nozzle for 3D printing
| 
|-
| Olfaction
| Ilona Croy, Tomasz Frackowiak, Thomas Hummel, and Agnieszka Sorokowska (Poland, Germany, Sweden)
| "Collecting evidence that babies smell wonderful to their parents but teenagers do not."
| Babies Smell Wonderful to Their Parents, Teenagers Do Not: an Exploratory Questionnaire Study on Children’s Age and Personal Odor Ratings in a Polish Sample
| 
|-
| Peace
| Jaimie Arona Krems, Rebecka Hahnel-Peeters, Laureon Merrie, Keelah Williams, and Daniel Sznycer (USA, Argentina, Australia)
| "We value friends who are vicious to people we dislike"
| Sometimes we want vicious friends: People have nuanced preferences for how they want their friends to behave toward them versus others
| 
|-
| Soil Science
| Franz Bender, Marcel van der Heijden, Atlant Bieri, and Pia Viviani (Switzerland, The Netherlands, Germany)
| "Burying 1,000 identical pairs of underpants in more than 25 countries then digging them up after 2 months"
| Soil health assessment using buried cotton underpants with the help of 1000 citizen scientists
| 
|-
|}

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: 2fd9886968cf6c26751b/article_plain.txt in the evidence directory.)

- {| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Reproduction
| Ahmed Shafik 
| "for studying the effects of wearing polyester, cotton, or wool trousers on the sex life of rats, and for conducting similar tests with human males"
| [ref: Shafik (1993) "Effect of Different Types of Textiles on Sexual Activity" doi:10.1159/000474332] [ref: Shafik (1992) "Contraceptive efficacy of polyester-induced azoospermia in normal men" doi:10.1016/0010-7824(92)90157-O]
|-
| Economics
| Mark Avis, Sarah Forbes, and Shelagh Ferguson
| "for assessing the perceived personalities of rocks, from a sales and marketing perspective"
| [ref: Avis (2014) "The brand personality of rocks: A critical evaluation of a brand perso" doi:10.1177/1470593113512323]
|-
| Physics
| Gábor Horváth, Miklós Blahó, György Kriska, Ramón Hegedüs, Balázs Gerics, Róbert Farkas, Susanne Åkesson, Péter Malik, and Hansruedi Wildermuth
| "for discovering why white-haired horses are the most horsefly-proof horses, and for discovering why dragonflies are fatally attracted to black tombstones"
| [ref: Horváth (2010) "An unexpected advantage of whiteness in horses: the most horsefly-proo" doi:10.1098/rspb.2009.2202] [ref: Horváth (2007) "Ecological traps for dragonflies in a cemetery: the attraction of Symp" doi:10.1111/j.1365-2427.2007.01798.x]
|-
| Chemistry
| Volkswagen
| "for solving the problem of excessive 
- {| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Medicine
| Marc Mitchell and David Wartinger
| "for using roller coaster rides to try to hasten the passage of kidney stones"
| [ref: Mitchell (2016) "Validation of a Functional Pyelocalyceal Renal Model for the Evaluatio" doi:10.7556/jaoa.2016.128]
|-
| Anthropology
| Tomas Persson, Gabriela-Alina Sauciuc, and Elainie Madsen
| "for collecting evidence, in a zoo, that chimpanzees imitate humans about as often, and about as well, as humans imitate chimpanzees"
| [ref: Persson (2018) "Spontaneous cross-species imitation in interactions between chimpanzee" doi:10.1007/s10329-017-0624-9]
|-
| Biology
| Paul Becher, Sebastien Lebreton, Erika Wallin, Erik Hedenstrom, Felipe Borrero-Echeverry, Marie Bengtsson, Volker Jorger, and Peter Witzgall
| "for demonstrating that wine experts can reliably identify, by smell, the presence of a single fly in a glass of wine"
| [ref: Becher (2018) "The Scent of the Fly" doi:10.1007/s10886-018-0950-4] 
|-
| Chemistry
| Paula Romão, Adília Alarcão and the late César Viana
| "for measuring the degree to which human saliva is a good cleaning agent for dirty surfaces"
| [ref: Romão (1990) "Human saliva as a cleaning agent for dirty surfaces" doi:10.1179/sic.1990.35.3.153]
|-
| Medical Education
| Akira Horiuchi
| "for the medical report Colonoscopy in the Sitting Position: Lessons Learn
- {| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Acoustics
| Stephan Reber, Takeshi Nishimura, Judith Janisch, Mark Robertson, and Tecumseh Fitch,
| "for inducing a female Chinese alligator to bellow in an airtight chamber filled with helium-enriched air"
| [ref: Reber (2015) "A Chinese alligator in heliox: formant frequencies in a crocodilian" doi:10.1242/jeb.119552]
|-
| Economics
| Christopher Watkins, Juan David Leongómez, Jeanne Bovet, Agnieszka Żelaźniewicz, Max Korbmacher, Marco Antônio Corrêa Varella, Ana Maria Fernandez, Danielle Wagstaff, and Samuela Bolgan
| "for trying to quantify the relationship between different countries' national income inequality and the average amount of mouth-to-mouth kissing"
| [ref: Watkins (2019) "National income inequality predicts cultural variation in mouth to mou" doi:10.1038/s41598-019-43267-7]
|-
| Entomology
| Richard Vetter
| "for collecting evidence that many entomologists (scientists who study insects) are afraid of spiders, which are not insects"
| [ref: Vetter (2013) "Arachnophobic Entomologists: When Two More Legs Makes a Big Difference" doi:10.1093/ae/59.3.168]
|-
| Management
| Xi Guang-An, Mo Tian-Xiang, Yang Kang-Sheng, Yang Guang-Sheng, and Ling Xian Si
| "five professional hitmen in Guangxi, China, who managed a contract for a hit job (a murder performed for money) in the following way: After acceptin

## ORIGINAL STUDY: doi:10.1073/pnas.1118373109 (FLoRA title: Higher social class predicts increased unethical behavior)
Crossref: Higher social class predicts increased unethical behavior | Paul K. Piff, Daniel M. Stancato, Stéphane Côté, Rodolfo Mendoza-Denton, Dacher Keltner | Proceedings of the National Academy of Sciences | 2012 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2125457158", "type": "article", "publication_year": 2012, "cited_by_count": 1045, "is_retracted": false, "oa_status": "green", "oa_pdf": null, "oa_landing": "https://www.ncbi.nlm.nih.gov/pmc/articles/3306667"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1073_pnas_1118373109.txt (Free copy found by source search (published): https://pmc.ncbi.nlm.nih.gov/articles/PMC3306667/)
Retrieved: 2026-10-09T12:18:42+00:00
### Abstract (Crossref deposited abstract)
Seven studies using experimental and naturalistic methods reveal that upper-class individuals behave more unethically than lower-class individuals. In studies 1 and 2, upper-class individuals were more likely to break the law while driving, relative to lower-class individuals. In follow-up laboratory studies, upper-class individuals were more likely to exhibit unethical decision-making tendencies (study 3), take valued goods from others (study 4), lie in a negotiation (study 5), cheat to increase their chances of winning a prize (study 6), and endorse unethical behavior at work (study 7) than were lower-class individuals. Mediator and moderator data demonstrated that upper-class individuals’ unethical tendencies are accounted for, in part, by their more favorable attitudes toward greed.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1038/sdata.2016.120 (FLoRA title: A 4-study replication of the moderating effects of greed on socioeconomic status and unethical behaviour; FLoRA outcome code: mixed [screening input only, not citable]; DOI detected on page: False)
Crossref: A 4-study replication of the moderating effects of greed on socioeconomic status and unethical behaviour | Anjana Balakrishnan, Paolo A. Palma, Joshua Patenaude, Lorne Campbell | Scientific Data | 2017 | type journal-article
Updates/relations (Crossref): [] {"references": [{"id-type": "doi", "id": "10.17605/OSF.IO/92QKX", "asserted-by": "subject"}], "correction": [{"id-type": "doi", "id": "10.1038/sdata.2017.119", "asserted-by": "object"}]}
OpenAlex: {"id": "https://openalex.org/W2580202562", "type": "data-paper", "publication_year": 2017, "cited_by_count": 25, "is_retracted": false, "oa_status": "gold", "oa_pdf": "https://www.nature.com/articles/sdata2016120.pdf", "oa_landing": "https://doi.org/10.1038/sdata.2016.120"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext/10_1038_sdata_2016_120.txt (Europe PMC open-access full text (PMC5283063))
Retrieved: 2026-10-09T12:18:43+00:00
### Abstract (Crossref deposited abstract)
Four replications of Piff and colleagues’ study examined the moderating effects of greed attitudes on the relationship between socio-economic status (SES) and unethical behaviour (Study 7). In the original study, the researchers found that both greed and SES predicted increased propensity to engage in unethical behavior. Furthermore, this association was moderated such that the effects of SES on unethical behaviour were no longer present in the greed prime condition versus the neutral condition. In replication 1 of the original study main effects of greed attitudes and SES were found, but no interaction was found. Main effects for greed emerged in replications 3 and 4. However no main effects for SES or interactions emerged for replications 2–4. A meta-analysis was conducted with all replications and the original study, and found no moderating effect of greed on the relationship between SES and unethical behavior.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1037/xge0001333 (FLoRA title: Social status and unethical behavior: Two replications of the field studies in Piff et al. (2012).; FLoRA outcome code: failed [screening input only, not citable]; DOI detected on page: False)
Crossref: Social status and unethical behavior: Two replications of the field studies in Piff et al. (2012). | Minah H. Jung, Paul Smeets, Jan Stoop, Joachim Vosgerau | Journal of Experimental Psychology: General | 2023 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W4313560788", "type": "article", "publication_year": 2023, "cited_by_count": 16, "is_retracted": false, "oa_status": "green", "oa_pdf": null, "oa_landing": "https://pure.eur.nl/en/publications/6a494c6a-04ec-4b23-a59c-5f0a8a6c02d7"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_skill/10_1037_xge0001333.txt (PDF via download-paper skill (fetchpdf open-access chain); may be a preprint or author manuscript)
Retrieved: 2026-10-09T12:18:45+00:00
### Abstract (Europe PMC abstract)
Prominent social psychologists and major media outlets have put forward the notion that people of high socioeconomic status (SES) are more selfish and behave more unethically than people of low SES. In contrast, other research in economics and sociology has hypothesized and found a positive relationship between SES and prosocial and ethical behavior. We review the empirical evidence for these contradictory findings and conduct two direct, well-powered, and preregistered replications of the field studies by Piff and colleagues (2012) to test the relationship between SES and unethical/selfish behavior. Unlike the original findings, we find no evidence of a positive relationship between SES and unethical/selfish behavior in the two field replication studies. (PsycInfo Database Record (c) 2023 APA, all rights reserved).

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1098/rsos.231240 (FLoRA title: Eleven years of student replication projects provide evidence on the correlates of replicability in psychology; FLoRA outcome code: failed [screening input only, not citable]; DOI detected on page: False)
Crossref: Eleven years of student replication projects provide evidence on the correlates of replicability in psychology | Veronica Boyce, Maya Mathur, Michael C. Frank | Royal Society Open Science | 2023 | type journal-article
Updates/relations (Crossref): [] {"has-review": [{"id-type": "doi", "id": "10.1098/RSOS.231240/v2/decision1", "asserted-by": "object"}, {"id-type": "doi", "id": "10.1098/RSOS.231240/v1/review2", "asserted-by": "object"}, {"id-type": "doi", "id": "10.1098/RSOS.231240/v1/review1", "asserted-by": "object"}, {"id-type": "doi", "id": "1
OpenAlex: {"id": "https://openalex.org/W4388479433", "type": "article", "publication_year": 2023, "cited_by_count": 8, "is_retracted": false, "oa_status": "gold", "oa_pdf": null, "oa_landing": "https://doi.org/10.1098/rsos.231240"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext/10_1098_rsos_231240.txt (Europe PMC open-access full text (PMC10645069))
Retrieved: 2026-10-06T16:15:54+00:00
### Abstract (Crossref deposited abstract)
Cumulative scientific progress requires empirical results that are robust enough to support theory construction and extension. Yet in psychology, some prominent findings have failed to replicate, and large-scale studies suggest replicability issues are widespread. The identification of predictors of replication success is limited by the difficulty of conducting large samples of independent replication experiments, however: most investigations reanalyse the same set of
                     
                       
                         170 
                           
                         
                           replications 
                         
                       
                     
                    . We introduce a new dataset of 176 replications from students in a graduate-level methods course. Replication results were judged to be successful in 49% of replications; of the 136 where effect sizes could be numerically compared, 46% had point estimates within the prediction interval of the original outcome (versus the expected 95%). Larger original effect sizes and within-participants designs were especially related to replication success. Our results indicate that, consistent with prior reports, the robustness of the psychology literature is low enough to limit cumulative progress by student investigators.

## Other database studies cited on this same page (each has its own packet; drafted together)
- 7b3d33cc48f39207c3b6: Bottomless Bowls: Why Visual Cues of Portion Size May Influence Intake** (doi:10.1038/oby.2005.12)
- f84ff1fe303855ec730c: Inhibiting and facilitating conditions of the human smile: A nonobtrusive test of the facial feedback hypothesis. (doi:10.1037/0022-3514.54.5.768)
- 7d53a3ae7f8f425cfab6: On the reception and detection of pseudo-profound bullshit (doi:10.1017/s1930297500006999)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1038/s41467-021-24519-5 | Higher socioeconomic status does not predict decreased prosocial behavior in a field experiment | 2021 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_1038_s41467_021_24519_5.txt
- doi:10.1111/sipr.12065 | How to Achieve Tax Compliance by the Wealthy: A Review of the Literature and Agenda for Policy | 2019 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_1111_sipr_12065.txt
  Snippet: , & hitt, 2017). nevertheless, it remains unclear whether or why the wealthier are greedier, given that income is positively related to financial satisfaction (sahi, 2013). however, greed may not moderate the ethical behavior of either rich or poor (balakrishnan, palma, patenaude, & campbell, 2017): several empirical studies conclude that wealthy individuals are more prosocial and moral than less affluent individuals (andreoni, nikiforakis, & stoop, 2017; balakrishnan et al., 2017; liebe, naumann, & tutic,
  Snippet: thical behavior of either rich or poor (balakrishnan, palma, patenaude, & campbell, 2017): several empirical studies conclude that wealthy individuals are more prosocial and moral than less affluent individuals (andreoni, nikiforakis, & stoop, 2017; balakrishnan et al., 2017; liebe, naumann, & tutic, 2017; trautmann, van de kuilen, & zeckhauser, 2013), suggesting that there is no simple linear relationship between wealth and ethical behavior (mols & jetten, 2017). on the one hand, many of these studies demo
- doi:10.1073/pnas.1807942116 | No evidence that economic inequality moderates the effect of income on generosity | 2019 | read: abstract | mentions replication: False
- doi:10.1038/s41467-023-41007-0 | Subjective socioeconomic status and income inequality are associated with self-reported morality across 67 countries | 2023 | read: abstract | mentions replication: False
- doi:10.1016/j.jbusres.2019.06.012 | Avoiding spurious moderation effects: An information-theoretic approach to moderation analysis | 2019 | read: full_text | mentions replication: True | file: cache/fulltext_skill/10_1016_j_jbusres_2019_06_012.txt
  Snippet: iding spurious moderation effects. in this section, we present how the method works using real data as, unlike the simulation data above, we do not know what the true model is. for this purpose, we use two data sets used in babcock et al. (2017) and balakrishnan et al. (2017), respectively. both data sets are hosted at the open science framework's website and are free to download. open science framework (osf) is an open source research project that facilitates an open collaboration among researchers in psyc
  Snippet: ly to be misleading or spurious due to nonlinearity effects. furthermore, the information-theoretic approach supplies us with evidence that the moderation model has good quality with respect to other plausible models. 18 6.2 study 4. using data from balakrishnan et al. (2017) we used a data set (n=264) from one of the balakrishnan et al. (2017) replication studies3. specifically, we used a data set of their first replication study provided in the spss format on the open science framework website. in their s

## Other papers relevant to this page that the pipeline looked up
- doi:10.3389/fpsyg.2017.00702 | From Data to Truth in Psychological Science. A Personal Perspective. | paper cited in the article (not a database study) | read: abstract
  Abstract (Semantic Scholar): Over 30 years ago, Leonard Martin, Sabine Stepper, and I (Strack et al., 1988) conducted two studies to test the “facial feedback” hypothesis (Darwin, 1872). At the time, the hypothesis itself, namely that facial expressionsmay affect emotional experiences, was well established and frequently tested (e.g., Leventhal andMace, 1970; Laird, 1974). However, the underlying mechanism remained largely unexplored. On the one hand, the feedback could have been mediated by an inference from the emotional meaning of the expression to the underlying emotional state. On the other hand it could have been a more direct mechanism that does not involve any inferences. To resolve this ambiguity, we attempted to eliminate the inferential route by preventing participants from interpreting their facial action as “a smile.” This was accomplished by having participants holding a pen either between their protruded lips, which prevents smiling, or between their teeth, which facilitates it. Holding the pen in either of these positions, participants had to perform a series of tasks, among them a rating of the funniness of cartoons. As predicted, the cartoons were rated to be funnier if the pen was held between the teeth than between the lips. The effect was not strong but met the standard criteria of significance. The resulting “pen study” was meant neither to demonstrate a cute phenomenon nor to identify a powerful intervention to improve people’s feelings. Instead, it was intended to be one piece in the theoretical puzzle. This was underscored in the last sentence of the original article: “Obviously, more research is needed to understand the exact mechanisms that are responsible for facial feedback. In this endeavor, an alternative methodology that eliminates possible confounds may be helpful (p. 776).” Since 1988, more research on facial feedback has been conducted (Laird and Lacasse, 2014) and even a new methodology was introduced that was robust enough to even afford therapeutic interventions, namely the suppression (injecting Botox) of the corrugator muscle, which contracts the eyebrows and is implied in negative emotions (Finzi and Rosenthal, 2016). In 2013, I volunteered to be part of a Registered Replication Report project and submitted the experimental materials. In September 2016, the results came out (Wagenmakers et al., 2016). Seventeen replication groups had tested 1,894 participants. For nine groups, the result was in the predicted direction, for eight groups in the opposite direction. Overall, there was no significant effect.

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1146/annurev-psych-010213-115054 | The Sociocultural Appraisals, Values, and Emotions (SAVE) Framework of Prosociality: Core Processes from Gene to Meme | 2014 | review | cited_by 297
  Abstract: The study of prosocial behavior--altruism, cooperation, trust, and the related moral emotions--has matured enough to produce general scholarly consensus that prosociality is widespread, intuitive, and rooted deeply within our biological makeup. Several evolutionary frameworks model the conditions under which prosocial behavior is evolutionarily viable, yet no unifying treatment exists of the psychological decision-making processes that result in prosociality. Here, we provide such a perspective in the form of the sociocultural appraisals, values, and emotions (SAVE) framework of prosociality. We review evidence for the components of our framework at four levels of analysis: intrapsychic, dyadic, group, and cultural. Within these levels, we consider how phenomena such as altruistic punishment, prosocial contagion, self-other similarity, and numerous others give rise to prosocial behavior. We then extend our reasoning to chart the biological underpinnings of prosociality and apply our framework to understand the role of social class in prosociality.
- [review citing original] doi:10.1016/j.copsyc.2015.09.007 | Cultural differences in moral judgment and behavior, across and within societies | 2015 | review | cited_by 224
  Abstract: (none)
- [review citing original] doi:10.1016/j.copsyc.2017.06.003 | Social class and prosocial behavior: current evidence, caveats, and questions | 2017 | review | cited_by 180
  Abstract: (none)
- [review citing original] doi:10.1016/j.copsyc.2015.03.013 | The social dynamics of breaking the rules: antecedents and consequences of norm-violating behavior | 2015 | review | cited_by 162
  Abstract: (none)
- [review citing original] doi:10.1016/j.copsyc.2015.09.006 | Beyond East vs. West: social class, region, and religion as forms of culture | 2015 | review | cited_by 92
  Abstract: (none)
- [cites original and replication 10.1038/sdata.2016.120] doi:10.1038/s41467-021-24519-5 | Higher socioeconomic status does not predict decreased prosocial behavior in a field experiment | 2021 | article | cited_by 100
  Abstract: Does higher socioeconomic status predict decreased prosocial behavior? Methodological issues such as the reliance of survey studies on self-reported measures of prosociality, the insufficient control of relative incentives in experiments, and the use of non-random samples, have prevented researchers from ruling out that there is a negative association between socioeconomic status (SES) and prosociality. Here, we present results from a field experiment on the willingness of unaware individuals of different SES to undertake an effortful prosocial task-returning a misdelivered letter. Specifically, using the rental or sale value of homes as indicators of SES, we randomly selected households of high and low SES and misdelivered envelopes to them. Despite controlling for numerous covariates and performing a series of ancillary tests, we fail to find any evidence that higher SES predicts decreased prosocial behavior. Instead, we find that misdelivered letters are substantially more likely to be returned from high rather than low SES households.
- [cites original and replication 10.1038/sdata.2016.120] doi:10.1111/sipr.12065 | How to Achieve Tax Compliance by the Wealthy: A Review of the Literature and Agenda for Policy | 2019 | article | cited_by 83
  Abstract: Abstract Tax compliance by the wealthy is relevant not only because their contributions are essential to maintain public budgets and social equality, but because their (non)compliance behavior and the perceived (un)fairness of their contributions can fuel social unrest. In this article, after giving a brief history of taxing the wealthy, we review the existing theoretical, empirical, and policy literature on their tax compliance. We discuss how and why the wealthy differ from less affluent taxpayers because of specific interrelated political, social, and psychological conditions. Understanding the psychological mechanisms that determine the tax compliance of the wealthy can provide policy insights on how to better integrate the wealthy in the tax system. Therefore, the present review is also a starting point for new policy approaches to increase tax compliance and tax morale among the wealthy.
- [cites original and replication 10.1038/sdata.2016.120] doi:10.1073/pnas.1807942116 | No evidence that economic inequality moderates the effect of income on generosity | 2019 | article | cited_by 83
  Abstract: A landmark study published in PNAS [Côté S, House J, Willer R (2015) Proc Natl Acad Sci USA 112:15838–15843] showed that higher income individuals are less generous than poorer individuals only if they reside in a US state with comparatively large economic inequality. This finding might serve to reconcile inconsistent findings on the effect of social class on generosity by highlighting the moderating role of economic inequality. On the basis of the importance of replicating a major finding before readily accepting it as evidence, we analyzed the effect of the interaction between income and inequality on generosity in three large representative datasets. We analyzed the donating behavior of 27,714 US households (study 1), the generosity of 1,334 German individuals in an economic game (study 2), and volunteering to participate in charitable activities in 30,985 participants from 30 countries (study 3). We found no evidence for the postulated moderation effect in any study. This result is especially remarkable because ( i ) our samples were very large, leading to high power to detect effects that exist, and ( ii ) the cross-country analysis employed in study 3 led to much greater vari
- [cites original and replication 10.1038/sdata.2016.120] doi:10.1038/s41467-023-41007-0 | Subjective socioeconomic status and income inequality are associated with self-reported morality across 67 countries | 2023 | article | cited_by 65
  Abstract: Individuals can experience a lack of economic resources compared to others, which we refer to as subjective experiences of economic scarcity. While such experiences have been shown to shift cognitive focus, attention, and decision-making, their association with human morality remains debated. We conduct a comprehensive investigation of the relationship between subjective experiences of economic scarcity, as indexed by low subjective socioeconomic status at the individual level, and income inequality at the national level, and various self-reported measures linked to morality. In a pre-registered study, we analyze data from a large, cross-national survey (N = 50,396 across 67 countries) allowing us to address limitations related to cross-cultural generalizability and measurement validity in prior research. Our findings demonstrate that low subjective socioeconomic status at the individual level, and income inequality at the national level, are associated with higher levels of moral identity, higher morality-as-cooperation, a larger moral circle, and increased prosocial intentions. These results appear robust to several advanced control analyses. Finally, exploratory analyses indicat
- [cites original and replication 10.1038/sdata.2016.120] doi:10.1016/j.jbusres.2019.06.012 | Avoiding spurious moderation effects: An information-theoretic approach to moderation analysis | 2019 | article | cited_by 21
  Abstract: (none)
- [cites original and replication 10.1037/xge0001333] doi:10.1038/s41467-025-59366-1 | Evolutionary dynamics of behavioral motivations for cooperation | 2025 | article | cited_by 16
  Abstract: Human decision-making is shaped by underlying motivations, which reflect both subjective well-being and fundamental biological needs. Different needs are often prioritized and traded off against one another. Here we develop a theoretical framework to study the evolution of behavioral motivations, encompassing both philanthropic (cooperating after personal needs are met) and aspirational (cooperating to fulfill personal needs) motivations. Our findings show that when the ratio of benefits to costs for cooperation exceeds a critical threshold, individuals initially driven by aspirational motivations can transition to philanthropic motivations with a low reference point for cooperation, resulting in increased cooperation. Furthermore, the critical threshold depends on the structure of the underlying social network, with network modifications capable of reversing the evolutionary trajectory of motivations. Our results reveal the complex interplay between needs, motivations, social networks, and decision-making, offering insights into how evolution shapes not only cooperative behaviors but also the motivations behind them. Human decision-making, including cooperation, is shaped by motiv
- [cites original and replication 10.1037/xge0001333] doi:10.1093/pnasnexus/pgae582 | Greater income and financial well-being are associated with higher prosocial preferences and behaviors across 76 countries | 2025 | article | cited_by 11
  Abstract: Prosocial preferences and behaviors-defined as those that benefit others-are essential for health, well-being, and a society that can effectively respond to global challenges. Identifying factors that may increase or decrease them is therefore critical. Wealth, in the form of income or subjective financial well-being (FWB), may be crucial in determining prosociality. In addition, individuals' experience of precarity (inability to meet basic needs) or country-specific factors could change how wealth correlates with prosociality, yet this impact is unknown. Here, we tested how self-reported household income (HHI) and FWB were associated with seven measures of prosociality in a global, representative sample of 80,337 people across 76 countries. We show a consistent positive association between wealth and prosociality, across both measures and for both financial and nonfinancial prosocial preferences and behaviors. HHI was positively associated with altruism, positive reciprocity, donating money, volunteering, and helping a stranger, but negatively associated with trust. FWB was positively associated with all aspects of prosociality, including trust. Individuals' experience of precarit
- [cites original and replication 10.1037/xge0001333] doi:10.1038/s41562-025-02234-1 | Advancing the psychology of social class with large-scale replications in four countries | 2025 | article | cited_by 10
  Abstract: Abstract Theoretical models have been developed to understand how social class influences individual thoughts, feelings and behaviours. However, the validity of these models is threatened by the prevailing use of small, non-diverse samples and flexible measurement practices. We preregistered replications of 35 key hypotheses from 17 correlational and 5 experimental studies, and collected large, quota-based or probability samples from the USA, France, Switzerland and India ( N total = 33,536). Our analysis yielded three central findings: (1) ~50% of the effects were successfully replicated; (2) conclusions were consistent across different operationalizations of social class, although objective indicators yielded smaller estimates (for example, income and education); and (3) half of the effects were moderated—mostly strengthened—by social class identification, system-justification beliefs or local income inequality. Overall, hypotheses based on differences between social class contexts in terms of constraints, uncertainty and status were well supported. However, hypotheses based on models positing social class differences in psychological orientations towards ‘the self’ versus ‘other
- [cites original and replication 10.1037/xge0001333] doi:10.1016/j.jbusres.2023.114468 | License for Wrongdoing: Why better relationships with leaders lead to employee unethical behavior | 2023 | article | cited_by 7
  Abstract: (none)
- [cites original and replication 10.1037/xge0001333] doi:10.2139/ssrn.3249788 | Is Social Responsibility a Normal Good? | 2018 | preprint | cited_by 4
  Abstract: (none)
