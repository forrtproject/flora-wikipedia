# Evidence packet d002c0648f67a08a1429: List of cognitive biases

Frozen revision: 1376537524 (2026-09-24T19:42:49Z); https://en.wikipedia.org/w/index.php?oldid=1376537524
Live check: {"frozen_revid": "1376537524", "title": "List of cognitive biases", "live_revid": 1376537524, "live_timestamp": "2026-09-24T19:42:49Z", "checked_at": "2026-10-06T16:09:01+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "history_list", "context_kind": "inline", "living_person_category": false, "health_term_flag": false, "co_cited": false, "large_project": false, "flora_originals_on_page": 7}

## Article lead (plain rendering, approximate)
In psychology and cognitive science, cognitive biases are systematic patterns of deviation from norm and/or rationality in judgment. [ref: (2005) "The Handbook of Evolutionary Psychology"] [ref: (2022) "Cognitive Bias. Philogenesis or Ontogenesis" doi:10.3389/fpsyg.2022.892829] They are often studied in psychology, sociology and behavioral economics. [ref: (2005) "The Handbook of Evolutionary Psychology"]

A memory bias is a cognitive bias that either enhances or impairs the recall of a memory (either the chances that the memory will be recalled at all, or the amount of time it takes for it to be recalled, or both), or that alters the content of a reported memory.

Explanations include information-processing rules (i.e., mental shortcuts), called heuristics, that the brain uses to produce decisions or judgments. Biases have a variety of forms and appear as cognitive ("cold") bias, such as mental noise, [ref: (2012) "Toward a synthesis of cognitive biases: how noisy information processi" doi:10.1037/a0025940] or motivational ("hot") bias, such as when beliefs are distorted by wishful thinking. Both effects can be present at the same time. [ref: MacCoun RJ (1998) "Biases in the interpretation and use of research results" doi:10.1146/annurev.psych.49.1.259] [ref: (1998) "Confirmation Bias: A Ubiquitous Phenomenon in Many Guises" doi:10.1037/1089-2680.2.2.175]

There are also controversies over some of these biases as to whether they count as useless or irrational, or whether they result in useful attitudes or behavior. For example, when getting to know others, people tend to ask leading questions which seem biased towards confirming their assumptions about the person. However, this kind of confirmation bias has also been argued to be an example of social skill; a way to establish a connection with the other person. [ref: (1995) "Confirmation Bias as a Social Skill" doi:10.1177/01461672952111011]

Although this research overwhelmingly involves human subjects, some studies have found bias in non-human animals as well. For example, loss aversion has been shown in monkeys and hyperbolic discounting has been observed in rats, pigeons, and monkeys. [ref: (2010) "Hyperbolically discounted temporal difference learning" doi:10.1162/neco.2010.08-09-1080]

## Article outline
Organization of cognitive biases
Estimation
  Association
  Baseline
  Inertia
  Outcome
  Self-perspective
Decision
  Association
  Baseline
  Inertia
  Outcome
  Self-perspective
Hypothesis assessment
  Association
  Outcome
Causal attribution
  Outcome
  Self-perspective
Recall
  Association
  Baseline
  Inertia
  Outcome
  Self-perspective
Opinion reporting
  Association
  Inertia
  Outcome
  Self-perspective
See also
Footnotes
References
Further reading
External links

## Categories
Cognitive biases; Psychology lists; Behavioral finance; Cognitive science lists

## Occurrence 1: original DOI 10.1037/0022-3514.77.2.221 in section 'Self-perspective'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
===Self-perspective===
* Curse of knowledge: When better-informed people find it extremely difficult to think about problems from the perspective of lesser-informed people. [ref: (2003) "Sharing expertise beyond knowledge management"]
* Extrinsic incentives bias, an exception to the fundamental attribution error, where people view others as having (situational) extrinsic motivations, while viewing themselves as having (dispositional) intrinsic motivations. [ref: Ross, L., & Nisbett, R. E. (1991). The Person and the Situation: Perspectives of Social ]
* False consensus effect, the tendency for people to overestimate the degree to which others agree with them. [ref: (1987) "Ten years of research on the false-consensus effect: An empirical and " doi:10.1037/0033-2909.102.1.72]
* Illusion of transparency, the tendency for people to overestimate the degree to which their personal mental state is known by others, and to overestimate how well they understand others' personal mental states. [ref: Gilovich, T., Savitsky, K., & Medvec, V. H. (1998). The illusion of transparency: Biased a]
* Naïve cynicism, expecting more egocentric bias in others than in oneself. [ref: Kruger, J., & Gilovich, T. (1999). Naive cynicism in everyday theories of responsibility a]
* Optimism bias: The tendency to be over-optimistic, underestimating greatly the probability of undesirable outcomes and overestimating favorable and pleasing outcomes (see also wishful thinking, valence effect, positive outcome bias, and compare pessimism bias). [ref: harvnb|Baron|1994|p=44] [ref: Harvnb |Hardman|2009|p=104]
* Outgroup homogeneity bias, where individuals see members of other groups as being relatively less varied than members of their own group. [ref: harvnb|Plous|1993|p=206]
* Pessimism bias: The tendency to overestimate the likelihood that bad things will happen. (compare optimism bias). [ref: Sharot, T. (2011). The optimism bias. Current Biology, 21(23), R941–R945. https://doi.]
* Spotlight effect: The tendency to overestimate the amount that other people notice one's appearance or behavior. [ref: Gilovich, T., Medvec, V. H., & Savitsky, K. (2000). The spotlight effect in social judgmen]
* Worse-than-average effect: A tendency to believe ourselves to be worse than others at tasks which are difficult. [FOCAL REF: (1999) "Lake Wobegon be gone! The "below-average effect" and the egocentric na" doi:10.1037/0022-3514.77.2.221]

### Paragraph (raw wikitext)
```
===Self-perspective===
* [[Curse of knowledge]]: When better-informed people find it extremely difficult to think about problems from the perspective of lesser-informed people.<ref>{{cite book| veditors = Ackerman MS | title=Sharing expertise beyond knowledge management|year=2003|publisher=MIT Press|location=Cambridge, Massachusetts|isbn=978-0-262-01195-2|edition=online|page=[https://archive.org/details/sharingexpertise0000unse/page/7 7]|url=https://archive.org/details/sharingexpertise0000unse/page/7}}</ref>
* [[Extrinsic incentives bias]], an exception to the ''fundamental attribution error'', where people view others as having (situational) extrinsic motivations, while viewing themselves as having (dispositional) intrinsic motivations.<ref>Ross, L., & Nisbett, R. E. (1991). ''The Person and the Situation: Perspectives of Social Psychology''. McGraw-Hill.</ref>
* [[False consensus effect]], the tendency for people to overestimate the degree to which others agree with them.<ref>{{cite journal |doi=10.1037/0033-2909.102.1.72 |title=Ten years of research on the false-consensus effect: An empirical and theoretical review| vauthors = Marks G, Miller N |journal=Psychological Bulletin|volume=102 |issue=1| year=1987 |pages=72–90}}</ref>
* [[Illusion of transparency]], the tendency for people to overestimate the degree to which their personal mental state is known by others, and to overestimate how well they understand others' personal mental states.<ref>Gilovich, T., Savitsky, K., & Medvec, V. H. (1998). The illusion of transparency: Biased assessments of others' ability to read one's emotional states. ''Journal of Personality and Social Psychology, 75''(2), 332–346. https://doi.org/10.1037/0022-3514.75.2.332</ref>
* [[Naïve cynicism]], expecting more egocentric bias in others than in oneself.<ref>Kruger, J., & Gilovich, T. (1999). Naive cynicism in everyday theories of responsibility assessment. ''Journal of Personality and Social Psychology, 76''(5), 743–753. https://doi.org/10.1037/0022-3514.76.5.743</ref>
* [[Optimism bias]]: The tendency to be over-optimistic, underestimating greatly the probability of undesirable outcomes and overestimating favorable and pleasing outcomes (see also [[wishful thinking]], [[valence effect]], [[Valence effect|positive outcome bias]], and compare [[pessimism bias]]).<ref>{{harvnb|Baron|1994|p=44}}</ref><ref>{{Harvnb |Hardman|2009|p=104}}</ref>
* [[Outgroup homogeneity bias]], where individuals see members of other groups as being relatively less varied than members of their own group.<ref>{{harvnb|Plous|1993|p=206}}</ref>
* [[Pessimism bias]]: The tendency to overestimate the likelihood that bad things will happen. (compare [[optimism bias]]).<ref>Sharot, T. (2011). The optimism bias. ''Current Biology, 21''(23), R941–R945. https://doi.org/10.1016/j.cub.2011.10.030</ref>
* [[Spotlight effect]]: The tendency to overestimate the amount that other people notice one's appearance or behavior.<ref>Gilovich, T., Medvec, V. H., & Savitsky, K. (2000). The spotlight effect in social judgment: An egocentric bias in estimates of the salience of one's own actions and appearance. ''Journal of Personality and Social Psychology, 78''(2), 211–222. https://doi.org/10.1037/0022-3514.78.2.211</ref>
* [[Worse-than-average effect]]: A tendency to believe ourselves to be worse than others at tasks which are difficult.<ref name="Kruger, J. 1999">{{cite journal | vauthors = Kruger J | title = Lake Wobegon be gone! The "below-average effect" and the egocentric nature of comparative ability judgments | journal = Journal of Personality and Social Psychology | volume = 77 | issue = 2 | pages = 221–232 | date = August 1999 | pmid = 10474208 | doi = 10.1037/0022-3514.77.2.221 }}</ref>
```

### Full section (plain rendering)
===Self-perspective===
* Curse of knowledge: When better-informed people find it extremely difficult to think about problems from the perspective of lesser-informed people. [ref: (2003) "Sharing expertise beyond knowledge management"]
* Extrinsic incentives bias, an exception to the fundamental attribution error, where people view others as having (situational) extrinsic motivations, while viewing themselves as having (dispositional) intrinsic motivations. [ref: Ross, L., & Nisbett, R. E. (1991). The Person and the Situation: Perspectives of Social ]
* False consensus effect, the tendency for people to overestimate the degree to which others agree with them. [ref: (1987) "Ten years of research on the false-consensus effect: An empirical and " doi:10.1037/0033-2909.102.1.72]
* Illusion of transparency, the tendency for people to overestimate the degree to which their personal mental state is known by others, and to overestimate how well they understand others' personal mental states. [ref: Gilovich, T., Savitsky, K., & Medvec, V. H. (1998). The illusion of transparency: Biased a]
* Naïve cynicism, expecting more egocentric bias in others than in oneself. [ref: Kruger, J., & Gilovich, T. (1999). Naive cynicism in everyday theories of responsibility a]
* Optimism bias: The tendency to be over-optimistic, underestimating greatly the probability of undesirable outcomes and overestimating favorable and pleasing outcomes (see also wishful thinking, valence effect, positive outcome bias, and compare pessimism bias). [ref: harvnb|Baron|1994|p=44] [ref: Harvnb |Hardman|2009|p=104]
* Outgroup homogeneity bias, where individuals see members of other groups as being relatively less varied than members of their own group. [ref: harvnb|Plous|1993|p=206]
* Pessimism bias: The tendency to overestimate the likelihood that bad things will happen. (compare optimism bias). [ref: Sharot, T. (2011). The optimism bias. Current Biology, 21(23), R941–R945. https://doi.]
* Spotlight effect: The tendency to overestimate the amount that other people notice one's appearance or behavior. [ref: Gilovich, T., Medvec, V. H., & Savitsky, K. (2000). The spotlight effect in social judgmen]
* Worse-than-average effect: A tendency to believe ourselves to be worse than others at tasks which are difficult. [FOCAL REF: (1999) "Lake Wobegon be gone! The "below-average effect" and the egocentric na" doi:10.1037/0022-3514.77.2.221]

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: d002c0648f67a08a1429/article_plain.txt in the evidence directory.)

- There are also controversies over some of these biases as to whether they count as useless or irrational, or whether they result in useful attitudes or behavior. For example, when getting to know others, people tend to ask leading questions which seem biased towards confirming their assumptions about the person. However, this kind of confirmation bias has also been argued to be an example of social skill; a way to establish a connection with the other person. [ref: (1995) "Confirmation Bias as a Social Skill" doi:10.1177/01461672952111011]
- == Organization of cognitive biases ==
Although the reality of these biases is confirmed by reproducible research, [ref: "Cognitive Bias – Association for Psychological Science"] [ref: (2018) "Two decades of cognitive bias research in entrepreneurship: What do we" doi:10.1007/s11301-018-0135-9] there are often controversies about how to classify these biases or how to explain them. [ref: (1999) "MINERVA-DM: A memory processes model for judgments of likelihood" doi:10.1037/0033-295x.106.1.180] Several theoretical causes are known for some cognitive biases, which provides a classification of biases by their common generative mechanism (such as noisy information-processing [ref: (2012) "Toward a synthesis of cognitive biases: how noisy information processi" doi:10.1037/a0025940]). Gerd Gigerenzer has criticized the framing of cognitive biases as errors in judgment, and favors interpreting them as arising from rational deviations from logical thought. [ref: Gigerenzer G (2006) "Contemporary Debates in Cognitive Science"] This list is organized based on the task-based classification proposed by . This classification defines 6 tasks, namely estimation, decision, hypothesis assessment, causal attribution, recall, and opinion reporting. The biases are further loosely classified into 5 sub-categories or "flavors": [ref: Dimara (2020) "A Task-Based Taxonomy of Cognitive Biases for Information Visualizatio" doi:10.1109/TVCG.2018.2872577]
- ===Outcome===
* Barnum effect or Forer effect, the tendency for individuals to give high accuracy ratings to descriptions of their personality that supposedly are tailored specifically for them, but are in fact vague and general enough to apply to a wide range of people. This effect can provide a partial explanation for the widespread acceptance of some beliefs and practices, such as astrology, fortune telling, graphology, and some types of personality tests. [ref: "The Barnum Demonstration"]
* Belief bias, an effect where someone's evaluation of the logical strength of an argument is biased by the believability of the conclusion. [ref: (2000) "On belief bias in syllogistic reasoning" doi:10.1037/0033-295X.107.4.852]
* Berkson's paradox, the tendency to misinterpret statistical experiments involving conditional probabilities. [ref: "Berkson's Paradox {{!"]
* Clustering illusion, the tendency to overestimate the importance of small runs, streaks, or clusters in large samples of random data (that is, seeing phantom patterns). [ref: (2008) "Neuropsychology in the Courtroom: Expert Analysis of Reports and Testi"]
* Confirmation bias, the tendency to search for, interpret, focus on and remember information in a way that confirms one's preconceptions. [ref: (2004) "Cognitive Illusions: A Handbook on Fallacies and Biases in Thinking, J"]
* Congruence bias, the tendency to test hypotheses exclusively through direct testing, instead of testing possible alternative hypotheses. [ref: (2

## ORIGINAL STUDY: doi:10.1037/0022-3514.77.2.221 (FLoRA title: Lake Wobegon be gone! The "below-average effect" and the egocentric nature of comparative ability judgments.)
Crossref: Lake Wobegon be gone! The "below-average effect" and the egocentric nature of comparative ability judgments. | Justin Kruger | Journal of Personality and Social Psychology | 1999 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W4246357531", "type": "article", "publication_year": 1999, "cited_by_count": 701, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: ABSTRACT
Retrieved: 2026-10-06T16:17:32+00:00
### Abstract (PubMed (PMID 10474208))
Like the inhabitants of Garrison Keillor's (1985) fictional community of Lake Wobegon, most people appear to believe that their skills and abilities are above average. A series of studies illustrates one of the reasons why: when people compare themselves with their peers, they focus egocentrically on their own skills and insufficiently take into account the skills of the comparison group. This tendency engenders the oft-documented above-average effect in domains in which absolute skills tend to be high but produces a reliable below-average effect in domains in which absolute skills tend to be low (Studies 1 and 2). In Study 3, cognitive load exacerbated these biases, suggesting that people "anchor" on their assessment of their own abilities and insufficiently "adjust" to take into account the skills of the comparison group. These results suggest that the tendency to see oneself as above average may not be as ubiquitous as once thought.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.17605/osf.io/7yfkc (FLoRA title: Both better and worse than others depending on difficulty: Replication and extensions of Kruger’s (1999) above and below average effects; FLoRA outcome code: successful [screening input only, not citable]; DOI detected on page: False)
Crossref: None |  | None | None | type None
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W3210605046", "type": "preprint", "publication_year": 2020, "cited_by_count": 0, "is_retracted": false, "oa_status": "green", "oa_pdf": null, "oa_landing": "https://osf.io/7yfkc"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_skill/10_17605_osf_io_7yfkc.txt (PDF via download-paper skill (fetchpdf open-access chain); may be a preprint or author manuscript)
Retrieved: 2026-10-06T16:17:32+00:00

## Other database studies cited on this same page (each has its own packet; drafted together)
- 48c1f5d796ac93a89d7c: Outcome bias in decision evaluation. (doi:10.1037/0022-3514.54.4.569)
- cf499d86909151fbd33a: Behavioral Study of obedience. (doi:10.1037/h0040525)
- 9847f5c8beefaaf3533c: Distinction Bias: Misprediction and Mischoice Due to Joint Evaluation. (doi:10.1037/0022-3514.86.5.680)
- e7a5d2648c80813c8b7e: Hierarchical Encoding Makes Individuals in a Group Seem More Attractive (doi:10.1177/0956797613497969)
- 94da14c2b142265f2ab3: People systematically overlook subtractive changes (doi:10.1038/s41586-021-03380-y)
- cb004d84131f41223d62: The Framing of Decisions and the Psychology of Choice (doi:10.1126/science.7455683)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.1016/j.jbusvent.2022.106207 | Overconfidence and entrepreneurship: A meta-analysis of different types of overconfidence in the entrepreneurial process | 2022 | read: metadata_only | mentions replication: False
- doi:10.1136/ebmed-2014-110101 | An evidence-based approach to an ancient pursuit: systematic review on converting online contact into a first date | 2015 | read: full_text | mentions replication: False | file: cache/fulltext_skill/10_1136_ebmed_2014_110101.txt

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1016/j.jbusvent.2022.106207 | Overconfidence and entrepreneurship: A meta-analysis of different types of overconfidence in the entrepreneurial process | 2022 | review | cited_by 64
  Abstract: (none)
- [review citing original] doi:10.1136/ebmed-2014-110101 | An evidence-based approach to an ancient pursuit: systematic review on converting online contact into a first date | 2015 | review | cited_by 12
  Abstract: OBJECTIVE: To determine, for people seeking a date online, what activities and behaviours have an effect on the chances of converting electronic communication into a face-to-face meeting. METHODS: Literature in psychology, sociology, and computer, behavioural and neurocognitive sciences that informed effective online dating was captured through electronic searching of Psychinfo, Medline and Embase in November 2013. Study selection and meta-narrative synthesis were carried out in duplicate. RESULTS: There were 3938 initial citations and 86 studies were synthesised. Initial interest was best captured through: a desirable screen name starting with a letter in the top half of the alphabet; an attractive still picture; and a fluent headline message. For those attracted to browse into the profile, a description of personal traits increased likeability when it: showed who the dater was and what they were looking for in a 70:30 ratio; stayed close to reality; and employed simple language with humour added. Invitations were most successful in obtaining a response from the potential date when they: were short personalised messages addressing a trait in their profile; rhymed with their screen
