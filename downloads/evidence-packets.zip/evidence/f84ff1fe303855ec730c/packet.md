# Evidence packet f84ff1fe303855ec730c: List of Ig Nobel Prize winners

Frozen revision: 1376076686 (2026-09-21T22:53:52Z); https://en.wikipedia.org/w/index.php?oldid=1376076686
Live check: {"frozen_revid": "1376076686", "title": "List of Ig Nobel Prize winners", "live_revid": 1376076686, "live_timestamp": "2026-09-21T22:53:52Z", "checked_at": "2026-10-06T16:46:56+00:00", "changed_since_frozen": false}

Screening flags (heuristic, unverified): {"page_kind_heuristic": "history_list", "context_kind": "inline", "living_person_category": false, "health_term_flag": true, "co_cited": false, "large_project": false, "flora_originals_on_page": 4}

## Article lead (plain rendering, approximate)
A parody of the Nobel Prizes, the Ig Nobel Prizes are awarded each year in mid-September, around the time the recipients of the genuine Nobel Prizes are announced, for ten achievements that "first make people laugh, and then make them think". Commenting on the 2006 awards, Marc Abrahams, editor of Annals of Improbable Research and co-sponsor of the awards, said that "[t]he prizes are intended to celebrate the unusual, honor the imaginative, and spur people's interest in science, medicine, and technology". [ref: (2006) "Teen repellent is Ig Nobel winner"] All prizes are awarded for real achievements, except for three in 1991 and one in 1994, due to an erroneous press release.

## Article outline
1991
  Apocryphal achievements
1992
1993
1994
  No longer officially listed
1995
1996
1997
1998
1999
2000
2001
2002
2003
2004
2005
2006
2007
2008
2009
2010
2011
2012
2013
2014
2015
2016
2017
2018
2019
2020
2021
2022
2023
2024
2025
2026
2027
People who received multiple Ig Nobel Prizes
Ig Nobel Prize winners who also received the Nobel Prize
Notes
References
External links

## Categories
Humor-related lists; Ig Nobel laureates; Ig Nobel Prize; Lists of award winners; Science and technology award winners

## Occurrence 1: original DOI 10.1037/0022-3514.54.5.768 in section '2019'

### Paragraph (plain rendering; [FOCAL REF] = original study, [PAIRED REF] = FLoRA replication)
{| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Medicine
| Silvano Gallus
| "for collecting evidence that pizza might protect against illness and death, if the pizza is made and eaten in Italy"
| [ref: Gallus (2003) "Does pizza protect against cancer?" doi:10.1002/ijc.11382] [ref: Gallus (2004) "Pizza and risk of acute myocardial infarction" doi:10.1038/sj.ejcn.1601997] [ref: Gallus (2006) "Pizza consumption and the risk of breast, ovarian and prostate cancer" doi:10.1097/01.cej.0000186632.04625.f6]
|-
| Medical Education
| Karen Pryor and Theresa McKeon
| "for using a simple animal-training technique—called clicker training—to help new doctors acquire basic surgical skills"
| [ref: Levy (2016) "Is Teaching Simple Surgical Skills Using an Operant Learning Program M" doi:10.1007/s11999-015-4555-8]
|-
| Biology
| Ling-Jun Kong, Herbert Crepaz, Agnieszka Górecka, Aleksandra Urbanek, Rainer Dumke, and Tomasz Paterek
| "for discovering that dead magnetized cockroaches behave differently than living magnetized cockroaches"
| [ref: Kong (2018) "In-vivo biomagnetic characterisation of the American cockroach" doi:10.1038/s41598-018-23005-1]
|-
| Anatomy
| Roger Mieusset and Bourras Bengoudifa
| "for measuring scrotal temperature asymmetry in naked and clothed postmen in France"
| [ref: Bengoudifa (2007) "Thermal asymmetry of the human scrotum" doi:10.1093/humrep/dem133]
|-
| Chemistry
| Shigeru Watanabe, Mineko Ohnishi, Kaori Imai, Eiji Kawano, and Seiji Igarashi
| "for estimating the total saliva volume produced per day by a typical five-year-old child"
| [ref: Watanabe (1995) "Estimation of the total saliva volume produced per day in five-year-ol" doi:10.1016/0003-9969(95)00026-L]
|-
| Engineering
| Iman Farahbakhsh
| "for inventing a diaper-changing machine for use on human infants"
| [ref: (2017) "Infant washer and diaper-changer apparatus and method"]
|-
| Economics
| Habip Gedik, Timothy A. Voss, and Andreas Voss
| "for testing which country's paper money is best at transmitting dangerous bacteria"
| [ref: Gedik (2013) "Money and transmission of bacteria" doi:10.1186/2047-2994-2-22]
|-
| Peace
| Ghada A. bin Saif, Alexandru Papoiu, Liliana Banari, Francis McGlone, Shawn G. Kwatra, Yiong-Huak Chan, and Gil Yosipovitch
| "for trying to measure the pleasurability of scratching an itch"
| [ref: bin Saif (2012) "The pleasurability of scratching an itch: a psychophysical and topogra" doi:10.1111/j.1365-2133.2012.10826.x]
|-
| Psychology
| Fritz Strack
| "for discovering that holding a pen in one's mouth makes one smile, which makes one happier – and for then discovering that it does not"
| [FOCAL REF: Strack (1988) "Inhibiting and facilitating conditions of the human smile: A nonobtrus" doi:10.1037/0022-3514.54.5.768] [ref: Strack (2017) "From Data to Truth in Psychological Science. A Personal Perspective." doi:10.3389/fpsyg.2017.00702]
|-
| Physics
| Patricia Yang, Alexander Lee, Miles Chan, Alynn Martin, Ashley Edwards, Scott Carver, and David Hu
| "for studying how, and why, wombats make cube-shaped poo"
| [ref: (2018) "71st Annual Meeting of the APS Division of Fluid Dynamics – Event – Ho"] [ref: Yang (2021) "Intestines of non-uniform stiffness mold the corners of wombat feces" doi:10.1039/D0SM01230K]
|}

### Paragraph (raw wikitext)
```
{| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Medicine
| Silvano Gallus
| "for collecting evidence that pizza might protect against illness and death, if the pizza is made and eaten in Italy"
| <ref>{{cite journal | last1=Gallus | first1=Silvano | last2=Bosetti | first2=Cristina | last3=Negri | first3=Eva | last4=Talamini | first4=Renato | last5=Montella | first5=Maurizio | last6=Conti | first6=Ettore | last7=Franceschi | first7=Silvia | last8=La Vecchia | first8=Carlo | title=Does pizza protect against cancer? | journal=International Journal of Cancer | volume=107 | issue=2 |year=2003 | doi=10.1002/ijc.11382 | pages=283–284 | pmid=12949808 }}</ref><ref>{{cite journal | last1=Gallus | first1=S | last2=Tavani | first2=A | last3=Vecchia | first3=C La | title=Pizza and risk of acute myocardial infarction | journal=European Journal of Clinical Nutrition | volume=58 | issue=11 | date=2004-11-01 | doi=10.1038/sj.ejcn.1601997 | pages=1543–1546 | pmid=15138460 }}</ref><ref>{{cite journal | last1=Gallus | first1=Silvano | last2=Talamini | first2=Renato | last3=Bosetti | first3=Cristina | last4=Negri | first4=Eva | last5=Montella | first5=Maurizio | last6=Franceschi | first6=Silvia | last7=Giacosa | first7=Attilio | last8=La Vecchia | first8=Carlo | title=Pizza consumption and the risk of breast, ovarian and prostate cancer | journal=European Journal of Cancer Prevention | volume=15 | issue=1 |year=2006 | doi=10.1097/01.cej.0000186632.04625.f6 | pages=74–76 | pmid=16374234 }}</ref>
|-
| Medical Education
| Karen Pryor and Theresa McKeon
| "for using a simple animal-training technique—called ''[[clicker training]]''—to help new doctors acquire basic surgical skills"
| <ref>{{cite journal | last1=Levy | first1=Martin I. | last2=Pryor | first2=Karen W. | last3=McKeon | first3=Theresa R. | title=Is Teaching Simple Surgical Skills Using an Operant Learning Program More Effective Than Teaching by Demonstration? | journal=Clinical Orthopaedics & Related Research | volume=474 | issue=4 |year=2016 | pmid=26369658 | pmc=4773331 | doi=10.1007/s11999-015-4555-8 | pages=945–955 }}</ref>
|-
| Biology
| Ling-Jun Kong, Herbert Crepaz, Agnieszka Górecka, Aleksandra Urbanek, Rainer Dumke, and Tomasz Paterek
| "for discovering that dead magnetized [[cockroach]]es behave differently than living magnetized cockroaches"
| <ref>{{cite journal | last1=Kong | first1=Ling-Jun | last2=Crepaz | first2=Herbert | last3=Górecka | first3=Agnieszka | last4=Urbanek | first4=Aleksandra | last5=Dumke | first5=Rainer | last6=Paterek | first6=Tomasz | title=In-vivo biomagnetic characterisation of the American cockroach | journal=Scientific Reports | volume=8 | issue=1 | date=2018-03-23 | pmid=29572509 | pmc=5865160 | doi=10.1038/s41598-018-23005-1 | doi-access=free| article-number=5140 | arxiv=1702.00538 | bibcode=2018NatSR...8.5140K }}</ref>
|-
| Anatomy
| Roger Mieusset and Bourras Bengoudifa
| "for measuring [[Scrotum#Asymmetry|scrotal temperature asymmetry]] in naked and clothed postmen in France"
| <ref>{{cite journal | last1=Bengoudifa | first1=B. | last2=Mieusset | first2=R. | title=Thermal asymmetry of the human scrotum | journal=Human Reproduction | volume=22 | issue=8 | date=2007-08-01 | pmid=17623724 | doi=10.1093/humrep/dem133 | pages=2178–2182 }}</ref>
|-
| Chemistry
| Shigeru Watanabe, Mineko Ohnishi, Kaori Imai, Eiji Kawano, and Seiji Igarashi
| "for estimating the total [[Saliva#Production|saliva volume produced]] per day by a typical five-year-old child"
| <ref>{{cite journal | last1=Watanabe | first1=S. | last2=Ohnishi | first2=M. | last3=Imai | first3=K. | last4=Kawano | first4=E. | last5=Igarashi | first5=S. | title=Estimation of the total saliva volume produced per day in five-year-old children | journal=Archives of Oral Biology | volume=40 | issue=8 |year=1995 | pmid=7487581 | doi=10.1016/0003-9969(95)00026-L | pages=781–782 }}</ref>{{efn|The award ceremony was attended by Shiguru Watanabe and his adult sons, who were some of the subjects of the study when they were children 35 years prior.}}
|-
| Engineering
| Iman Farahbakhsh
| "for inventing a diaper-changing machine for use on human infants"
| <ref>{{cite web | title=Infant washer and diaper-changer apparatus and method | website=Google Patents | date=2017-01-13 | url=https://patents.google.com/patent/US20170143168 | access-date=2025-12-14}}</ref>
|-
| Economics
| Habip Gedik, Timothy A. Voss, and Andreas Voss
| "for testing which country's paper money is best at transmitting dangerous bacteria"
| <ref>{{cite journal | last1=Gedik | first1=Habip | last2=Voss | first2=Timothy A | last3=Voss | first3=Andreas | title=Money and transmission of bacteria | journal=Antimicrobial Resistance and Infection Control | volume=2 | issue=1 |year=2013 | pmc=3765964 | pmid=23985137 | doi=10.1186/2047-2994-2-22 | doi-access=free | article-number=22 }}</ref>
|-
| Peace
| Ghada A. bin Saif, Alexandru Papoiu, Liliana Banari, [[Francis McGlone]], Shawn G. Kwatra, Yiong-Huak Chan, and Gil Yosipovitch
| "for trying to measure the pleasurability of [[Scratch reflex|scratching an itch]]"
| <ref name="l748">{{cite journal | last1=bin Saif | first1=G.A. | last2=Papoiu | first2=A.D.P. | last3=Banari | first3=L. | last4=McGlone | first4=F. | last5=Kwatra | first5=S.G. | last6=Chan | first6=Y-H. | last7=Yosipovitch | first7=G. | title=The pleasurability of scratching an itch: a psychophysical and topographical assessment | journal=British Journal of Dermatology | volume=166 | issue=5 |year=2012 | pmid=22242789 | pmc=3335970 | doi=10.1111/j.1365-2133.2012.10826.x | pages=981–985 }}</ref>
|-
| Psychology
| [[Fritz Strack]]
| "for discovering that holding a pen in one's mouth makes one smile, which makes one happier – and for then discovering that it does not"
| <ref>{{cite journal | last1=Strack | first1=Fritz | last2=Martin | first2=Leonard L. | last3=Stepper | first3=Sa
```

### Full section (plain rendering)
== 2019 ==

The ceremony took place on 12 September 2019. [ref: (2019) "Announcing the 2019 Ig Nobel Prize Winners"]

{| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Medicine
| Silvano Gallus
| "for collecting evidence that pizza might protect against illness and death, if the pizza is made and eaten in Italy"
| [ref: Gallus (2003) "Does pizza protect against cancer?" doi:10.1002/ijc.11382] [ref: Gallus (2004) "Pizza and risk of acute myocardial infarction" doi:10.1038/sj.ejcn.1601997] [ref: Gallus (2006) "Pizza consumption and the risk of breast, ovarian and prostate cancer" doi:10.1097/01.cej.0000186632.04625.f6]
|-
| Medical Education
| Karen Pryor and Theresa McKeon
| "for using a simple animal-training technique—called clicker training—to help new doctors acquire basic surgical skills"
| [ref: Levy (2016) "Is Teaching Simple Surgical Skills Using an Operant Learning Program M" doi:10.1007/s11999-015-4555-8]
|-
| Biology
| Ling-Jun Kong, Herbert Crepaz, Agnieszka Górecka, Aleksandra Urbanek, Rainer Dumke, and Tomasz Paterek
| "for discovering that dead magnetized cockroaches behave differently than living magnetized cockroaches"
| [ref: Kong (2018) "In-vivo biomagnetic characterisation of the American cockroach" doi:10.1038/s41598-018-23005-1]
|-
| Anatomy
| Roger Mieusset and Bourras Bengoudifa
| "for measuring scrotal temperature asymmetry in naked and clothed postmen in France"
| [ref: Bengoudifa (2007) "Thermal asymmetry of the human scrotum" doi:10.1093/humrep/dem133]
|-
| Chemistry
| Shigeru Watanabe, Mineko Ohnishi, Kaori Imai, Eiji Kawano, and Seiji Igarashi
| "for estimating the total saliva volume produced per day by a typical five-year-old child"
| [ref: Watanabe (1995) "Estimation of the total saliva volume produced per day in five-year-ol" doi:10.1016/0003-9969(95)00026-L]
|-
| Engineering
| Iman Farahbakhsh
| "for inventing a diaper-changing machine for use on human infants"
| [ref: (2017) "Infant washer and diaper-changer apparatus and method"]
|-
| Economics
| Habip Gedik, Timothy A. Voss, and Andreas Voss
| "for testing which country's paper money is best at transmitting dangerous bacteria"
| [ref: Gedik (2013) "Money and transmission of bacteria" doi:10.1186/2047-2994-2-22]
|-
| Peace
| Ghada A. bin Saif, Alexandru Papoiu, Liliana Banari, Francis McGlone, Shawn G. Kwatra, Yiong-Huak Chan, and Gil Yosipovitch
| "for trying to measure the pleasurability of scratching an itch"
| [ref: bin Saif (2012) "The pleasurability of scratching an itch: a psychophysical and topogra" doi:10.1111/j.1365-2133.2012.10826.x]
|-
| Psychology
| Fritz Strack
| "for discovering that holding a pen in one's mouth makes one smile, which makes one happier – and for then discovering that it does not"
| [FOCAL REF: Strack (1988) "Inhibiting and facilitating conditions of the human smile: A nonobtrus" doi:10.1037/0022-3514.54.5.768] [ref: Strack (2017) "From Data to Truth in Psychological Science. A Personal Perspective." doi:10.3389/fpsyg.2017.00702]
|-
| Physics
| Patricia Yang, Alexander Lee, Miles Chan, Alynn Martin, Ashley Edwards, Scott Carver, and David Hu
| "for studying how, and why, wombats make cube-shaped poo"
| [ref: (2018) "71st Annual Meeting of the APS Division of Fluid Dynamics – Event – Ho"] [ref: Yang (2021) "Intestines of non-uniform stiffness mold the corners of wombat feces" doi:10.1039/D0SM01230K]
|}

## Whole-article digest: paragraphs mentioning replication, reproduction, meta-analysis or criticism
(Full plain rendering of the whole article: f84ff1fe303855ec730c/article_plain.txt in the evidence directory.)

- {| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Reproduction
| Ahmed Shafik 
| "for studying the effects of wearing polyester, cotton, or wool trousers on the sex life of rats, and for conducting similar tests with human males"
| [ref: Shafik (1993) "Effect of Different Types of Textiles on Sexual Activity" doi:10.1159/000474332] [ref: Shafik (1992) "Contraceptive efficacy of polyester-induced azoospermia in normal men" doi:10.1016/0010-7824(92)90157-O]
|-
| Economics
| Mark Avis, Sarah Forbes, and Shelagh Ferguson
| "for assessing the perceived personalities of rocks, from a sales and marketing perspective"
| [ref: Avis (2014) "The brand personality of rocks: A critical evaluation of a brand perso" doi:10.1177/1470593113512323]
|-
| Physics
| Gábor Horváth, Miklós Blahó, György Kriska, Ramón Hegedüs, Balázs Gerics, Róbert Farkas, Susanne Åkesson, Péter Malik, and Hansruedi Wildermuth
| "for discovering why white-haired horses are the most horsefly-proof horses, and for discovering why dragonflies are fatally attracted to black tombstones"
| [ref: Horváth (2010) "An unexpected advantage of whiteness in horses: the most horsefly-proo" doi:10.1098/rspb.2009.2202] [ref: Horváth (2007) "Ecological traps for dragonflies in a cemetery: the attraction of Symp" doi:10.1111/j.1365-2427.2007.01798.x]
|-
| Chemistry
| Volkswagen
| "for solving the problem of excessive 
- {| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Medicine
| Marc Mitchell and David Wartinger
| "for using roller coaster rides to try to hasten the passage of kidney stones"
| [ref: Mitchell (2016) "Validation of a Functional Pyelocalyceal Renal Model for the Evaluatio" doi:10.7556/jaoa.2016.128]
|-
| Anthropology
| Tomas Persson, Gabriela-Alina Sauciuc, and Elainie Madsen
| "for collecting evidence, in a zoo, that chimpanzees imitate humans about as often, and about as well, as humans imitate chimpanzees"
| [ref: Persson (2018) "Spontaneous cross-species imitation in interactions between chimpanzee" doi:10.1007/s10329-017-0624-9]
|-
| Biology
| Paul Becher, Sebastien Lebreton, Erika Wallin, Erik Hedenstrom, Felipe Borrero-Echeverry, Marie Bengtsson, Volker Jorger, and Peter Witzgall
| "for demonstrating that wine experts can reliably identify, by smell, the presence of a single fly in a glass of wine"
| [ref: Becher (2018) "The Scent of the Fly" doi:10.1007/s10886-018-0950-4] 
|-
| Chemistry
| Paula Romão, Adília Alarcão and the late César Viana
| "for measuring the degree to which human saliva is a good cleaning agent for dirty surfaces"
| [ref: Romão (1990) "Human saliva as a cleaning agent for dirty surfaces" doi:10.1179/sic.1990.35.3.153]
|-
| Medical Education
| Akira Horiuchi
| "for the medical report Colonoscopy in the Sitting Position: Lessons Learn
- {| class="wikitable plainrowheaders unsortable" style="width:100%;"
! scope="col"| Category
! scope="col"| Winner(s)
! scope="col"| Rationale
! scope="col"| Refs
|- 
| Acoustics
| Stephan Reber, Takeshi Nishimura, Judith Janisch, Mark Robertson, and Tecumseh Fitch,
| "for inducing a female Chinese alligator to bellow in an airtight chamber filled with helium-enriched air"
| [ref: Reber (2015) "A Chinese alligator in heliox: formant frequencies in a crocodilian" doi:10.1242/jeb.119552]
|-
| Economics
| Christopher Watkins, Juan David Leongómez, Jeanne Bovet, Agnieszka Żelaźniewicz, Max Korbmacher, Marco Antônio Corrêa Varella, Ana Maria Fernandez, Danielle Wagstaff, and Samuela Bolgan
| "for trying to quantify the relationship between different countries' national income inequality and the average amount of mouth-to-mouth kissing"
| [ref: Watkins (2019) "National income inequality predicts cultural variation in mouth to mou" doi:10.1038/s41598-019-43267-7]
|-
| Entomology
| Richard Vetter
| "for collecting evidence that many entomologists (scientists who study insects) are afraid of spiders, which are not insects"
| [ref: Vetter (2013) "Arachnophobic Entomologists: When Two More Legs Makes a Big Difference" doi:10.1093/ae/59.3.168]
|-
| Management
| Xi Guang-An, Mo Tian-Xiang, Yang Kang-Sheng, Yang Guang-Sheng, and Ling Xian Si
| "five professional hitmen in Guangxi, China, who managed a contract for a hit job (a murder performed for money) in the following way: After acceptin

## ORIGINAL STUDY: doi:10.1037/0022-3514.54.5.768 (FLoRA title: Inhibiting and facilitating conditions of the human smile: A nonobtrusive test of the facial feedback hypothesis.)
Crossref: Inhibiting and facilitating conditions of the human smile: A nonobtrusive test of the facial feedback hypothesis. | Fritz Strack, Leonard L. Martin, Sabine Stepper | Journal of Personality and Social Psychology | 1988 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2169284121", "type": "article", "publication_year": 1988, "cited_by_count": 1833, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1037_0022_3514_54_5_768.txt (Free copy found by source search (published): https://jhrcook.github.io/wagenmaker-data-analysis/papers/Strack_1988_Inhibiting-and-facilitating-conditions-of-the-human-smile-a-nonobtrusive-test-of-the-facial-feedback-hypothesis.pdf)
Retrieved: 2026-10-06T16:11:11+00:00
### Abstract (OpenAlex reconstructed abstract)
We investigated the hypothesis that people's facial activity influences their affective responses. Two studies were designed to both eliminate methodological problems of earlier experiments and clarify theoretical ambiguities. This was achieved by having subjects hold a pen in their mouth in ways that either inhibited or facilitated the muscles typically associated with smiling without requiring subjects to pose in a smiling face. Study 1's results demonstrated the effectiveness of the procedure. Subjects reported more intense humor responses when cartoons were presented under facilitating conditions than under inhibiting conditions that precluded labeling of the facial expression in emotion categories. Study 2 served to further validate the methodology and to answer additional theoretical questions. The results replicated Study 1's findings and also showed that facial feedback operates on the affective but not on the cognitive component of the humor response. Finally, the results suggested that both inhibitory and facilitatory mechanisms may have contributed to the observed affective responses.

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1037/pspa0000121 (FLoRA title: When both the original study and its failed replication are correct: Feeling observed eliminates the facial-feedback effect.; FLoRA outcome code: mixed [screening input only, not citable]; DOI detected on page: False)
Crossref: When both the original study and its failed replication are correct: Feeling observed eliminates the facial-feedback effect. | Tom Noah, Yaacov Schul, Ruth Mayo | Journal of Personality and Social Psychology | 2018 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2799327013", "type": "article", "publication_year": 2018, "cited_by_count": 113, "is_retracted": false, "oa_status": "closed", "oa_pdf": null, "oa_landing": null}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_hunt/10_1037_pspa0000121.txt (Free copy found by source search (published): https://www2.psych.ubc.ca/~schaller/528Readings/NoahSchulMayo2018.pdf)
Retrieved: 2026-10-06T16:11:12+00:00
### Abstract (Europe PMC abstract)
This article suggests a theoretically driven explanation for a replication failure of one of the basic findings in psychology: the facial-feedback effect. According to the facial-feedback hypothesis, the facial activity associated with particular emotional expressions can influence people's affective experiences. Recently, a replication attempt of this effect in 17 laboratories around the world failed to find any support for the effect. We hypothesize that the reason for the failure of replication is that the replication protocol deviated from that of the original experiment in a critical factor. In all of the replication studies, participants were alerted that they would be monitored by a video camera, whereas the participants in the original study were not monitored, observed, or recorded. Previous findings indicate that feeling monitored or observed reduces reliance on internal cues in making judgments. Therefore, we hypothesize that recording the participants in the replication experiments reduced their reliance on the facial-feedback. To test the hypothesis, we replicated the facial-feedback experiment in 2 conditions: one with a video-camera and one without it. The results revealed a significant facial-feedback effect in the absence of a camera, which was eliminated in the camera's presence. These findings suggest that minute differences in the experimental protocol might lead to theoretically meaningful changes in the outcomes. In our view, the theoretical and methodological approach advocated by our study changes failed replications from being the "end of the road" regarding entire fields of study into a new road for growth regarding our understanding of human nature. (PsycINFO Database Record

## FLoRA-LINKED REPLICATION/REPRODUCTION: doi:10.1177/1745691616674458 (FLoRA title: Registered Replication Report; FLoRA outcome code: failed [screening input only, not citable]; DOI detected on page: False)
Crossref: Registered Replication Report | E.-J. Wagenmakers, T. Beek, L. Dijkhoff, Q. F. Gronau, A. Acosta, R. B. Adams et al. | Perspectives on Psychological Science | 2016 | type journal-article
Updates/relations (Crossref): [] {}
OpenAlex: {"id": "https://openalex.org/W2543067875", "type": "article", "publication_year": 2016, "cited_by_count": 447, "is_retracted": false, "oa_status": "hybrid", "oa_pdf": "https://journals.sagepub.com/doi/pdf/10.1177/1745691616674458", "oa_landing": "https://doi.org/10.1177/1745691616674458"}
Evidence level available to you: FULL_TEXT — full text file: cache/fulltext_skill/10_1177_1745691616674458.txt (PDF via download-paper skill (fetchpdf open-access chain); may be a preprint or author manuscript)
Retrieved: 2026-10-06T16:11:13+00:00
### Abstract (Crossref deposited abstract)
According to the facial feedback hypothesis, people’s affective responses can be influenced by their own facial expression (e.g., smiling, pouting), even when their expression did not result from their emotional experiences. For example, Strack, Martin, and Stepper (1988) instructed participants to rate the funniness of cartoons using a pen that they held in their mouth. In line with the facial feedback hypothesis, when participants held the pen with their teeth (inducing a “smile”), they rated the cartoons as funnier than when they held the pen with their lips (inducing a “pout”). This seminal study of the facial feedback hypothesis has not been replicated directly. This Registered Replication Report describes the results of 17 independent direct replications of Study 1 from Strack et al. (1988), all of which followed the same vetted protocol. A meta-analysis of these studies examined the difference in funniness ratings between the “smile” and “pout” conditions. The original Strack et al. (1988) study reported a rating difference of 0.82 units on a 10-point Likert scale. Our meta-analysis revealed a rating difference of 0.03 units with a 95% confidence interval ranging from −0.11 to 0.16.

## Other database studies cited on this same page (each has its own packet; drafted together)
- 7b3d33cc48f39207c3b6: Bottomless Bowls: Why Visual Cues of Portion Size May Influence Intake** (doi:10.1038/oby.2005.12)
- 2fd9886968cf6c26751b: Higher social class predicts increased unethical behavior (doi:10.1073/pnas.1118373109)
- 7d53a3ae7f8f425cfab6: On the reception and detection of pseudo-profound bullshit (doi:10.1017/s1930297500006999)

## Review articles checked by the pipeline for mentions of the replication(s)
Each was searched (full text where we could get it, otherwise abstract) for the replication authors and year.
- doi:10.3389/fpsyg.2018.00998 | Are Manipulation Checks Necessary? | 2018 | read: abstract | mentions replication: False
- doi:10.1007/s41465-018-0115-y | Improving Methodological Standards in Behavioral Interventions for Cognitive Enhancement | 2019 | read: metadata_only | mentions replication: False
- doi:10.1037/bul0000194 | A meta-analysis of the facial feedback literature: Effects of facial feedback on emotional experience are small and variable. | 2019 | read: abstract | mentions replication: False
- doi:10.1002/arcp.1067 | Metacognitive experiences as information: Processing fluency in consumer judgment and decision making | 2020 | read: abstract | mentions replication: False
- doi:10.1016/j.neubiorev.2020.02.031 | Measuring the evolution of facial ‘expression’ using multi-species FACS | 2020 | read: metadata_only | mentions replication: False

## Other papers relevant to this page that the pipeline looked up
- doi:10.3389/fpsyg.2017.00702 | From Data to Truth in Psychological Science. A Personal Perspective. | paper cited in the article (not a database study) | read: abstract
  Abstract (Semantic Scholar): Over 30 years ago, Leonard Martin, Sabine Stepper, and I (Strack et al., 1988) conducted two studies to test the “facial feedback” hypothesis (Darwin, 1872). At the time, the hypothesis itself, namely that facial expressionsmay affect emotional experiences, was well established and frequently tested (e.g., Leventhal andMace, 1970; Laird, 1974). However, the underlying mechanism remained largely unexplored. On the one hand, the feedback could have been mediated by an inference from the emotional meaning of the expression to the underlying emotional state. On the other hand it could have been a more direct mechanism that does not involve any inferences. To resolve this ambiguity, we attempted to eliminate the inferential route by preventing participants from interpreting their facial action as “a smile.” This was accomplished by having participants holding a pen either between their protruded lips, which prevents smiling, or between their teeth, which facilitates it. Holding the pen in either of these positions, participants had to perform a series of tasks, among them a rating of the funniness of cartoons. As predicted, the cartoons were rated to be funnier if the pen was held between the teeth than between the lips. The effect was not strong but met the standard criteria of significance. The resulting “pen study” was meant neither to demonstrate a cute phenomenon nor to identify a powerful intervention to improve people’s feelings. Instead, it was intended to be one piece in the theoretical puzzle. This was underscored in the last sentence of the original article: “Obviously, more research is needed to understand the exact mechanisms that are responsible for facial feedback. In this endeavor, an alternative methodology that eliminates possible confounds may be helpful (p. 776).” Since 1988, more research on facial feedback has been conducted (Laird and Lacasse, 2014) and even a new methodology was introduced that was robust enough to even afford therapeutic interventions, namely the suppression (injecting Botox) of the corrugator muscle, which contracts the eyebrows and is implied in negative emotions (Finzi and Rosenthal, 2016). In 2013, I volunteered to be part of a Registered Replication Report project and submitted the experimental materials. In September 2016, the results came out (Wagenmakers et al., 2016). Seventeen replication groups had tested 1,894 participants. For nine groups, the result was in the predicted direction, for eight groups in the opposite direction. Overall, there was no significant effect.

## Other secondary-source leads from OpenAlex (NOT inspected; metadata/abstract only)
- [review citing original] doi:10.1146/annurev.psych.59.103006.093639 | Grounded Cognition | 2007 | review | cited_by 5766
  Abstract: Grounded cognition rejects traditional views that cognition is computation on amodal symbols in a modular system, independent of the brain's modal systems for perception, action, and introspection. Instead, grounded cognition proposes that modal simulations, bodily states, and situated action underlie cognition. Accumulating behavioral and neural evidence supporting this view is reviewed from research on perception, memory, knowledge, language, thought, social cognition, and development. Theories of grounded cognition are also reviewed, as are origins of the area and common misperceptions of it. Theoretical, empirical, and methodological issues are raised whose future treatment is likely to affect the growth and impact of grounded cognition.
- [review citing original] doi:10.2466/03.20.pr0.114k22w4 | Relation between Emotion Regulation and Mental Health: A Meta-Analysis Review | 2014 | review | cited_by 648
  Abstract: This meta-analysis examined the relationship between emotion regulation strategies (cognitive reappraisal, expressive suppression) and mental health (measured by life-satisfaction, positive affect, depression, anxiety, and negative affect). 48 studies, which included 51 independent samples, 157 effect sizes, and 21,150 participants, met the inclusion criteria. The results showed that cognitive reappraisal was correlated significantly and positively with positive indicators of mental health (r = .26) and negatively with negative indicators of mental health (r = -.20). Expressive suppression was correlated negatively with positive indicators of mental health (r = -.12), and positively with negative indicators of mental health (r =.15). Expressive suppression was correlated positively with positive indicators of mental health within the category of samples with Western cultural values (r = -.11) but not the category with Eastern cultural values. Moreover, the correlation of expressive suppression and negative indicators of mental health was stronger in the Western cultural values category (r = .19) than in the Eastern cultural values category (r = .06). Therefore, it is necessary for 
- [review citing original] doi:10.1146/annurev-psych-122216-011836 | Psychology's Renaissance | 2017 | review | cited_by 610
  Abstract: In 2010-2012, a few largely coincidental events led experimental psychologists to realize that their approach to collecting, analyzing, and reporting data made it too easy to publish false-positive findings. This sparked a period of methodological reflection that we review here and call Psychology's Renaissance. We begin by describing how psychologists' concerns with publication bias shifted from worrying about file-drawered studies to worrying about p-hacked analyses. We then review the methodological changes that psychologists have proposed and, in some cases, embraced. In describing how the renaissance has unfolded, we attempt to describe different points of view fairly but not neutrally, so as to identify the most promising paths forward. In so doing, we champion disclosure and preregistration, express skepticism about most statistical solutions to publication bias, take positions on the analysis and interpretation of replication failures, and contend that meta-analytical thinking increases the prevalence of false positives. Our general thesis is that the scientific practices of experimental psychologists have improved dramatically.
- [review citing original] doi:10.1146/annurev.psych.121208.131605 | Social Functionality of Human Emotion | 2011 | review | cited_by 495
  Abstract: Answers to the question "What are human emotions for?" have stimulated highly productive programs of research on emotional phenomena in psychology and neuroscience in the past decade. Although a variety of functions have been proposed and examined at different levels of abstraction, what is undeniable is that when emotional processing is compromised, most things social go awry. In this review we survey the research findings documenting the functions of emotion and link these to new discoveries about how emotion is accurately processed and transmitted. We focus specifically on emotion processing in dyads and groups, which reflects the current scientific trend. Within dyads, emotional expressions and learning and understanding through vicarious emotion are the phenomena of interest. Behavioral and brain mechanisms supporting their successful occurrence are evaluated. At the group level, group emotions and group-based emotions, two very different phenomena, are discussed, and mechanistic accounts are reviewed.
- [review citing original] doi:10.1016/j.tics.2009.01.007 | Is social cognition embodied? | 2009 | review | cited_by 423
  Abstract: (none)
- [cites original and replication 10.1037/pspa0000121] doi:10.3389/fpsyg.2018.00998 | Are Manipulation Checks Necessary? | 2018 | article | cited_by 491
  Abstract: Researchers are concerned about whether manipulations have the intended effects. Many journals and reviewers view manipulation checks favorably, and they are widely reported in prestigious journals. However, the prototypical manipulation check is a verbal (rather than behavioral) measure that always appears at the same point in the procedure (rather than its order being varied to assess order effects). Embedding such manipulation checks within an experiment comes with problems. While we conceptualize manipulation checks as measures, they can also act as interventions which initiate new processes that would otherwise not occur. The default assumption that manipulation checks do not affect experimental conclusions is unwarranted. They may amplify, undo, or interact with the effects of a manipulation. Further, the use of manipulation checks in mediational analyses does not rule out confounding variables, as any unmeasured variables that correlate with the manipulation check may still drive the relationship. Alternatives such as non-verbal and behavioral measures as manipulation checks and pilot testing are less problematic. Reviewers should view manipulation checks more critically, an
- [cites original and replication 10.1037/pspa0000121] doi:10.1007/s41465-018-0115-y | Improving Methodological Standards in Behavioral Interventions for Cognitive Enhancement | 2019 | article | cited_by 243
  Abstract: (none)
- [cites original and replication 10.1037/pspa0000121] doi:10.1037/bul0000194 | A meta-analysis of the facial feedback literature: Effects of facial feedback on emotional experience are small and variable. | 2019 | review | cited_by 239
  Abstract: The facial feedback hypothesis suggests that an individual's experience of emotion is influenced by feedback from their facial movements. To evaluate the cumulative evidence for this hypothesis, we conducted a meta-analysis on 286 effect sizes derived from 138 studies that manipulated facial feedback and collected emotion self-reports. Using random effects meta-regression with robust variance estimates, we found that the overall effect of facial feedback was significant but small. Results also indicated that feedback effects are stronger in some circumstances than others. We examined 12 potential moderators, and 3 were associated with differences in effect sizes: (a) Type of emotional outcome: Facial feedback influenced emotional experience (e.g., reported amusement) and, to a greater degree, affective judgments of a stimulus (e.g., the objective funniness of a cartoon). Three publication bias detection methods did not reveal evidence of publication bias in studies examining the effects of facial feedback on emotional experience, but all 3 methods revealed evidence of publication bias in studies examining affective judgments. (b) Presence of emotional stimuli: Facial feedback effec
- [cites original and replication 10.1037/pspa0000121] doi:10.1002/arcp.1067 | Metacognitive experiences as information: Processing fluency in consumer judgment and decision making | 2020 | article | cited_by 183
  Abstract: Abstract Thinking is accompanied by metacognitive experiences of ease or difficulty. People draw on these experiences as a source of information that can complement or challenge the implications of declarative information. We conceptualize the operation of metacognitive experiences within the framework of feelings‐as‐information theory and review their implications for judgments relevant to consumer behavior, including popularity, trust, risk, truth, and beauty.
- [cites original and replication 10.1037/pspa0000121] doi:10.1016/j.neubiorev.2020.02.031 | Measuring the evolution of facial ‘expression’ using multi-species FACS | 2020 | article | cited_by 131
  Abstract: (none)
- [cites original and replication 10.1177/1745691616674458] doi:10.1016/j.neubiorev.2017.05.013 | Connecting minds and sharing emotions through mimicry: A neurocognitive model of emotional contagion | 2017 | article | cited_by 442
  Abstract: During social interactions, people tend to automatically align with, or mimic their interactor's facial expressions, vocalizations, postures and other bodily states. Automatic mimicry might be implicated in empathy and affiliation and is impaired in several pathologies. Despite a growing body of literature on its phenomenology, the function and underlying mechanisms of mimicry remain poorly understood. The current review puts forward a new Neurocognitive Model of Emotional Contagion (NMEC), demonstrating how basic automatic mimicry can give rise to emotional contagion. We combine neurological, developmental and evolutionary insights to argue that automatic mimicry is a precursor to healthy social development. We show that (i) strong synchronization exists between people, (ii) that this resonates on different levels of processing and (iii) demonstrate how mimicry translates into emotional contagion. We conclude that our synthesized model, built upon integrative knowledge from various fields, provides a promising avenue for future research investigating the role of mimicry in human mental health and social development.
- [cites original and replication 10.1177/1745691616674458] doi:10.1177/2515245919898657 | A Conceptual Introduction to Bayesian Model Averaging | 2020 | article | cited_by 347
  Abstract: Many statistical scenarios initially involve several candidate models that describe the data-generating process. Analysis often proceeds by first selecting the best model according to some criterion and then learning about the parameters of this selected model. Crucially, however, in this approach the parameter estimates are conditioned on the selected model, and any uncertainty about the model-selection process is ignored. An alternative is to learn the parameters for all candidate models and then combine the estimates according to the posterior probabilities of the associated models. This approach is known as Bayesian model averaging (BMA). BMA has several important advantages over all-or-none selection methods, but has been used only sparingly in the social sciences. In this conceptual introduction, we explain the principles of BMA, describe its advantages over all-or-none model selection, and showcase its utility in three examples: analysis of covariance, meta-analysis, and network analysis.
- [cites original and replication 10.1177/1745691616674458] doi:10.1038/s41562-019-0787-z | Comparing meta-analyses and preregistered multiple-laboratory replication projects | 2019 | article | cited_by 296
  Abstract: (none)
